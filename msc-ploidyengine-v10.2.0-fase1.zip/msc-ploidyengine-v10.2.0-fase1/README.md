# MSC PloidyEngine v10.2.0 — PloidyGen (Scope M)

Simulador Monte Carlo de cruces poliploides — Mexicanas Seeds Company, División Biotecnológica.
Software propietario, uso interno.

## Uso rápido
Abre `dist/MSC_PloidyEngine_v10-2-0-PloidyGen.html` en el navegador. Es un archivo único y autónomo (sin servidor ni dependencias).

## Cruces soportados
| Parental A | Parental B | Zigoto | `maxDoseLocus` |
|---|---|---|---|
| 4x | 2x | triploide (ruta clásica) | 3 |
| 2x | 2x | diploide | 2 |
| 4x | 4x | tetraploide | 4 |
| 2x | 4x | triploide (A aporta 1 copia, B aporta 2) | 3 |

`maxDoseLocus = GAMETE_COPIES[ploidyA] + GAMETE_COPIES[ploidyB]` con `GAMETE_COPIES = {2: 1, 4: 2}`.
Genotipos: 4x → 0..4 (aaaa…AAAA); 2x → 0..2 (aa, Aa, AA).

## Estructura
```
src/engine/   motor (sin DOM): RNG, Haldane, EpistasisMatrix, HaplotypicBlockEngine,
              MeiosisEngine, ProbabilityValidator, tipos de genoma, GenomicPolyploidEngine
src/ui/       estado, controles, render, run-montecarlo, biblioteca, validación/auditoría
src/scopes/   Scope K (trazabilidad haplotípica), Scope L (auditoría de varianza), Evidence Layer
src/manifest.json         orden de carga (los módulos son scripts globales, no ES modules)
src/index.template.html   HTML + CSS; el marcador /*@@SCRIPT@@*/ se reemplaza al compilar
build.js      src/ → dist/*.html (archivo único)
tests/        engine.test.js (Node, sin dependencias) · ui-smoke.test.js (jsdom)
```

## Comandos
```
npm run build      # compila dist/MSC_PloidyEngine_v10-2-0-PloidyGen.html
npm test           # 75 pruebas del motor (sin dependencias)
npm install && npm run test:ui   # humo de UI: runMonteCarlo en los 4 cruces
```
Para añadir un módulo: crea el archivo y agrégalo a `src/manifest.json` en el orden correcto
(los módulos de `engine/` deben ir antes que los de `ui/` y `scopes/`).

## Modelo meiótico 4x (v10.2)
- Bivalentes aleatorios: en cada meiosis se sortea qué cromátidas físicas portan A.
- Doble reducción (probabilidad α): el gameto recibe las dos cromátidas hermanas de un mismo cromosoma.
- Con α=0 las dosis coinciden con la tabla de Mather para todos los genotipos.
  Con α>0 coinciden exactamente para g=0, 2 y 4.

## Limitaciones conocidas
1. **Simplex y tríplex con α>0**: `tetraploidGameteProbs` no asigna la fracción α/4 de gametos AA (g=1)
   ni aa (g=3) que sí produce la simulación; la diferencia máxima es ≈0.04 (α=1/6). Las pruebas
   documentan el comportamiento simulado. Pendiente decidir si se corrige la fórmula.
2. **Regresión vs v9.2.0**: en 4x×2x con la misma semilla, v10.1 era idéntico salvo `totalD`/`totalG`
   (≤0.1 %, por las constantes truncadas 0.333/0.667 del original). v10.2 cambia la secuencia del RNG en
   rutas 4x (meiosis corregida), por lo que ya no es comparable bit a bit con v9.2.0/v10.1.
3. Al cambiar la ploidía de un parental se conserva el código de genotipo si es válido en la nueva
   ploidía (p. ej. dúplex AAaa = 2 pasa a AA = 2). Revisa el genotipo tras cambiar de ploidía.
4. Los umbrales de wSDT se reescalan proporcionalmente a `maxDoseLocus` (calibrados originalmente para 3).
