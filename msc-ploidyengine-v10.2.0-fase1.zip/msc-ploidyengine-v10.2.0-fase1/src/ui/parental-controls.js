
// ─── [SM-7] updateParentalGenoOptions ────────────────────────────────
const GENO_OPTIONS = {
  4: [[0,'Nuliplexo — aaaa'],[1,'Simplexo — Aaaa'],[2,'Dúplexo — AAaa'],[3,'Tríplexo — AAAa'],[4,'Cuádruplexo — AAAA']],
  2: [[0,'Homocigoto recesivo — aa'],[1,'Heterocigoto — Aa'],[2,'Homocigoto dominante — AA']]
};
function updateParentalGenoOptions(which) {
  const ploidy = parseInt($(which === 'A' ? 'parA-ploidy' : 'parB-ploidy').value);
  const sel    = $(which === 'A' ? 'par4x' : 'par2x');
  const opts   = GENO_OPTIONS[ploidy];
  const cur    = parseInt(sel.value);
  const keep   = opts.some(o => o[0] === cur) ? cur : 1;   // default: heterocigoto/simplexo-dúplex
  const def    = ploidy === 4 && !opts.some(o => o[0] === cur) ? 2 : keep;
  sel.innerHTML = opts.map(o => `<option value="${o[0]}"${o[0] === def ? ' selected' : ''}>${o[1]}</option>`).join('');
  updateMinDoseOptions();
}

// [v10.2] Dosis mínima acotada a 1..maxDoseLocus del cruce actual
function updateMinDoseOptions() {
  const maxD = (GAMETE_COPIES[parseInt($('parA-ploidy').value)] ?? 2)
             + (GAMETE_COPIES[parseInt($('parB-ploidy').value)] ?? 1);
  const sel = $('minDose');
  const cur = parseInt(sel.value) || 1;
  const lbl = k => k === 1 ? '1 copia dominante (dominancia simple)'
                 : k === maxD ? `${k} copias dominantes (requerimiento máximo)`
                 : k === 2 ? '2 copias dominantes (semidominancia)'
                 : `${k} copias dominantes`;
  const keep = Math.min(cur, maxD);
  sel.innerHTML = Array.from({ length: maxD }, (_, i) => i + 1)
    .map(k => `<option value="${k}"${k === keep ? ' selected' : ''}>${lbl(k)}</option>`).join('');
}
