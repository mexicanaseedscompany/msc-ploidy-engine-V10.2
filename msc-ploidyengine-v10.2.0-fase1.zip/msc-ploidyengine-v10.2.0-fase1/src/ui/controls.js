
// ─── Tabs ────────────────────────────────────────────────────────────
function switchTab(id) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  $(`tab-${id}`).classList.add('active');
  event.target.classList.add('active');
}

// ─── Actualizadores de controles ────────────────────────────────────
function updateAlpha()     { $('alphaOut').textContent      = (parseInt($('alphaSlider').value) / 10000).toFixed(4); }
function updateN()         { $('nOut').textContent          = nLabels[parseInt($('nSlider').value)]; }
function updateChar(id, out){ $(out).innerHTML              = parseInt($(id).value) + ' <span>loci</span>'; }
function updateMuBase()    { $('muBaseOut').textContent     = parseFloat($('muBase').value).toFixed(1) + '%'; }
function updateAdit()      { $('efectoAditOut').textContent = parseFloat($('efectoAdit').value).toFixed(2) + '%'; }
function updateH2()        { $('h2Out').textContent         = (parseInt($('h2Slider').value) / 100).toFixed(2); }
function updateSigma()     { $('sigmaEOut').textContent     = parseFloat($('sigmaE').value).toFixed(2); }
function updateDominance() { $('dominanceOut').textContent  = (parseInt($('dominance').value) / 100).toFixed(2); }
function updateEpistasis() { $('epistasisOut').textContent  = (parseInt($('epistasis').value) / 100).toFixed(2); }
function updateSelP()      { $('selPOut').textContent       = $('selPressure').value + '%'; }

function updatePairing() {
  const biv  = parseInt($('bivSlider').value);
  const quad = 100 - biv;
  $('bivSlider').value  = biv;
  $('quadSlider').value = quad;
  $('bivOut').textContent  = biv  + '%';
  $('quadOut').textContent = quad + '%';
}

$('alphaSlider').addEventListener('input', updateAlpha);
$('nSlider').addEventListener('input', updateN);
['c1','c2','c3'].forEach(id => $(id).addEventListener('input', () => updateChar(id, id+'v')));
$('muBase').addEventListener('input', updateMuBase);
$('efectoAdit').addEventListener('input', updateAdit);
$('h2Slider').addEventListener('input', updateH2);
$('sigmaE').addEventListener('input', updateSigma);
$('dominance').addEventListener('input', updateDominance);
$('epistasis').addEventListener('input', updateEpistasis);
$('bivSlider').addEventListener('input', () => { updatePairing(); });
