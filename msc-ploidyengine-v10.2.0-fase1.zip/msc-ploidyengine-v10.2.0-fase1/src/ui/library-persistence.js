
// ─── Biblioteca ──────────────────────────────────────────────────────
function renderLibrary() {
  if (simLibrary.length === 0) {
    $('libraryDisplay').innerHTML = `<div class="lib-empty">Sin simulaciones registradas.</div>`;
    return;
  }
  const rows = simLibrary.slice().reverse().map(s =>
    `<tr>
      <td>#${s.id}</td>
      <td>${s.date.slice(0,19).replace('T',' ')}</td>
      <td>${s.cross}</td>
      <td>α=${s.alpha} | Biv=${(s.pairing.bivalent*100).toFixed(0)}%</td>
      <td>${s.prediction.mu}%</td>
      <td>${s.observed ? s.observed+'%' : '<span style="color:var(--muted)">—</span>'}</td>
      <td>${s.error ? (parseFloat(s.error)>0?'+':'')+s.error : '<span style="color:var(--muted)">—</span>'}</td>
      <td>${s.modelAccuracy ? s.modelAccuracy+'%' : '<span style="color:var(--muted)">—</span>'}</td>
    </tr>`
  ).join('');
  $('libraryDisplay').innerHTML = `
    <div class="zyg-wrap">
      <table class="lib-table">
        <thead><tr><th>#</th><th>Fecha</th><th>Cruce</th><th>Parámetros</th><th>μ Pred</th><th>Observado</th><th>Error</th><th>Exactitud</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>`;
}

function exportLibrary() {
  if (simLibrary.length === 0) { alert('No hay simulaciones para exportar.'); return; }
  const blob = new Blob([JSON.stringify(simLibrary, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = `MSC_PloidyEngine_v5_library_${Date.now()}.json`;
  a.click(); URL.revokeObjectURL(url);
}

function clearLibrary() {
  if (simLibrary.length === 0) return;
  if (!confirm('¿Mover todas las simulaciones a la papelera de respaldo local?')) return;

  localStorage.setItem(TRASH_KEY, JSON.stringify(simLibrary));

  simLibrary.length = 0;
  SIM_COUNT = 0;
  $('hstatSims').textContent = '0';

  saveLibrary();
  checkTrash();
  renderLibrary();
}

// ─── Calibración ─────────────────────────────────────────────────────
function registerObserved() {
  const obs = parseFloat($('obsInput').value);
  if (!SIM_STATE || isNaN(obs)) {
    alert('Ejecuta la simulación primero e ingresa un valor observado.');
    return;
  }
  const pred   = SIM_STATE.mu;
  const err    = obs - pred;
  const errPct = (err / pred) * 100;
  const lastSim = simLibrary[simLibrary.length - 1];
  if (lastSim) {
    lastSim.observed     = obs.toFixed(3);
    lastSim.error        = err.toFixed(3);
    lastSim.modelAccuracy = (100 - Math.abs(errPct)).toFixed(2);
  }
  const col = Math.abs(errPct) < 5 ? 'var(--ok)' : Math.abs(errPct) < 15 ? 'var(--warn)' : 'var(--danger)';
  $('accuracyDisplay').innerHTML = `
    <div class="acc-grid">
      <div class="acc-card"><div class="acc-num" style="color:var(--accent)">${pred.toFixed(2)}%</div><div class="acc-lab">μ PREDICHA</div></div>
      <div class="acc-card"><div class="acc-num" style="color:var(--accent2)">${obs.toFixed(2)}%</div><div class="acc-lab">μ OBSERVADA</div></div>
      <div class="acc-card"><div class="acc-num" style="color:${col}">${err > 0 ? '+' : ''}${err.toFixed(3)}</div><div class="acc-lab">ERROR ABSOLUTO</div></div>
      <div class="acc-card"><div class="acc-num" style="color:${col}">${(100-Math.abs(errPct)).toFixed(1)}%</div><div class="acc-lab">EXACTITUD MODELO</div></div>
    </div>`;
  saveLibrary(); // [Scope G] Persistir calibración
  renderLibrary();
}

// ─── PERSISTENCIA Y PAPELERA LOCAL (Scope G) ────────────────────────
const STORAGE_KEY = 'msc_ploidy_library_v5';
const TRASH_KEY   = 'msc_ploidy_trash_v5';

function saveLibrary() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(simLibrary));
  localStorage.setItem('msc_ploidy_count_v5', SIM_COUNT);
}

function loadLibrary() {
  const stored = localStorage.getItem(STORAGE_KEY);
  const count  = localStorage.getItem('msc_ploidy_count_v5');
  if (stored) {
    const parsed = JSON.parse(stored);
    simLibrary.length = 0;
    parsed.forEach(item => simLibrary.push(item));
    SIM_COUNT = count ? parseInt(count) : simLibrary.length;
    $('hstatSims').textContent = SIM_COUNT;
    renderLibrary();
  }
  checkTrash();
}

function checkTrash() {
  const trash = localStorage.getItem(TRASH_KEY);
  $('btnRestore').style.display = trash ? 'inline-block' : 'none';
}

function restoreLibrary() {
  const trash = localStorage.getItem(TRASH_KEY);
  if (trash) {
    const parsed = JSON.parse(trash);
    parsed.forEach(item => simLibrary.push(item));
    SIM_COUNT = simLibrary.length > 0 ? Math.max(...simLibrary.map(s => s.id)) : 0;
    $('hstatSims').textContent = SIM_COUNT;
    saveLibrary();
    localStorage.removeItem(TRASH_KEY);
    checkTrash();
    renderLibrary();
  }
}

// ─── Pesos por carácter ───────────────────────────────────────────────
function updateWeights() {
  const w1 = parseInt($('wResina').value);
  const w2 = parseInt($('wVigor').value);
  const w3 = parseInt($('wEstructura').value);
  $('wResinaOut').textContent    = w1 + '%';
  $('wVigorOut').textContent     = w2 + '%';
  $('wEstructuraOut').textContent = w3 + '%';
  const total = w1 + w2 + w3;
  $('weightWarnMsg').style.display = (total !== 100) ? 'block' : 'none';
}
