// quadSlider es ahora hidden (calculado = 100 − biv); no necesita listener

// ─── Render: Mapa genómico ───────────────────────────────────────────
function renderGenomeMap(genomeDef, alpha) {
  let mapHTML = '';
  let recombHTML = '<table class="r-table"><thead><tr><th>Cromosoma</th><th>Par de loci</th><th>Δ cM</th><th>r (Haldane)</th><th>Ligamiento</th></tr></thead><tbody>';

  genomeDef.forEach(chrDef => {
    const totalLen = chrDef.length_cM;
    let locusMarkersHTML = chrDef.loci.map(l => {
      const leftPct = (l.pos_cM / totalLen * 100).toFixed(1);
      return `<div class="chr-locus" style="left:${leftPct}%;" title="${l.name} @ ${l.pos_cM} cM"></div>
              <div class="chr-locus-label" style="left:${leftPct}%;">${l.name.replace('QTL_','')}</div>`;
    }).join('');

    let locusTableHTML = chrDef.loci.map(l =>
      `<div class="locus-row">
        <span class="locus-name">${l.name}</span>
        <span class="locus-pos">${l.pos_cM} cM</span>
        <span class="locus-eff">A:+${l.effect.toFixed(2)}</span>
        <span class="locus-dom">D:${(l.dominance||0).toFixed(2)}</span>
      </div>`
    ).join('');

    mapHTML += `<div class="chr-card">
      <div class="chr-head"><span>${chrDef.id} — ${totalLen} cM</span><span style="color:var(--accent)">${chrDef.loci.length} QTLs</span></div>
      <div class="chr-track" style="height:14px;margin-bottom:24px;">${locusMarkersHTML}</div>
      ${locusTableHTML}
    </div>`;

    for (let i = 1; i < chrDef.loci.length; i++) {
      const l1    = chrDef.loci[i-1], l2 = chrDef.loci[i];
      const delta = Math.abs(l2.pos_cM - l1.pos_cM);
      const r     = RecombinationEngine.haldane(l1.pos_cM, l2.pos_cM);
      const link  = r < 0.10 ? '🔗 Fuerte' : r < 0.30 ? '≈ Moderado' : '↔ Libre';
      recombHTML += `<tr><td>${chrDef.id}</td><td>${l1.name} ↔ ${l2.name}</td><td>${delta.toFixed(1)}</td><td>${r.toFixed(4)}</td><td>${link}</td></tr>`;
    }
  });

  recombHTML += '</tbody></table>';
  $('genomeMapDisplay').innerHTML = mapHTML;
  $('recombDisplay').innerHTML    = recombHTML;
  $('hstatQTL').textContent       = genomeDef.reduce((s, c) => s + c.loci.length, 0);
}

// ─── Render: analíticas gaméticas ────────────────────────────────────
function renderAnalytics(g4, g2, alpha, ploidyA = 4, ploidyB = 2) {
  const maxDose = (GAMETE_COPIES[ploidyA] ?? 2) + (GAMETE_COPIES[ploidyB] ?? 1);
  const distA = MeiosisEngine.gameteDist(ploidyA, g4, alpha);
  const distB = MeiosisEngine.gameteDist(ploidyB, g2, alpha);
  ProbabilityValidator.check(distA.map(x => x.p), `Gametos ${ploidyA}x g=${g4}`);
  ProbabilityValidator.check(distB.map(x => x.p), `Gametos ${ploidyB}x g=${g2}`);
  const glabels = {
    4: ['aaaa','Aaaa','AAaa','AAAa','AAAA'],
    2: ['aa','Aa','AA']
  };
  const gnames = {
    AA: 'AA (doble dominante)', Aa: 'Aa (heterocigoto)', aa: 'aa (doble recesivo)',
    A: 'A (dominante)', a: 'a (recesivo)'
  };
  const card = (title, dist) => `
    <div class="gamete-card">
      <div class="gamete-head">${title}</div>
      ${dist.map(x => `<div class="gamete-row"><span class="gamete-name">${gnames[x.label]}</span><span class="gamete-pct">${pct(x.p)}</span></div>`).join('')}
    </div>`;
  $('gameteDisplay').innerHTML =
    card(`GAMETOS ${GAMETE_COPIES[ploidyA]}x — PARENTAL A ${glabels[ploidyA][g4]} (${ploidyA}x, α=${alpha.toFixed(4)})`, distA) +
    card(`GAMETOS ${GAMETE_COPIES[ploidyB]}x — PARENTAL B ${glabels[ploidyB][g2]} (${ploidyB}x)`, distB);

  const dist = MeiosisEngine.zygoteDist(distA, distB, maxDose);
  ProbabilityValidator.check(dist, `Zigotos ${ploidyA}x×${ploidyB}x g=${g4},${g2}`);
  const ploidyName = { 2: 'diploide', 3: 'triploide', 4: 'tetraploide' }[maxDose] ?? `${maxDose}x`;
  const triLabels = { 3: 'Triple dominante', 2: 'Doble dominante', 1: 'Simple dominante', 0: 'Recesivo pleno ⚠' };
  let rows = '';
  const zyg = { dist, maxDose };
  for (let d = maxDose; d >= 0; d--) {
    const st = MeiosisEngine.renderAlleleState(d, maxDose);
    zyg[st] = dist[d];  // compat: zyg.AAA / zyg.AAa … cuando maxDose=3
    const lbl = maxDose === 3 ? triLabels[d] : `${d} copia(s) dominante(s)${d === 0 ? ' ⚠' : ''}`;
    rows += `<tr><td><strong>${st}</strong></td><td>${d}</td><td>${lbl}</td><td>${pct(dist[d])}</td></tr>`;
  }
  $('zygoteDisplay').innerHTML = `
    <table class="zyg-table">
      <thead><tr><th>Genotipo F1 ${ploidyName}</th><th>Dosis A</th><th>Fenotipo</th><th>Probabilidad</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
  return zyg;
}

// ─── Render: haplotipo muestral — Nivel 3 ────────────────────────────
// Muestra alleleState (Nivel 1, backward compat) + chips por homólogo (Nivel 3)
function renderHaplotype(gEngine, dam4xHaplotype, sire2xHaplotype, pairingMode,
                         maxDoseLocus = 3, ploidyA = 4, ploidyB = 2) {
  const zyg = gEngine.generateTriploidZygote(dam4xHaplotype, sire2xHaplotype, pairingMode,
                                              EPISTASIS_MATRIX, maxDoseLocus, ploidyA, ploidyB);
  let html  = '';

  zyg.chrResults.forEach(chrRes => {
    let rows = chrRes.loci.map(l => {
      const dc    = ['d0','d1','d2','d3'][Math.min(l.dose, 3)];
      const label = l.alleleState;  // Nivel 1 — backward compat

      // ── Nivel 3: chips por homólogo ───────────────────────────────
      // Cada chip muestra: origen (♀4x / ♂2x) + alelo individual
      // Verde = dam 4x;  Azul = sire 2x
      // Los homólogos dam con allele=A se resaltan en accent;
      // el homólogo sire con allele=A en accent2;
      // homólogos recesivos en muted
      let homologHTML = '';
      if (l.homologs && l.homologs.length) {
        const chips = l.homologs.map(h => {
          const cls  = h.origin === 'dam' ? 'dam' : 'sire';
          const tag  = h.origin === 'dam' ? `♀${ploidyA}x` : `♂${ploidyB}x`;
          const aCls = h.allele === 'A'
                         ? (h.origin === 'dam' ? 'dom-dam' : 'dom-sire')
                         : 'rec';
          return `<span class="haplo-chip ${cls}" title="[SCOPE H] ancestorId: ${h.ancestorId}">
            <span class="haplo-chip-src">${tag}</span>
            <span class="haplo-chip-allele ${aCls}">${h.allele}</span>
          </span>`;
        }).join('');
        homologHTML = `<div class="haplo-homologs">${chips}</div>`;
      }

      return `<div class="haplo-locus" style="flex-direction:column;align-items:flex-start;gap:1px;">
        <div class="haplo-locus-row">
          <span class="haplo-lname">${l.name}</span>
          <span class="haplo-dose ${dc}">${label} (${l.dose}✕) +${(l.dose * l.effect).toFixed(2)}</span>
        </div>
        ${homologHTML}
      </div>`;
    }).join('');
    html += `<div class="haplo-card">
      <div class="haplo-head">
        ${chrRes.chrId}
        <span class="n3-badge">NIVEL 3</span>
        &nbsp;
        <span style="color:var(--accent)">♀ DAM ${ploidyA}x</span>
        &nbsp;·&nbsp;
        <span style="color:var(--accent2)">♂ SIRE ${ploidyB}x</span>
      </div>
      ${rows}
    </div>`;
  });

  $('haploDisplay').innerHTML = html;
  $('gValueDisplay').innerHTML =
    `<div class="g-badge">▸ G TOTAL = <span style="font-size:16px;margin-left:6px;">${zyg.totalG.toFixed(3)}</span>
      &nbsp;|&nbsp; A=${zyg.totalA.toFixed(3)} D=${zyg.totalD.toFixed(3)} I=${zyg.totalI.toFixed(3)}</div>`;

  $('gBreakdownDisplay').innerHTML = `
    <div class="g-breakdown">
      <div class="gbd-card a"><div class="gbd-num a">${zyg.totalA.toFixed(3)}</div><div class="gbd-lab">EFECTO ADITIVO (A)</div></div>
      <div class="gbd-card d"><div class="gbd-num d">${zyg.totalD.toFixed(3)}</div><div class="gbd-lab">DESVIACIÓN DOMINANCIA (D)</div></div>
      <div class="gbd-card i"><div class="gbd-num i">${zyg.totalI.toFixed(3)}</div><div class="gbd-lab">INTERACCIÓN EPISTÁTICA (I)*</div></div>
    </div>
    <div class="gbd-formula">G = A + D + I = ${zyg.totalA.toFixed(3)} + ${zyg.totalD.toFixed(3)} + ${zyg.totalI.toFixed(3)} = ${zyg.totalG.toFixed(3)}</div>
    <div style="font-size:9px;color:var(--warn);margin-top:4px;">* I = <strong style="color:var(--accent3)">SCOPE J ACTIVO</strong>: Matriz Epistática Inter-Loci. ${zyg.epiContributions && zyg.epiContributions.length > 0
      ? zyg.epiContributions.map(c =>
          `<span style="color:var(--muted)">${c.locusA}×${c.locusB}</span>: I=${c.Iij.toFixed(3)} → <span style="color:${c.I_pair>=0?'var(--ok)':'var(--danger)'}">Δ${c.I_pair>=0?'+':''}${c.I_pair.toFixed(4)}</span>`
        ).join(' | ')
      : 'Sin pares epistáticos configurados (usando fallback de curvatura de dosis).'}</div>`;
}

// ─── Render: tabla arquitectura ──────────────────────────────────────
function renderArchTable() {
  $('archTable').innerHTML = `
    <table class="cmp-table">
      <thead><tr><th>Módulo</th><th>v5.3</th><th>v7.0 (activo)</th></tr></thead>
      <tbody>
        <tr><td>PRNG</td><td>Mulberry32 semillado ✓</td><td>Mulberry32 semillado ✓ (sin cambios)</td></tr>
        <tr><td>Núcleo gaméticos</td><td>MeiosisEngine único ✓</td><td>MeiosisEngine único ✓ (sin cambios)</td></tr>
        <tr><td>simulateMeiosis 4x</td><td style="color:var(--warn)">sampleTetraploidGamete independiente por locus ⚠</td><td style="color:var(--accent)">Strand tracking real: 4 cromátidas, crossover Haldane, double reduction corregido ✓ SCOPE C v6.1</td></tr>
        <tr><td>simulateMeiosis 2x</td><td style="color:var(--warn)">sampleDiploidGamete independiente por locus ⚠</td><td style="color:var(--accent)">Strand tracking: 2 cromátidas, flip Haldane inter-loci ✓ SCOPE C v6.1</td></tr>
        <tr><td>Bloques haplotípicos</td><td style="color:var(--danger)">Inexistentes — genes ligados tratados como independientes</td><td style="color:var(--accent)">Preservados: genes adyacentes co-segregan desde misma cromátida ✓ SCOPE C v6.1</td></tr>
        <tr><td>ancestorId / pedigree</td><td style="color:var(--warn)">STUB en homologs (dam_4x_h1, sire_2x_h1) ⚠</td><td style="color:var(--accent)">ancestorId real: 'dam_4x_ChrX_hAN_hBM' / 'sire_2x_ChrX_hN' ✓ SCOPE H</td></tr>
        <tr><td>buildLocusGenotype</td><td style="color:var(--warn)">Sin parámetros de pedigree — STUBs fijos ⚠</td><td style="color:var(--accent)">Acepta damAncestorId + sireAncestorId desde strand tracking ✓ SCOPE H</td></tr>
        <tr><td>haploBonus</td><td style="color:var(--danger)">Proxy: highDoseCount/3 — no detecta ligamiento real</td><td style="color:var(--accent)">Análisis de bloques contiguos: ancestorId compartido entre loci favorables ✓ SCOPE H</td></tr>
        <tr><td>finalEliteScore</td><td>0.8×wSDT + 0.2×(proxy dosis)</td><td>0.8×wSDT + 0.2×(integridad bloque haplotípico real — integrado en simulateLinkedMCIteration)</td></tr>
        <tr><td>effectiveAlpha</td><td style="color:var(--warn)">STUB — Fase 2 Scope B pendiente ⚠</td><td style="color:var(--warn)">STUB — pendiente ⚠</td></tr>
        <tr><td>Epistasis inter-loci</td><td style="color:var(--warn)">Curvatura de dosis (Scope E pendiente) ⚠</td><td style="color:var(--accent)">EpistasisMatrix real: Map locus×locus, I_{i,j} configurable, sinérgico/antagónico ✓ SCOPE J v7.0</td></tr>
        <tr><td>Integridad haplotípica</td><td style="color:var(--danger)">haploBonus: proxy binario sin longitud cM ✗</td><td style="color:var(--accent)">IIH real: bloques en cM, IIH por cromosoma + global, deriva generacional, log de recombinación ✓ SCOPE K v8.0</td></tr>
        <tr><td>h² real</td><td style="color:var(--warn)">Control de ruido (Scope F pendiente) ⚠</td><td style="color:var(--warn)">Control de ruido (pendiente) ⚠</td></tr>
      </tbody>
    </table>`;
}

// ─── Histograma ──────────────────────────────────────────────────────
function renderHistogram(fenotipos, media, sd) {
  const BINS = 24;
  const min  = media - 4 * sd;
  const max  = media + 4 * sd;
  const step = (max - min) / BINS;
  const counts = new Array(BINS).fill(0);
  fenotipos.forEach(v => {
    counts[Math.min(BINS - 1, Math.max(0, Math.floor((v - min) / step)))]++;
  });
  const peak = Math.max(...counts);
  $('histoBars').innerHTML = counts.map(c =>
    `<div class="histo-bar" style="height:${Math.max(2, Math.round((c / peak) * 80))}px" title="${c} ind."></div>`
  ).join('');
  $('histoAxis').innerHTML  = `<span>${min.toFixed(1)}%</span><span>${media.toFixed(2)}% ± ${sd.toFixed(2)}</span><span>${max.toFixed(1)}%</span>`;
  $('histoTitle').textContent = `DISTRIBUCIÓN FENOTÍPICA — Rendimiento simulado (n = ${fenotipos.length.toLocaleString('es-MX')})`;
  $('histoWrap').style.display = 'block';
}
