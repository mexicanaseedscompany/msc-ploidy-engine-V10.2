
// ─── Validación ──────────────────────────────────────────────────────
function runValidation() {
  const alphaV = parseInt($('alphaSlider').value) / 10000;
  // Suite completa con 4 valores de alpha incluyendo el actual
  const alphaSet = [...new Set([0, alphaV, 0.10, 1/6])];
  const checks   = ProbabilityValidator.runFullSuite(alphaSet);
  const nOk   = checks.filter(c => c.ok).length;
  const nFail = checks.filter(c => !c.ok).length;
  $('validationLog').innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
      <span class="val-badge ${nFail===0?'ok':'err'}">${nFail===0?'✓ TODAS VÁLIDAS':'✗ HAY ERRORES'}</span>
      <span style="font-size:10px;color:var(--muted)">${nOk} correctas · ${nFail} fallidas · ${checks.length} total</span>
    </div>
    <div class="val-log">
      ${checks.map(c => `
        <div class="val-row">
          <span style="color:var(--text);font-size:10px;">${c.label}</span>
          <span class="${c.ok ? 'val-check' : 'val-fail'}">${c.ok ? '✓' : '✗ ' + (c.msg||'')}</span>
        </div>`).join('')}
    </div>`;
}

// ─── Auditoría ───────────────────────────────────────────────────────
function renderAuditLog() {
  if (!SIM_STATE) {
    $('auditDisplay').innerHTML = `<div class="audit-block">Sin simulaciones ejecutadas.</div>`;
    return;
  }
  const r = SIM_STATE.simRecord;
  $('auditDisplay').innerHTML = `
    <div class="audit-block">
      <div><strong>SOFTWARE VERSION:</strong> <span>${r.version}</span></div>
      <div><strong>SIMULATION SEED:</strong> <span>${r.seed}</span></div>
      <div><strong>PRNG:</strong> <span>Mulberry32 — determinista ✓</span></div>
      <div><strong>DATE/TIME:</strong> <span>${r.date}</span></div>
      <div><strong>CROSS:</strong> <span>${r.cross}</span></div>
      <div><strong>ALPHA (α):</strong> <span>${r.alpha}</span></div>
      <div><strong>PAIRING MODE:</strong> <span>Bivalente=${(r.pairing.bivalent*100).toFixed(0)}% · Cuadrivalente=${(r.pairing.quadrivalent*100).toFixed(0)}%</span></div>
      <div><strong>LOCI (C1/C2/C3):</strong> <span>${r.loci.join(' / ')}</span></div>
      <div><strong>TRAIT WEIGHTS (C1/C2/C3):</strong> <span>${r.traitWeights ? r.traitWeights.join(' / ') : '—'}</span></div>
      <div><strong>MIN DOSE:</strong> <span>${r.minDose}</span></div>
      <div><strong>N (iterations):</strong> <span>${r.N.toLocaleString('es-MX')}</span></div>
      <div><strong>PREDICTED μ:</strong> <span>${r.prediction.mu}%</span></div>
      <div><strong>PREDICTED σ:</strong> <span>${r.prediction.sigma}</span></div>
      <div><strong>PREDICTED CV:</strong> <span>${r.prediction.cv}%</span></div>
      <div><strong>ELITE FREQUENCY (triple):</strong> <span>${r.prediction.eliteP}%</span></div>
      <div><strong>THEORETICAL P(triple):</strong> <span>${r.prediction.pTheo}</span></div>
      <div><strong>SDT &gt; 2.5 (Legacy):</strong> <span style="color:var(--accent2)">${r.prediction.sdtAbove ?? '—'}%</span></div>
      <div><strong>wSDT MEDIO POBLACIONAL:</strong> <span style="color:var(--accent2)">${r.prediction.wsdtMean ?? '—'}</span></div>
      <div><strong>SDT MEDIO C1/C2/C3:</strong> <span style="color:var(--accent)">${r.prediction.sdtMeanTrait ? r.prediction.sdtMeanTrait.join(' / ') : '—'}</span></div>
      <div><strong>TOP 1% / 5% / 10% (n):</strong> <span>${r.prediction.top1n ?? '—'} / ${r.prediction.top5n ?? '—'} / ${r.prediction.top10n ?? '—'}</span></div>
      <div><strong>MEJOR SCORE ÉLITE:</strong> <span style="color:#ffd700">${r.prediction.bestScore ?? '—'}</span></div>
      <div><strong>MEJOR FENOTIPO:</strong> <span style="color:var(--accent)">${r.prediction.bestPheno ?? '—'}%</span></div>
    </div>
    <p style="font-size:9px;color:var(--muted);margin-top:8px;">
      Reproducibilidad: misma seed + misma versión = resultado idéntico (Mulberry32).
    </p>`;
}

// ─── Multigeneracional ───────────────────────────────────────────────
function runMultigeneracional() {
  if (!SIM_STATE) { alert('Ejecuta primero la simulación principal.'); return; }
  const btn = $('runMultigen');
  btn.classList.add('running');
  btn.textContent = '⏳ SIMULANDO GENERACIONES...';

  setTimeout(() => {
    const selP  = parseInt($('selPressure').value) / 100;
    const sMode = parseInt($('selfMode').value);
    const generations = ['P', 'F1', 'F2', 'BC1', 'S1', 'S2'];
    const genData = [];
    let currentMu = SIM_STATE.mu;
    let currentCV = SIM_STATE.cv;
    let inbreeding = 0.0;

    generations.forEach((gen, idx) => {
      const selGain = idx > 0 ? currentMu * 0.06 * selP * (1 + idx * 0.1) : 0;
      const varLoss = idx > 0 ? currentCV * 0.12 * (sMode + 1) : 0;
      currentMu += selGain;
      currentCV  = Math.max(1.5, currentCV - varLoss);
      if (sMode === 2) inbreeding += 0.125 * (idx > 0 ? 1 : 0);
      else if (sMode === 1) inbreeding += 0.04 * (idx > 0 ? 1 : 0);
      genData.push({ gen, mu: currentMu, cv: currentCV,
                     inbreeding: Math.min(inbreeding, 0.99),
                     eliteEst: SIM_STATE.allP * (1 + 0.15 * idx * selP) });
    });

    let timelineHTML = '<div class="gen-timeline">';
    genData.forEach((g, i) => {
      const isCurrent = i === 0;
      const desc = ['Parentales','Primera filial','Segunda filial',
                    'Retrocruce 1','Autofec. 1','Autofec. 2'][i];
      timelineHTML += `
        <div class="gen-node ${isCurrent ? 'active' : 'completed'}">
          <div class="gen-label ${isCurrent ? '' : 'done'}">${g.gen}</div>
          <div class="gen-desc">${desc}</div>
          <div class="gen-stats">μ: ${g.mu.toFixed(1)}%<br>CV: ${g.cv.toFixed(1)}%<br>F: ${g.inbreeding.toFixed(3)}</div>
        </div>
        ${i < genData.length - 1 ? '<div class="gen-arrow">→</div>' : ''}`;
    });
    timelineHTML += '</div>';

    const tableHTML = `
      <div class="zyg-wrap" style="margin-top:12px;">
        <table class="zyg-table">
          <thead><tr><th>Generación</th><th>μ estimada (%)</th><th>CV (%)</th><th>F (endogamia)</th><th>Frecuencia elite est.</th></tr></thead>
          <tbody>
            ${genData.map(g => `<tr>
              <td><strong>${g.gen}</strong></td>
              <td style="color:var(--accent)">${g.mu.toFixed(2)}%</td>
              <td style="${parseFloat(g.cv)>20?'color:var(--danger)':parseFloat(g.cv)>10?'color:var(--warn)':'color:var(--ok)'}">${g.cv.toFixed(2)}%</td>
              <td>${g.inbreeding.toFixed(3)}</td>
              <td style="color:var(--accent)">${(Math.min(g.eliteEst,1)*100).toFixed(2)}%</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <p style="font-size:9px;color:var(--muted);margin-top:8px;">⚠ Estimaciones teóricas simplificadas. Las ganancias reales dependen de la varianza aditiva disponible.</p>`;

    $('multigenTimeline').innerHTML = timelineHTML;
    $('multigenStats').innerHTML    = tableHTML;
    btn.classList.remove('running');
    btn.textContent = '⏩ SIMULAR PROGRESIÓN GENERACIONAL';
  }, 30);
}
