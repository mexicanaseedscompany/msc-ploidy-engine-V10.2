
// ─── Estado global ───────────────────────────────────────────────────
let SIM_STATE = null;
let SIM_SEED  = null;
let SIM_COUNT = 0;
const simLibrary = [];

// ─── Helpers ────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const pct = v => (v * 100).toFixed(2) + '%';
const nMap    = { 3: 1000, 4: 10000, 5: 100000 };
const nLabels = { 3: '1,000', 4: '10,000', 5: '100,000' };

// ─── Genoma por defecto ──────────────────────────────────────────────
const DEFAULT_GENOME = [
  {
    id: 'Chr1', length_cM: 120.5,
    loci: [
      { name: 'THCAS_1',     pos_cM: 15.2, effect: 1.20, dominance: 0.45, epistasis: 0.10, trait: 'cannabinoids' },
      { name: 'TERP_MYR',    pos_cM: 22.8, effect: 0.90, dominance: 0.30, epistasis: 0.05, trait: 'terpenes'     },
      { name: 'QTL_Resina2', pos_cM: 40.0, effect: 0.80, dominance: 0.20, epistasis: 0.08, trait: 'cannabinoids' }
    ]
  },
  {
    id: 'Chr2', length_cM: 95.0,
    loci: [
      { name: 'QTL_Morfol',  pos_cM: 12.0, effect: 1.50, dominance: 0.60, epistasis: 0.12, trait: 'morphology'   },
      { name: 'CBDAS_1',     pos_cM: 55.0, effect: 1.10, dominance: 0.40, epistasis: 0.07, trait: 'cannabinoids' }
    ]
  }
];
