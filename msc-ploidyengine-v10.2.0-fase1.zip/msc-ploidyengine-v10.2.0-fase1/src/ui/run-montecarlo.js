
// ─── MOTOR PRINCIPAL — runMonteCarlo ─────────────────────────────────
function runMonteCarlo() {
  const btn = $('runBtn');
  btn.classList.add('running');
  btn.textContent = '⏳ SIMULANDO...';

  setTimeout(() => {
    // [F1-1] Generar seed e inicializar PRNG determinista
    SIM_SEED = Math.floor(Math.random() * 999999999);
    _RNG     = new RNG(SIM_SEED);

    const alpha      = parseInt($('alphaSlider').value) / 10000;
    const ploidyA    = parseInt($('parA-ploidy').value);
    const ploidyB    = parseInt($('parB-ploidy').value);
    const g4         = parseInt($('par4x').value);
    const g2         = parseInt($('par2x').value);
    const minDose    = parseInt($('minDose').value);
    const N          = nMap[parseInt($('nSlider').value)];
    const nLoci      = [parseInt($('c1').value), parseInt($('c2').value), parseInt($('c3').value)];
    const muBase     = parseFloat($('muBase').value);
    const efectoAdit = parseFloat($('efectoAdit').value);
    const heredab    = parseInt($('h2Slider').value) / 100;
    const desvAmb    = parseFloat($('sigmaE').value);
    const domCoef    = parseInt($('dominance').value) / 100;
    const epiCoef    = parseInt($('epistasis').value) / 100;
    const biv        = parseInt($('bivSlider').value) / 100;
    const quad       = 1 - biv;
    const pairingMode = { bivalent: biv, quadrivalent: quad };

    // [SM-6] Dosis máxima del zigoto: 4x×2x→3, 2x×2x→2, 4x×4x→4
    const maxDoseLocus = (GAMETE_COPIES[ploidyA] ?? 2) + (GAMETE_COPIES[ploidyB] ?? 1);
    HaplotypicBlockEngine.setCrossContext(ploidyA, ploidyB);

    // ── [EvidenceLayer v9.1] Flags desde nivel de evidencia activo ───────────
    //
    // useQTL:
    //   true  (L2–L3): DEFAULT_GENOME con pos_cM reales, ligamiento Haldane real.
    //   false (L0–L1): genoma sintético spacingCM=50 (r≈0.43, cuasi-libre).
    //
    // useEpistasis:
    //   true  (L2–L3): EpistasisMatrix.computeI() activo.
    //                  I_comp = totalI_matrix de pares configurados.
    //   false (L0–L1): EpistasisMatrix puenteada — instancia vacía temporal.
    //                  I_comp cae al fallback curvatura de dosis.
    //                  Panel Scope J deshabilitado visualmente.
    //
    // Estas flags controlan solo flujo de datos.
    // EpistasisMatrix, computeI(), simulateLinkedMCIteration() intactos.
    const useQTL       = (EL_ACTIVE_LEVEL >= 2);
    const useEpistasis = (EL_ACTIVE_LEVEL >= 2);
    // useIIH: Scope K requiere mapa genómico con pos_cM reales (L3).
    // Sin él, ancestorId son sintéticos y el IIH no es interpretable.
    // Dependencia dura: useIIH=true → useQTL=true (L3 ⊂ L2).
    const useIIH       = (EL_ACTIVE_LEVEL >= 3);

    // [EvidenceLayer v9.1] Panel visual Scope J — overlay cuando useEpistasis=false
    {
      const epiPanel = $('epiMatrixPanel');
      const existingOverlay = document.getElementById('elEpiOverlay');
      if (!useEpistasis) {
        // Bloquear interacción en el panel contenedor (no solo el overlay)
        epiPanel.style.pointerEvents = 'none';
        epiPanel.style.userSelect    = 'none';
        if (!existingOverlay) {
          const overlay = document.createElement('div');
          overlay.id = 'elEpiOverlay';
          overlay.style.cssText = [
            'position:absolute', 'inset:0', 'background:rgba(10,15,20,.82)',
            'display:flex', 'align-items:center', 'justify-content:center',
            'border-radius:6px', 'z-index:10', 'pointer-events:all'
          ].join(';');
          overlay.innerHTML =
            '<div style="text-align:center;font-family:var(--mono);font-size:9px;color:var(--muted);padding:16px;">' +
            '○ SCOPE J DESACTIVADO<br>' +
            '<span style="font-size:8px;opacity:.7;">Requiere Nivel 2+ (QTL Mapeados)<br>' +
            'I_comp usa fallback de curvatura de dosis</span></div>';
          // epiMatrixPanel necesita position:relative para el overlay absoluto
          if (getComputedStyle(epiPanel).position === 'static') {
            epiPanel.style.position = 'relative';
          }
          epiPanel.appendChild(overlay);
        }
      } else {
        // Quitar overlay y restaurar interacción si nivel subió a 2+
        epiPanel.style.pointerEvents = '';
        epiPanel.style.userSelect    = '';
        if (existingOverlay) existingOverlay.remove();
      }
    }

    // [EvidenceLayer v9.1] Tab visual Scope K — overlay cuando useIIH=false
    // Patrón simétrico al overlay de Scope J.
    // Scope K depende de pos_cM reales + densidad haplotípica → solo L3.
    // Sin estos datos el IIH es matemáticamente calculable pero biológicamente
    // sin significado. El overlay comunica esto antes de que el usuario intente
    // navegar al tab, evitando confusión con datos aparentemente válidos.
    {
      const kTab = document.getElementById('tab-trazabilidad');
      const kTabBtn = [...document.querySelectorAll('.tab-btn')]
        .find(b => b.textContent.includes('TRAZABILIDAD'));
      const existingKOverlay = document.getElementById('elKOverlay');

      if (!useIIH) {
        // Overlay sobre el contenido del tab
        if (!existingKOverlay && kTab) {
          if (getComputedStyle(kTab).position === 'static') {
            kTab.style.position = 'relative';
          }
          const kOverlay = document.createElement('div');
          kOverlay.id = 'elKOverlay';
          kOverlay.style.cssText = [
            'position:absolute', 'inset:0', 'background:rgba(10,15,20,.88)',
            'display:flex', 'align-items:center', 'justify-content:center',
            'z-index:10', 'pointer-events:none', 'border-radius:4px'
          ].join(';');
          kOverlay.innerHTML =
            '<div style="text-align:center;font-family:var(--mono);padding:24px;max-width:420px;">' +
            '<div style="font-size:11px;color:var(--muted);margin-bottom:10px;">◎ SCOPE K — NO DISPONIBLE</div>' +
            '<div style="font-size:9px;color:var(--muted);line-height:1.8;font-family:var(--sans);">' +
            'La Integridad Haplotípica (IIH) requiere:<br>' +
            '<span style="color:var(--text);">① Mapa QTL con posiciones cM reales (Nivel 2+)</span><br>' +
            '<span style="color:var(--text);">② Densidad de marcadores inter-QTL (Nivel 3)</span><br><br>' +
            '<span style="color:var(--accent);font-weight:700;">Activa Nivel 3 → Genómico Completo</span>' +
            '</div></div>';
          kTab.appendChild(kOverlay);
        }
        // Dim el botón del tab para señalizar inactividad
        if (kTabBtn) {
          kTabBtn.style.opacity = '0.4';
          kTabBtn.title = 'Scope K requiere Nivel 3 — Genómico Completo';
        }
      } else {
        // Quitar overlay y restaurar botón si nivel subió a 3
        if (existingKOverlay) existingKOverlay.remove();
        if (kTabBtn) {
          kTabBtn.style.opacity = '';
          kTabBtn.title = '';
        }
      }
    }

    // Render estáticos — condicional en useQTL
    if (useQTL) {
      renderGenomeMap(DEFAULT_GENOME, alpha);
    } else {
      // Limpiar paneles QTL para que no muestren datos obsoletos de runs anteriores
      $('genomeMapDisplay').innerHTML =
        `<div style="font-size:10px;color:var(--muted);padding:12px 4px;">
          ⊘ Mapa QTL desactivado — Nivel de evidencia L${EL_ACTIVE_LEVEL} (sin posiciones cM).
          Activa Nivel 2 o superior para ver el mapa genómico.
        </div>`;
      $('recombDisplay').innerHTML =
        `<div style="font-size:10px;color:var(--muted);padding:12px 10px;">
          ⊘ Tabla de recombinación desactivada — sin mapa de ligamiento.
        </div>`;
    }

    const zyg = renderAnalytics(g4, g2, alpha, ploidyA, ploidyB);

    // Motores v5
    const v3 = new PolyploidEngineV3(alpha);
    const v4 = new GenomicPolyploidEngine(alpha);

    // buildGenome solo con QTLs reales cuando useQTL está activo
    if (useQTL) {
      v4.buildGenome(DEFAULT_GENOME);
    } else {
      // Genoma mínimo: un cromosoma ficticio por carácter, loci independientes
      // Se construye con buildMCGenome para mantener estructura compatible.
      // spacingCM = 50 → r ≈ 0.43 (cuasi-libre entre loci)
      const minimalGenomeDef = nLoci.map((n, c) => ({
        id: `FictitiousChr${c}`,
        length_cM: n * 50,
        loci: Array.from({ length: n }, (_, l) => ({
          name:      `MC_C${c}_L${l}`,
          pos_cM:    (l + 1) * 50,
          effect:    efectoAdit,
          dominance: domCoef,
          epistasis: epiCoef,
          trait:     ['cannabinoids','terpenes','morphology'][c] ?? `trait_${c}`
        }))
      }));
      v4.buildGenome(minimalGenomeDef);
    }

    // [F1-8] Haplotipo parental: modo uniforme (compatibilidad v4.1)
    // En versiones futuras: editor de haplotipo por locus en la UI
    const dam4x  = ParentalHaplotype.fromUniform(g4);
    const sire2x = ParentalHaplotype.fromUniform(g2);

    // Zigoto muestral y tabla de arquitectura: solo con QTLs mapeados
    if (useQTL) {
      renderHaplotype(v4, dam4x, sire2x, pairingMode, maxDoseLocus, ploidyA, ploidyB);
      renderArchTable();
    } else {
      $('haploDisplay').innerHTML =
        `<div style="font-size:10px;color:var(--muted);padding:12px 4px;">
          ⊘ Zigoto muestral desactivado — requiere mapa QTL (Nivel 2+).
        </div>`;
      $('gValueDisplay').innerHTML = '';
      $('gBreakdownDisplay').innerHTML =
        `<div style="font-size:10px;color:var(--muted);padding:8px 4px;">
          ⊘ Desglose G = A + D + I desactivado — requiere Nivel 2+.
        </div>`;
      $('archTable').innerHTML =
        `<div style="font-size:10px;color:var(--muted);padding:12px 10px;">
          ⊘ Comparativa de arquitectura desactivada — requiere Nivel 2+.
        </div>`;
    }

    // ── Monte Carlo — SCOPE C: ligamiento real ──
    // [F3-4] Usa simulateLinkedMCIteration (strand tracking, Haldane entre loci)
    // sampleTriploidZygoteSingle ya NO se invoca en este bucle.
    let allPass = 0, partial = 0, nonePass = 0;
    const charPass = [0, 0, 0];
    const sigmaE   = desvAmb * Math.sqrt((1 - heredab) / heredab);
    const fenotipos = [];
    let sumP = 0;

    // [Scope-D] Precalcular totalLoci para SDT (necesario dentro del loop)
    const totalLoci = nLoci.reduce((a, b) => a + b, 0);
    let sdtAbove = 0; // contador individuos con SDT > 2.5

    // [FASE 2] SDT acumulado por carácter
    const sdtSumTrait = [0, 0, 0];

    // [FASE 3] Pesos normalizados por carácter
    const rawWeights = [
      parseInt($('wResina').value) / 100,
      parseInt($('wVigor').value) / 100,
      parseInt($('wEstructura').value) / 100
    ];
    const wSum = rawWeights.reduce((a,b)=>a+b,0) || 1;
    const traitWeights = rawWeights.map(w => w / wSum);

    // [FASE 4] Elite pool
    const elitePool = [];

    // [SK-3] IIH accumulators — Scope K
    let iihSum         = 0;   // Σ IIH per iteration (for population mean)
    let iihBlockLenSum = 0;   // Σ meanBlockCM per iteration
    let iihRecombSum   = 0;   // Σ total recombination events per iteration
    let skLastResult   = null; // último análisis K para renderizado

    // ── [SCOPE L] Acumuladores para descomposición de varianza ──────────
    // Se acumulan los valores individuales de cada componente para calcular
    // Var(A), Var(D), Var(I), Var(E) y verificar V_P = V_A + V_D + V_I + V_E.
    // Nota técnica: Var(G) ≠ Var(A) + Var(D) + Var(I) salvo si los componentes
    // son ortogonales. La verificación completa requiere: V_P = Var(A+D+I+E).
    let sumA_comp   = 0;   // Σ contribución aditiva pura (sin muBase, centrada)
    let sumD_comp   = 0;   // Σ contribución de dominancia
    let sumI_comp   = 0;   // Σ contribución de epistasis
    let sumE_comp   = 0;   // Σ error ambiental (residual)
    let sumSqA      = 0;   // Σ A²
    let sumSqD      = 0;   // Σ D²
    let sumSqI      = 0;   // Σ I²
    let sumSqE      = 0;   // Σ E²
    // Para covarianzas cruzadas (detectar no-ortogonalidad):
    let sumAD        = 0;  // Σ A×D
    let sumAI        = 0;  // Σ A×I
    let sumDI        = 0;  // Σ D×I

    // [F3-4] SCOPE C — Construir genoma MC una sola vez, fuera del loop
    // [EvidenceLayer] useQTL=true  → DEFAULT_GENOME (nombres reales, pos_cM reales)
    //                 useQTL=false → buildMCGenome sintético, spacingCM=50 (r≈0.432)
    //
    // [Fix v9.1.2] Bug anterior: buildMCGenome generaba nombres MC_C0_L0, MC_C0_L1…
    // La EpistasisMatrix tiene pares registrados con nombres reales (THCAS_1, TERP_MYR…).
    // computeI() buscaba por nombre y nunca encontraba coincidencias → totalI=0 siempre.
    // Fix: cuando useQTL=true pasar DEFAULT_GENOME directamente como mcGenome.
    // buildMCGenome() solo se invoca en el camino useQTL=false (genoma sintético L0/L1).
    const MC_SPACING_CM = useQTL ? 10 : 50;
    const mcGenome = useQTL
      ? DEFAULT_GENOME  // nombres reales → EpistasisMatrix.computeI() funciona
      : GenomicPolyploidEngine.buildMCGenome(
          nLoci, efectoAdit, domCoef, epiCoef,
          ['cannabinoids', 'terpenes', 'morphology'],
          MC_SPACING_CM
        );

    // [EvidenceLayer v9.1] useEpistasis=false → pasar instancia vacía para que
    // computeI() retorne totalI=0 y el modelo caiga al fallback de curvatura.
    // La instancia real EPISTASIS_MATRIX permanece intacta; solo se elige cuál pasar.
    const _activeEpiMatrix = useEpistasis ? EPISTASIS_MATRIX : new EpistasisMatrix();

    for (let i = 0; i < N; i++) {
      // ── [SCOPE C] Meiosis con strand tracking real ─────────────────────
      // [SJ-4] simulateLinkedMCIteration ahora retorna también totalI_matrix
      const { doseTrait, passCount, charOk, haploBonus, totalI_matrix } =
        v4.simulateLinkedMCIteration(mcGenome, g4, g2, alpha, minDose, _activeEpiMatrix,
                                     ploidyA, ploidyB, maxDoseLocus);

      // ── [SK-3] Scope K IIH inline MC accumulation ──────────────────────
      // [EvidenceLayer v9.1] useIIH=false (L0–L2): bloque omitido.
      // Sin mapa QTL con pos_cM reales los ancestorId son sintéticos y el
      // IIH no tiene significado biológico. Los acumuladores permanecen en 0.
      // HaplotypicBlockEngine, simulateMeiosis y extractBlocks sin modificar.
      if (useIIH) {
        const dam4xHP_mc  = ParentalHaplotype.fromUniform(g4);
        const sire2xHP_mc = ParentalHaplotype.fromUniform(g2);
        const chrResultsK_mc = mcGenome.map(chr => ({
          chrId:        chr.id,
          chrLength_cM: chr.length_cM,
          damGam:       v4.simulateMeiosis(chr, ploidyA, dam4xHP_mc,  alpha, 'dam'),
          sireGam:      v4.simulateMeiosis(chr, ploidyB, sire2xHP_mc, alpha, 'sire')
        }));
        const skRes = HaplotypicBlockEngine.computeIIH_global(chrResultsK_mc);
        iihSum         += skRes.IIH_global;
        iihBlockLenSum += skRes.meanBlockCM_global;
        iihRecombSum   += skRes.totalRecombEvents;
        if (i === N - 1) skLastResult = skRes; // guardar último para render
      }

      // ── Clasificación cualitativa ────────────────────────────────────
      if      (passCount === 3) allPass++;
      else if (passCount >= 1)  partial++;
      else                      nonePass++;

      for (let c = 0; c < 3; c++) {
        if (charOk[c]) charPass[c]++;
      }

      // [FASE 2] SDT por carácter para este individuo
      const sdtTrait = [
        doseTrait[0] / nLoci[0],
        doseTrait[1] / nLoci[1],
        doseTrait[2] / nLoci[2]
      ];
      sdtSumTrait[0] += sdtTrait[0];
      sdtSumTrait[1] += sdtTrait[1];
      sdtSumTrait[2] += sdtTrait[2];

      // [FASE 3] SDT Global Ponderado
      const weightedSDT =
        sdtTrait[0] * traitWeights[0] +
        sdtTrait[1] * traitWeights[1] +
        sdtTrait[2] * traitWeights[2];

      // Legacy SDT total (todos los loci, sin ponderar)
      const sdtDoseTotal = doseTrait[0] + doseTrait[1] + doseTrait[2];
      const sdt_i = sdtDoseTotal / totalLoci;
      if (sdt_i > 2.5 * maxDoseLocus / 3) sdtAbove++;

      // Fenotipo cuantitativo (carácter 1)
      // [SCOPE L] CORRECCIÓN: se separan los componentes A, D, I, E de forma
      // explícita para permitir la verificación de neutralidad de varianza.
      //
      // Modelo anterior (INCORRECTO — A y D mezclados):
      //   G_A = muBase + dosisTotal * efectoAdit * (1 + domCoef * normD)  ← mezcla A+D
      //
      // Modelo corregido (SCOPE L):
      //   A_comp = dosisTotal * efectoAdit                 (efecto aditivo puro)
      //   D_comp = dosisTotal * efectoAdit * domCoef*normD (desviación de dominancia)
      //   I_comp = epistasis real o fallback               (interacción epistática)
      //   E_comp = ruido ambiental N(0, sigmaE)            (residual ambiental)
      //   P = muBase + A_comp + D_comp + I_comp + E_comp
      const dosisTotal = doseTrait[0];
      const normD      = dosisTotal / (nLoci[0] * maxDoseLocus);

      // A: contribución aditiva pura (lineal en dosis)
      const A_comp = dosisTotal * efectoAdit;

      // D: desviación de dominancia (interacción dosis×domCoef)
      const D_comp = dosisTotal * efectoAdit * domCoef * normD;

      // I: epistasis real via EpistasisMatrix o fallback de curvatura
      // [SJ-4] totalI_matrix ya calculado por simulateLinkedMCIteration
      // [EvidenceLayer v9.1] _activeEpiMatrix es vacía cuando useEpistasis=false
      // → size=0 → cae al fallback de curvatura de dosis automáticamente.
      // EPISTASIS_MATRIX global permanece intacto; solo se consulta _activeEpiMatrix.
      const I_comp = _activeEpiMatrix.size > 0
        ? totalI_matrix
        : epiCoef * efectoAdit * normD * (1 - normD);

      // E: residual ambiental — N(0, sigmaE)
      const E_comp = _RNG.normal(0, sigmaE);

      const G = muBase + A_comp + D_comp + I_comp;
      const P = G + E_comp;
      fenotipos.push(P);
      sumP += P;

      // [SCOPE L] Acumular componentes para descomposición de varianza
      sumA_comp  += A_comp;
      sumD_comp  += D_comp;
      sumI_comp  += I_comp;
      sumE_comp  += E_comp;
      sumSqA     += A_comp * A_comp;
      sumSqD     += D_comp * D_comp;
      sumSqI     += I_comp * I_comp;
      sumSqE     += E_comp * E_comp;
      sumAD      += A_comp * D_comp;
      sumAI      += A_comp * I_comp;
      sumDI      += D_comp * I_comp;

      // ── [SCOPE H] haploBonus ya calculado en simulateLinkedMCIteration ──
      // No se necesita un segundo llamado a simulateMeiosis. El haploBonus
      // retornado por simulateLinkedMCIteration es coherente con doseTrait:
      // viene del mismo estado del PRNG y del mismo recorrido haplotípico.

      // [FASE 6] Puntuación final élite combinada
      // [EvidenceLayer v9.1] useIIH=false → haploBonus sintético no tiene
      // significado biológico. Se sustituye por 0.5 (valor neutro) para que
      // el ranking sea determinado exclusivamente por wSDT.
      // haploBonus original (del motor) permanece en elitePool para auditoría.
      const _effectiveHaploBonus = useIIH ? haploBonus : 0.5;
      const finalEliteScore = (weightedSDT * 0.8) + (_effectiveHaploBonus * 0.2);

      // [FASE 4] Registrar en elite pool
      elitePool.push({
        sdt:      weightedSDT,
        sdtRaw:   sdt_i,
        traits:   [...sdtTrait],
        phenotype: P,
        haploBonus,
        finalScore: finalEliteScore
      });
    }

    // [FASE 4] Ordenar por puntuación final descendente
    elitePool.sort((a, b) => b.finalScore - a.finalScore);

    // ── [SCOPE L] Descomposición de Varianza — Neutralidad ──────────────
    // Var(X) = E[X²] - E[X]² = (ΣX²/N) - (ΣX/N)²
    const meanA  = sumA_comp / N;
    const meanD  = sumD_comp / N;
    const meanI  = sumI_comp / N;
    const meanE  = sumE_comp / N;

    const V_A = (sumSqA / N) - meanA * meanA;
    const V_D = (sumSqD / N) - meanD * meanD;
    const V_I = (sumSqI / N) - meanI * meanI;
    const V_E = (sumSqE / N) - meanE * meanE;

    // Covarianzas cruzadas — deben ser ~0 si el modelo es ortogonal
    const Cov_AD = (sumAD / N) - meanA * meanD;
    const Cov_AI = (sumAI / N) - meanA * meanI;
    const Cov_DI = (sumDI / N) - meanD * meanI;

    // Suma de componentes incluyendo covarianzas (expansión de Var(A+D+I+E))
    // Var(A+D+I+E) = V_A + V_D + V_I + V_E + 2Cov(A,D) + 2Cov(A,I) + 2Cov(D,I)
    // (Cov con E ≈ 0 por construcción — E es independiente de G)
    const V_sum_components = V_A + V_D + V_I + V_E
      + 2 * Cov_AD + 2 * Cov_AI + 2 * Cov_DI;

    // V_G (varianza genotípica) sin componente ambiental
    const V_G_obs = V_A + V_D + V_I + 2 * Cov_AD + 2 * Cov_AI + 2 * Cov_DI;

    // ══ CONSOLE.LOG DE VERIFICACIÓN DE NEUTRALIDAD DE VARIANZA ══════════
    // Este log es el "circuito de verificación" exigido por la auditoría.
    // Si |ΔV_P| > 1% de V_P, el simulador tiene inconsistencia de modelo.
    console.log('');
    console.log('╔══════════════════════════════════════════════════════════════╗');
    console.log('║  SCOPE L — AUDITORÍA DE NEUTRALIDAD DE VARIANZA              ║');
    console.log('║  MSC PloidyEngine v9.0 · Verificación post-simulación        ║');
    console.log('╚══════════════════════════════════════════════════════════════╝');
    console.log(`  N simulado              = ${N.toLocaleString('es-MX')}`);
    console.log('  ─── Componentes de varianza ───────────────────────────────');
    console.log(`  V_A  (aditiva pura)     = ${V_A.toFixed(6)}`);
    console.log(`  V_D  (dominancia)       = ${V_D.toFixed(6)}`);
    console.log(`  V_I  (epistasis)        = ${V_I.toFixed(6)}`);
    console.log(`  V_E  (ambiental)        = ${V_E.toFixed(6)}`);
    console.log('  ─── Covarianzas cruzadas (ortogonalidad) ──────────────────');
    console.log(`  Cov(A,D)                = ${Cov_AD.toFixed(6)}  ${Math.abs(Cov_AD) > 0.01 * V_A ? '⚠ NO ORTOGONAL' : '✓ ok'}`);
    console.log(`  Cov(A,I)                = ${Cov_AI.toFixed(6)}  ${Math.abs(Cov_AI) > 0.01 * V_A ? '⚠ NO ORTOGONAL' : '✓ ok'}`);
    console.log(`  Cov(D,I)                = ${Cov_DI.toFixed(6)}  ${Math.abs(Cov_DI) > 0.01 * V_D ? '⚠ NO ORTOGONAL' : '✓ ok'}`);
    console.log('  ─── Verificación de neutralidad ───────────────────────────');
    const V_P_obs = (ss_placeholder_compute => ss_placeholder_compute)(() => {
      // V_P se recalcula abajo; aquí usamos el V_sum_components como aproximación
      return V_sum_components;
    })();
    console.log(`  V_A+V_D+V_I+V_E         = ${(V_A+V_D+V_I+V_E).toFixed(6)}  (sin covarianzas)`);
    console.log(`  Var(A+D+I+E) completa   = ${V_sum_components.toFixed(6)}  (con 2×Cov cruzadas)`);
    console.log('  [V_P observada se imprime después del cálculo de sigma]');
    console.log('  ─── Heredabilidad ─────────────────────────────────────────');
    console.log(`  h² INPUT (slider)       = ${heredab.toFixed(4)}`);
    console.log(`  h²_narrow (V_A/V_P)     = PENDIENTE (V_P se calcula abajo)`);
    console.log(`  V_G estimada            = ${V_G_obs.toFixed(6)}`);
    console.log('════════════════════════════════════════════════════════════════');

    // [FASE 5] Cortes por percentil
    const top1n  = Math.max(1, Math.floor(N * 0.01));
    const top5n  = Math.max(1, Math.floor(N * 0.05));
    const top10n = Math.max(1, Math.floor(N * 0.10));

    const top1Threshold  = elitePool[top1n  - 1]?.finalScore ?? 0;
    const top5Threshold  = elitePool[top5n  - 1]?.finalScore ?? 0;
    const top10Threshold = elitePool[top10n - 1]?.finalScore ?? 0;

    const bestIndividual = elitePool[0];
    const bestSDT        = bestIndividual?.finalScore ?? 0;
    const bestPheno      = bestIndividual?.phenotype  ?? 0;

    // [FASE 2] SDT medio por carácter
    const sdtMeanTrait = [
      sdtSumTrait[0] / N,
      sdtSumTrait[1] / N,
      sdtSumTrait[2] / N
    ];

    // [FASE 3] SDT ponderado medio poblacional
    const wsdtMean = sdtMeanTrait[0]*traitWeights[0]
                   + sdtMeanTrait[1]*traitWeights[1]
                   + sdtMeanTrait[2]*traitWeights[2];


    const mu = sumP / N;
    let ss = 0;
    fenotipos.forEach(p => { ss += (p - mu) ** 2; });
    const sigma = Math.sqrt(ss / N);
    const cv    = (sigma / mu) * 100;

    // ── [SCOPE L] Segunda fase del console.log — con V_P real ───────────
    {
      const V_P_real   = ss / N;
      const delta_abs  = Math.abs(V_sum_components - V_P_real);
      const delta_pct  = (delta_abs / V_P_real) * 100;
      const h2_narrow  = V_A / V_P_real;
      const h2_broad   = V_G_obs / V_P_real;
      const status     = delta_pct < 1 ? '✓ NEUTRALIDAD VERIFICADA'
                       : delta_pct < 5 ? '⚠ DISCREPANCIA MODERADA'
                       : '✗ FALLA DE NEUTRALIDAD';

      console.log('');
      console.log('╔══════════════════════════════════════════════════════════════╗');
      console.log('║  SCOPE L — RESULTADO FINAL: NEUTRALIDAD DE VARIANZA          ║');
      console.log('╚══════════════════════════════════════════════════════════════╝');
      console.log(`  V_P observada (σ²)      = ${V_P_real.toFixed(6)}`);
      console.log(`  Var(A+D+I+E) calculada  = ${V_sum_components.toFixed(6)}`);
      console.log(`  |ΔV_P| absoluto         = ${delta_abs.toFixed(6)}`);
      console.log(`  |ΔV_P| relativo         = ${delta_pct.toFixed(3)}%  ${status}`);
      console.log('  ─── Heredabilidades ────────────────────────────────────────');
      console.log(`  h² INPUT  (slider)      = ${heredab.toFixed(4)}`);
      console.log(`  h²_narrow (V_A/V_P)     = ${h2_narrow.toFixed(4)}  ${Math.abs(h2_narrow - heredab) > 0.05 ? '⚠ DIVERGE del input' : '✓ coherente'}`);
      console.log(`  h²_broad  (V_G/V_P)     = ${h2_broad.toFixed(4)}`);
      console.log(`  Δh²_narrow vs input     = ${Math.abs(h2_narrow - heredab).toFixed(4)}`);
      console.log('  ─── Proporciones de V_P ────────────────────────────────────');
      console.log(`  V_A / V_P               = ${(V_A/V_P_real*100).toFixed(2)}%`);
      console.log(`  V_D / V_P               = ${(V_D/V_P_real*100).toFixed(2)}%`);
      console.log(`  V_I / V_P               = ${(V_I/V_P_real*100).toFixed(2)}%`);
      console.log(`  V_E / V_P               = ${(V_E/V_P_real*100).toFixed(2)}%`);
      console.log(`  2×Cov/V_P               = ${((2*Cov_AD+2*Cov_AI+2*Cov_DI)/V_P_real*100).toFixed(2)}%`);
      console.log(`  SUMA                    = ${((V_A+V_D+V_I+V_E+2*Cov_AD+2*Cov_AI+2*Cov_DI)/V_P_real*100).toFixed(2)}%  (debe ser ≈ 100%)`);
      console.log('════════════════════════════════════════════════════════════════');
      console.log('');

      // Guardar en objeto global para renderizado en UI
      window._SL_VARIANCE_AUDIT = {
        V_P: V_P_real, V_A, V_D, V_I, V_E, V_G: V_G_obs,
        Cov_AD, Cov_AI, Cov_DI,
        V_sum: V_sum_components,
        delta_abs, delta_pct,
        h2_input: heredab, h2_narrow, h2_broad,
        N, status,
        ok: delta_pct < 1
      };
    }

    // [SK-4] IIH poblacional
    const iihMean        = iihSum / N;
    const iihMeanBlockCM = iihBlockLenSum / N;
    const iihMeanRecomb  = iihRecombSum / N;
    const totalLoci_all  = nLoci.reduce((a, b) => a + b, 0);

    const cvCls = cv < 10 ? 'ok' : cv < 20 ? 'warn' : 'bad';
    const cvLbl = cv < 10 ? 'GRADO FARMACÉUTICO' : cv < 20 ? 'VARIABILIDAD MODERADA' : 'HETEROGÉNEO';
    const cvCol = cv < 10 ? 'green' : cv < 20 ? 'warn' : 'danger';

    const sorted = fenotipos.slice().sort((a, b) => a - b);
    const p5  = sorted[Math.floor(N * 0.05)];
    const p95 = sorted[Math.floor(N * 0.95)];

    $('quantGrid').innerHTML = `
      <div class="quant-card highlight">
        <div class="q-num green">${mu.toFixed(2)}%</div>
        <div class="q-lab">MEDIA POBLACIONAL (μ)</div>
      </div>
      <div class="quant-card">
        <div class="q-num">${sigma.toFixed(2)}</div>
        <div class="q-lab">DESVIACIÓN ESTÁNDAR (σ)</div>
      </div>
      <div class="quant-card cv-${cvCls}">
        <div class="q-num ${cvCol}">${cv.toFixed(2)}%</div>
        <div class="q-lab">COEFICIENTE DE VARIACIÓN</div>
        <div class="cv-badge ${cvCls}">${cvLbl}</div>
      </div>
      <div class="quant-card">
        <div class="q-num">${p5.toFixed(1)}–${p95.toFixed(1)}</div>
        <div class="q-lab">RANGO P5–P95 (%)</div>
      </div>`;

    renderHistogram(fenotipos, mu, sigma);

    const allP  = allPass / N;
    const partP = partial / N;
    const noneP = nonePass / N;
    const sdtP  = sdtAbove / N; // [Scope-D] fracción con SDT > 2.5

    $('resultsGrid').innerHTML = `
      <div class="res-card highlight">
        <div class="res-num green">${(allP*100).toFixed(1)}%</div>
        <div class="res-lab">TRIPLE CONFORMES</div>
      </div>
      <div class="res-card">
        <div class="res-num warn">${(partP*100).toFixed(1)}%</div>
        <div class="res-lab">CONFORMES PARCIALES</div>
      </div>
      <div class="res-card">
        <div class="res-num">${(noneP*100).toFixed(1)}%</div>
        <div class="res-lab">DESCARTADOS</div>
      </div>
      <div class="res-card" style="border-color:#ffd700;background:rgba(255,215,0,.06);">
        <div class="res-num" style="color:#ffd700;">${top1n.toLocaleString('es-MX')}</div>
        <div class="res-lab">TOP 1% ÉLITE (n)</div>
        <div class="sdt-badge" style="background:rgba(255,215,0,.15);color:#ffd700;border-color:#ffd700;">SCORE FINAL</div>
      </div>
      <div class="res-card sdt">
        <div class="res-num blue">${wsdtMean.toFixed(3)}</div>
        <div class="res-lab">wSDT MEDIO PONDERADO</div>
        <div class="sdt-badge">FASES 2–3</div>
      </div>`;

    $('barChart').innerHTML = `
      <div class="bar-block">
        <div class="bar-meta"><span>Triple conformes</span><span>${(allP*100).toFixed(2)}%</span></div>
        <div class="bar-track"><div class="bar-fill all" style="width:${Math.max(allP*100,0.3)}%"></div></div>
      </div>
      <div class="bar-block">
        <div class="bar-meta"><span>Conformes parciales (≥1 carácter)</span><span>${(partP*100).toFixed(2)}%</span></div>
        <div class="bar-track"><div class="bar-fill partial" style="width:${Math.max(partP*100,0.3)}%"></div></div>
      </div>
      <div class="bar-block">
        <div class="bar-meta"><span>Descartados (0 caracteres)</span><span>${(noneP*100).toFixed(2)}%</span></div>
        <div class="bar-track"><div class="bar-fill none" style="width:${Math.max(noneP*100,0.3)}%"></div></div>
      </div>
      <div class="bar-block">
        <div class="bar-meta"><span>wSDT medio ponderado (escala 0–${maxDoseLocus})</span><span>${(wsdtMean/maxDoseLocus*100).toFixed(2)}%</span></div>
        <div class="bar-track"><div class="bar-fill sdt" style="width:${Math.max(wsdtMean/maxDoseLocus*100,0.3)}%"></div></div>
      </div>`;

    // [SM-6] P(dosis ≥ minDose) desde la distribución genérica
    const pLocusAdj = zyg.dist.reduce((acc, p, d) => acc + (d >= minDose ? p : 0), 0);
    // totalLoci ya declarado antes del loop — no se redeclara
    const pTheo     = Math.pow(pLocusAdj, totalLoci);

    // Panel SDT legacy + wSDT resumen
    const sdtCls = sdtP >= 0.5 ? 'ok' : sdtP >= 0.2 ? 'warn' : 'bad';
    const sdtLbl = sdtP >= 0.5 ? 'ALTA DOSIFICACIÓN' : sdtP >= 0.2 ? 'DOSIFICACIÓN MODERADA' : 'BAJA DOSIFICACIÓN';
    $('sdtMetric').innerHTML = `
      <div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:12px 14px;">
        <div style="font-size:9px;color:var(--muted);letter-spacing:.08em;font-weight:700;margin-bottom:6px;">
          SDT LEGACY (umbral > 2.5, sin ponderar) — SCOPE D
        </div>
        <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
          <div style="text-align:center;min-width:80px;">
            <div style="font-size:22px;font-weight:700;color:var(--muted);">${(sdtP*100).toFixed(2)}%</div>
            <div style="font-size:9px;color:var(--muted);margin-top:2px;">POBLACIÓN SDT &gt; 2.5</div>
          </div>
          <div style="flex:1;min-width:160px;">
            <div style="font-size:9px;color:var(--muted);margin-bottom:3px;">
              n = ${sdtAbove.toLocaleString('es-MX')} ind. SDT &gt; 2.5 de N = ${N.toLocaleString('es-MX')} &nbsp;·&nbsp;
              <span style="color:var(--accent2)">Ver ranking ponderado (Fases 2–5) ↓</span>
            </div>
            <div class="bar-track" style="height:8px;">
              <div class="bar-fill sdt" style="width:${Math.max(sdtP*100,0.3)}%;opacity:.5;transition:width .6s ease;"></div>
            </div>
          </div>
          <div><div class="cv-badge ${sdtCls}" style="font-size:9px;">${sdtLbl}</div></div>
        </div>
      </div>`;

    $('lociGrid').innerHTML = ['Carácter 1 — Resina','Carácter 2 — Vigor','Carácter 3 — Estructura'].map((name, i) => {
      const p = charPass[i] / N;
      return `<div class="locus-card">
        <div class="locus-title">${name} — ${nLoci[i]} loci | dosis ≥${minDose}</div>
        <div class="locus-pct">${(p*100).toFixed(2)}%</div>
        <div class="bar-track"><div class="bar-fill all" style="width:${Math.max(p*100,0.3)}%"></div></div>
      </div>`;
    }).join('');

    // [FASE 2] — Renderizar SDT medio por carácter
    const traitNames  = ['RESINA (C1)', 'VIGOR (C2)', 'ESTRUCTURA (C3)'];
    const traitClasses = ['resin', 'vigor', 'struct'];
    $('sdtTraitsGrid').innerHTML = traitNames.map((name, i) => {
      const v = sdtMeanTrait[i];
      const pct_bar = ((v / maxDoseLocus) * 100).toFixed(1);
      return `<div class="sdt-trait-card ${traitClasses[i]}">
        <div class="sdt-trait-lab">SDT MEDIO ${name}</div>
        <div class="sdt-trait-num ${traitClasses[i]}">${v.toFixed(3)}</div>
        <div class="sdt-trait-lab" style="margin-top:2px;">de ${maxDoseLocus.toFixed(3)} máx · peso ${(traitWeights[i]*100).toFixed(0)}%</div>
        <div class="sdt-trait-bar"><div class="sdt-trait-bar-fill ${traitClasses[i]}" style="width:${pct_bar}%"></div></div>
      </div>`;
    }).join('');

    // [FASE 3] — Panel SDT Global Ponderado
    const wsdtBarPct = ((wsdtMean / maxDoseLocus) * 100).toFixed(1);
    const wsdtCls = wsdtMean >= 2.2 * maxDoseLocus / 3 ? 'ok' : wsdtMean >= 1.5 * maxDoseLocus / 3 ? 'warn' : 'bad';
    const wsdtLbl = wsdtMean >= 2.2 * maxDoseLocus / 3 ? 'ÉLITE GENÉTICO' : wsdtMean >= 1.5 * maxDoseLocus / 3 ? 'SELECCIÓN MODERADA' : 'BAJA DOSIFICACIÓN';
    $('wsdtPanel').innerHTML = `
      <div class="wsdt-panel">
        <div class="wsdt-header">wSDT — SCORE DE DOSIFICACIÓN PONDERADO · FASES 2–3</div>
        <div class="wsdt-main">
          <div style="text-align:center;min-width:90px;">
            <div class="wsdt-num">${wsdtMean.toFixed(3)}</div>
            <div style="font-size:9px;color:var(--muted);margin-top:2px;">wSDT POBLACIONAL</div>
            <div class="cv-badge ${wsdtCls}" style="font-size:8px;margin-top:4px;">${wsdtLbl}</div>
          </div>
          <div class="wsdt-detail">
            <div class="wsdt-formula">
              wSDT = SDT<sub>C1</sub>×${(traitWeights[0]*100).toFixed(0)}%
              + SDT<sub>C2</sub>×${(traitWeights[1]*100).toFixed(0)}%
              + SDT<sub>C3</sub>×${(traitWeights[2]*100).toFixed(0)}%
              = ${(sdtMeanTrait[0]*traitWeights[0]).toFixed(3)}
              + ${(sdtMeanTrait[1]*traitWeights[1]).toFixed(3)}
              + ${(sdtMeanTrait[2]*traitWeights[2]).toFixed(3)}
            </div>
            <div class="bar-track" style="height:11px;">
              <div class="bar-fill sdt" style="width:${Math.max(parseFloat(wsdtBarPct),0.3)}%;transition:width .6s ease;"></div>
            </div>
            <div style="font-size:9px;color:var(--muted);margin-top:4px;">
              Rango [0–3] · Top 1%: wSDT ≥ ${elitePool[top1n-1]?.sdt.toFixed(3) ?? '—'}
              &nbsp;|&nbsp; Top 5%: ≥ ${elitePool[top5n-1]?.sdt.toFixed(3) ?? '—'}
              &nbsp;|&nbsp; Top 10%: ≥ ${elitePool[top10n-1]?.sdt.toFixed(3) ?? '—'}
            </div>
          </div>
          <div>
            <div style="font-size:9px;color:var(--muted);margin-bottom:6px;">MEJOR OBSERVADO</div>
            <div style="font-size:20px;font-weight:700;color:#ffd700;">${bestSDT.toFixed(3)}</div>
            <div style="font-size:9px;color:var(--muted);">wSDT + haplo</div>
            <div style="font-size:14px;font-weight:700;color:var(--accent);margin-top:4px;">${bestPheno.toFixed(2)}%</div>
            <div style="font-size:9px;color:var(--muted);">fenotipo</div>
          </div>
        </div>
      </div>`;

    // [FASE 5] — Tarjetas de élites por percentil
    $('eliteGrid').innerHTML = `
      <div class="elite-card top1">
        <div class="elite-num gold">${top1n.toLocaleString('es-MX')}</div>
        <div class="elite-lab">INDIVIDUOS TOP 1%</div>
        <div class="elite-badge gold">ÉLITE ABSOLUTA</div>
        <div style="font-size:9px;color:var(--muted);margin-top:5px;">wSDT ≥ ${elitePool[top1n-1]?.finalScore.toFixed(3) ?? '—'}</div>
      </div>
      <div class="elite-card top5">
        <div class="elite-num green">${top5n.toLocaleString('es-MX')}</div>
        <div class="elite-lab">INDIVIDUOS TOP 5%</div>
        <div class="elite-badge green">SUPERIOR</div>
        <div style="font-size:9px;color:var(--muted);margin-top:5px;">wSDT ≥ ${elitePool[top5n-1]?.finalScore.toFixed(3) ?? '—'}</div>
      </div>
      <div class="elite-card top10">
        <div class="elite-num blue">${top10n.toLocaleString('es-MX')}</div>
        <div class="elite-lab">INDIVIDUOS TOP 10%</div>
        <div class="elite-badge blue">SELECCIÓN</div>
        <div style="font-size:9px;color:var(--muted);margin-top:5px;">wSDT ≥ ${elitePool[top10n-1]?.finalScore.toFixed(3) ?? '—'}</div>
      </div>
      <div class="elite-card best">
        <div class="elite-num orange">${bestSDT.toFixed(3)}</div>
        <div class="elite-lab">MEJOR wSDT OBSERVADO</div>
        <div style="font-size:8px;color:var(--muted);margin-top:5px;">Haplo: ${useIIH ? (bestIndividual?.haploBonus*100).toFixed(0)+'%' : '<span style="color:var(--border)">N/D</span>'} · P: ${bestPheno.toFixed(2)}%</div>
      </div>
      <div class="elite-card" style="border-color:var(--accent2);background:rgba(0,184,255,.06);">
        <div class="elite-num blue">${sdtMeanTrait[0].toFixed(3)}</div>
        <div class="elite-lab">SDT MEDIO RESINA</div>
        <div style="font-size:9px;color:var(--muted);margin-top:5px;">C1 · peso ${(traitWeights[0]*100).toFixed(0)}%</div>
      </div>
      <div class="elite-card" style="border-color:var(--accent);background:var(--accent-glow);">
        <div class="elite-num green">${sdtMeanTrait[1].toFixed(3)}</div>
        <div class="elite-lab">SDT MEDIO VIGOR</div>
        <div style="font-size:9px;color:var(--muted);margin-top:5px;">C2 · peso ${(traitWeights[1]*100).toFixed(0)}%</div>
      </div>
      <div class="elite-card" style="border-color:var(--accent3);background:rgba(255,107,53,.06);">
        <div class="elite-num orange">${sdtMeanTrait[2].toFixed(3)}</div>
        <div class="elite-lab">SDT MEDIO ESTRUCTURA</div>
        <div style="font-size:9px;color:var(--muted);margin-top:5px;">C3 · peso ${(traitWeights[2]*100).toFixed(0)}%</div>
      </div>
      <div class="elite-card" style="border-color:var(--ok);background:rgba(63,185,80,.06);">
        <div class="elite-num" style="color:var(--ok);">${bestPheno.toFixed(2)}%</div>
        <div class="elite-lab">MEJOR FENOTIPO OBSERVADO</div>
        <div style="font-size:9px;color:var(--muted);margin-top:5px;">Carácter 1 — Rendimiento</div>
      </div>`;

    // [FASE 5] — Tabla ranking de los mejores 20 individuos
    const RANK_SHOW = Math.min(20, elitePool.length);
    const rankRows = elitePool.slice(0, RANK_SHOW).map((ind, idx) => {
      const rank = idx + 1;
      const pctRank = ((rank / N) * 100).toFixed(2);
      let posClass = rank === 1 ? 'p1' : rank <= top1n ? 'p1' : rank <= top5n ? 'p5' : rank <= top10n ? 'p10' : 'rest';
      let tagHTML = '';
      if (rank === 1)            tagHTML = `<span class="rank-tag top1">🏆 #1</span>`;
      else if (rank <= top1n)    tagHTML = `<span class="rank-tag top1">TOP 1%</span>`;
      else if (rank <= top5n)    tagHTML = `<span class="rank-tag top5">TOP 5%</span>`;
      else if (rank <= top10n)   tagHTML = `<span class="rank-tag top10">TOP 10%</span>`;
      return `<tr>
        <td><span class="rank-pos ${posClass}">${rank}</span> ${tagHTML}</td>
        <td class="rank-sdt">${ind.finalScore.toFixed(4)}</td>
        <td class="rank-sdt" style="color:var(--accent)">${ind.sdt.toFixed(4)}</td>
        <td style="color:var(--accent)">${ind.traits[0].toFixed(3)}</td>
        <td style="color:var(--accent2)">${ind.traits[1].toFixed(3)}</td>
        <td style="color:var(--accent3)">${ind.traits[2].toFixed(3)}</td>
        <td class="rank-pheno">${ind.phenotype.toFixed(2)}%</td>
        <td style="color:var(--muted)">${useIIH ? (ind.haploBonus*100).toFixed(0)+'%' : '<span style="opacity:.4">N/D</span>'}</td>
        <td style="color:var(--muted)">P${pctRank}</td>
      </tr>`;
    }).join('');
    $('eliteRankTable').innerHTML = `
      <div class="rank-wrap">
        <table class="rank-table">
          <thead><tr>
            <th>RANGO</th>
            <th>SCORE FINAL</th>
            <th>wSDT</th>
            <th>SDT C1</th>
            <th>SDT C2</th>
            <th>SDT C3</th>
            <th>FENOTIPO</th>
            <th>HAPLO%</th>
            <th>PERCENTIL</th>
          </tr></thead>
          <tbody>${rankRows}</tbody>
        </table>
      </div>
      <div style="font-size:9px;color:var(--muted);margin-top:6px;">
        Score Final = wSDT×0.8 + HaploBonus×0.2 &nbsp;·&nbsp;
        Mostrando top ${RANK_SHOW} de ${N.toLocaleString('es-MX')} individuos simulados.
      </div>`;
    // [EvidenceLayer v9.1] Status line con indicador useQTL
    $('statusLine').innerHTML =
      `v9.1-EL &nbsp;|&nbsp; ` +
      `<strong style="color:${useQTL?'var(--accent)':'var(--muted)'}">` +
        `${useQTL ? '◉ QTL ON' : '○ QTL OFF'} (L${EL_ACTIVE_LEVEL})</strong> &nbsp;|&nbsp; ` +
      `N=${N.toLocaleString('es-MX')} &nbsp;|&nbsp; α=${alpha.toFixed(4)} &nbsp;|&nbsp; ` +
      `Biv=${(biv*100).toFixed(0)}% Quad=${(quad*100).toFixed(0)}% &nbsp;|&nbsp; ` +
      `h²=${heredab.toFixed(2)} &nbsp;|&nbsp; σ_E=${sigmaE.toFixed(3)} &nbsp;|&nbsp; ` +
      `P(locus ok)=${pct(pLocusAdj)} &nbsp;|&nbsp; P teórica triple=<strong>${pct(pTheo)}</strong> &nbsp;|&nbsp; ` +
      `wSDT=<strong style="color:var(--accent2)">${wsdtMean.toFixed(3)}</strong> &nbsp;|&nbsp; ` +
      `EpiPares=<strong style="color:var(--accent3)">${EPISTASIS_MATRIX.size}</strong> &nbsp;|&nbsp; ` +
      (useIIH
        ? `IIH=<strong style="color:${iihMean>=.75?'var(--accent)':iihMean>=.50?'var(--warn)':'var(--danger)'};">${(iihMean*100).toFixed(1)}%</strong>`
        : `IIH=<span style="color:var(--muted);">N/D (L${EL_ACTIVE_LEVEL})</span>`) +
      ` &nbsp;|&nbsp; ` +
      `Top1%=${top1n} ind &nbsp;|&nbsp; Seed: <strong>${SIM_SEED}</strong>`;

    // [SK-5] Render IIH inline card in Simulación tab
    // [EvidenceLayer v9.1] Solo renderizar IIH si useIIH está activo.
    // Sin mapa QTL real el IIH no es interpretable — mostrar mensaje.
    if (useIIH) {
      renderIIHInline(iihMean, iihMeanBlockCM, iihMeanRecomb);
    } else {
      $("iihInlineCard").innerHTML =
        '<div style="font-size:10px;color:var(--muted);padding:10px 0;">' +
        '<span style="color:var(--border);">◎</span> ' +
        '<strong style="color:var(--muted);">Scope K — No disponible en este nivel de evidencia</strong><br>' +
        '<span style="font-size:9px;">El IIH real requiere mapa genómico denso con posiciones cM (Nivel 3). ' +
        'Sin él, los ancestorId son sintéticos y los bloques haplotípicos no tienen ' +
        'significado biológico.</span></div>';
    }

    // [SK-6] Render full Scope K trazabilidad tab
    // [EvidenceLayer v9.1] Mismo criterio: solo si useIIH activo.
    if (useIIH) {
      const driftGens = HaplotypicBlockEngine.predictGenerationalDrift(
        iihMean, totalLoci_all, 0.091
      );
      renderScopeKTab(iihMean, iihMeanBlockCM, iihMeanRecomb, skLastResult, driftGens, alpha, N);
    } else {
      // Mensaje "No disponible" en el tab TRAZABILIDAD K completo
      const _naMsg =
        '<div style="padding:32px 20px;text-align:center;">' +
        '<div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-bottom:12px;">' +
        '◎ SCOPE K — NO DISPONIBLE EN ESTE NIVEL DE EVIDENCIA</div>' +
        '<div style="font-size:10px;color:var(--muted);max-width:480px;margin:0 auto;line-height:1.7;">' +
        'La Integridad Haplotípica (IIH) requiere:<br>' +
        '<span style="color:var(--text);">① Mapa genómico con posiciones cM reales (Nivel 2+)</span><br>' +
        '<span style="color:var(--text);">② Densidad de marcadores inter-QTL (Nivel 3)</span><br><br>' +
        'Sin estos datos, los bloques haplotípicos calculados reflejarían solo' +
        ' el espaciado sintético del genoma MC y no tendrían interpretación biológica.' +
        '<br><br><span style="color:var(--accent);font-weight:700;">Activa Nivel 3 → Genómico Completo</span>' +
        ' para habilitar IIH, mapa de bloques y predicción de deriva generacional.</div></div>';
      // Limpiar todos los contenedores del tab K
      const _kContainers = [
        "iihHeroDisplay","iihBlockMapDisplay","iihRecombLogDisplay",
        "iihDriftDisplay","iihPerChromDisplay"
      ];
      _kContainers.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = _naMsg;
      });
      // Limpiar SK_STATE para no mostrar datos obsoletos
      SK_STATE = null;
    }

    // [SJ-5] Render breakdown de la EpistasisMatrix post-simulación
    // [EvidenceLayer v9.1] Solo muestra pares si useEpistasis está activo.
    // EPISTASIS_MATRIX permanece intacta; el display refleja el nivel de evidencia.
    const epiPairs = useEpistasis ? EPISTASIS_MATRIX.list() : [];
    if (epiPairs.length > 0) {
      $('epiBreakdownDisplay').innerHTML = `
        <div class="epi-matrix-wrap" style="border-color:var(--accent3);">
          <div class="epi-matrix-head">
            <span>📊 SCOPE J — PARES EPISTÁTICOS ACTIVOS EN ESTA SIMULACIÓN</span>
            <span style="color:var(--muted);font-size:9px;">${epiPairs.length} interacciones inter-loci</span>
          </div>
          <div style="display:grid;gap:4px;">
            ${epiPairs.map(p => {
              const sign = p.Iij >= 0 ? '+' : '';
              const col  = p.Iij >= 0 ? 'var(--ok)' : 'var(--danger)';
              return `<div style="display:flex;align-items:center;gap:10px;font-size:10px;padding:4px 8px;background:var(--surface2);border-radius:4px;">
                <span style="color:var(--accent3);font-weight:700;">${p.locusA}</span>
                <span style="color:var(--muted);">×</span>
                <span style="color:var(--accent3);font-weight:700;">${p.locusB}</span>
                <span class="epi-type-badge ${p.type}">${p.type==='syn'?'SIN':'ANT'}</span>
                <span style="color:${col};font-weight:700;margin-left:auto;">I = ${sign}${p.Iij.toFixed(3)}</span>
                <span style="color:var(--muted);font-size:9px;">
                  → ΔG per ind ≈ ${sign}${(Math.abs(p.Iij)*0.5*0.5).toFixed(4)} (a dosis media)
                </span>
              </div>`;
            }).join('')}
          </div>
        </div>`;
    } else {
      $('epiBreakdownDisplay').innerHTML = `<div style="font-size:9px;color:var(--muted);padding:4px 0;">
        Scope J: sin pares epistáticos configurados. Usando fallback de curvatura de dosis (epiCoef global).
      </div>`;
    }

    SIM_COUNT++;
    $('hstatSims').textContent = SIM_COUNT;
    const simRecord = {
      id: SIM_COUNT,
      date: new Date().toISOString(),
      version: '10.2.0-PloidyGen',
      seed: SIM_SEED,
      cross: `${ploidyA}x(g${g4}) × ${ploidyB}x(g${g2})`,
      alpha: alpha.toFixed(4),
      pairing: { bivalent: biv, quadrivalent: quad },
      loci: nLoci, minDose, N,
      traitWeights: traitWeights.map(w => w.toFixed(3)),
      epistasisMatrix: EPISTASIS_MATRIX.list().map(p => ({
        locusA: p.locusA, locusB: p.locusB,
        Iij: p.Iij.toFixed(4), type: p.type
      })),
      prediction: {
        mu: mu.toFixed(3), sigma: sigma.toFixed(3),
        cv: cv.toFixed(3), eliteP: (allP*100).toFixed(2),
        pTheo: pct(pTheo),
        sdtAbove: (sdtP*100).toFixed(2),
        wsdtMean: wsdtMean.toFixed(3),
        sdtMeanTrait: sdtMeanTrait.map(v=>v.toFixed(3)),
        top1n, top5n, top10n,
        bestScore: bestSDT.toFixed(4),
        bestPheno: bestPheno.toFixed(2)
      },
      observed: null, error: null, modelAccuracy: null
    };
    simLibrary.push(simRecord);
    saveLibrary(); // [Scope G] Persistencia automática
    SIM_STATE = { mu, sigma, cv, allP, N, simRecord, wsdtMean, sdtMeanTrait, elitePool, top1n, top5n, top10n };

    renderLibrary();
    renderAuditLog();
    renderVarianceAudit(); // [SCOPE L] Descomposición de varianza
    renderEpistasisMatrix(); // [SJ-5] refrescar contadores

    btn.classList.remove('running');
    btn.textContent = '▶ EJECUTAR SIMULACIÓN GENÓMICA';
  }, 20);
}
