
// ─── SCOPE J — UI: Gestión de la Matriz Epistática ─────────────────

// Renderizar la lista de pares epistáticos configurados
function renderEpistasisMatrix() {
  const pairs = EPISTASIS_MATRIX.list();
  const listEl = $('epiPairList');

  if (pairs.length === 0) {
    listEl.innerHTML = `<div style="font-size:10px;color:var(--muted);padding:6px 2px;">
      Sin pares configurados — la epistasis usará fallback de curvatura de dosis (epiCoef global).
    </div>`;
  } else {
    listEl.innerHTML = pairs.map((p, idx) => {
      const typeCls  = p.type === 'syn' ? 'syn' : 'ant';
      const typeLabel = p.type === 'syn' ? 'SIN (+)' : 'ANT (−)';
      const sign     = p.type === 'syn' ? '+' : '−';
      const sliderId = `epiSlider_${idx}`;
      const valId    = `epiVal_${idx}`;
      return `<div class="epi-pair-row" id="epiRow_${idx}">
        <span class="epi-pair-label">
          <span>${p.locusA}</span>
          <span style="color:var(--muted);margin:0 6px;">×</span>
          <span>${p.locusB}</span>
        </span>
        <span class="epi-type-badge ${typeCls}">${typeLabel}</span>
        <div class="epi-pair-coef">
          <label>I_{i,j}:</label>
          <input type="range" id="${sliderId}"
            min="0" max="100" step="1"
            value="${Math.round(Math.abs(p.Iij) * 100)}"
            oninput="updateEpistasisCoef('${p.locusA}','${p.locusB}','${p.type}',${idx})">
          <span class="epi-pair-val" id="${valId}">${sign}${Math.abs(p.Iij).toFixed(2)}</span>
        </div>
        <button class="epi-del-btn"
          onclick="deleteEpistasisPair('${p.locusA}','${p.locusB}')">✕</button>
      </div>`;
    }).join('');
  }

  // Actualizar contadores en el panel
  const nSyn = pairs.filter(p => p.type === 'syn').length;
  const nAnt = pairs.filter(p => p.type === 'ant').length;
  $('epiNPairs').textContent   = pairs.length;
  $('epiNSyn').textContent     = nSyn;
  $('epiNAnt').textContent     = nAnt;
  $('epiMatrixStatus').textContent = pairs.length === 0
    ? '0 pares activos'
    : `${pairs.length} par${pairs.length > 1 ? 'es' : ''} activo${pairs.length > 1 ? 's' : ''} · ${nSyn} sinérgico${nSyn!==1?'s':''} · ${nAnt} antagónico${nAnt!==1?'s':''}`;
}

// Agregar nuevo par epistático desde la UI
function addEpistasisPair() {
  const locA  = $('epiLocusA').value;
  const locB  = $('epiLocusB').value;
  const type  = $('epiType').value;

  if (locA === locB) {
    alert('⚠ Selecciona dos loci distintos para definir una interacción epistática.');
    return;
  }
  if (EPISTASIS_MATRIX.get(locA, locB)) {
    alert(`ℹ El par ${locA} × ${locB} ya está configurado. Usa el slider para ajustar I_{i,j}.`);
    return;
  }

  // Coeficiente inicial: 0.50 (moderado)
  const Iij = type === 'syn' ? 0.50 : -0.50;
  EPISTASIS_MATRIX.set(locA, locB, Iij, type);
  $('epiLastI').textContent = `${Iij > 0 ? '+' : ''}${Iij.toFixed(2)}`;
  renderEpistasisMatrix();
}

// Actualizar coeficiente I_{i,j} desde slider
function updateEpistasisCoef(locA, locB, type, idx) {
  const slider = $(`epiSlider_${idx}`);
  const valEl  = $(`epiVal_${idx}`);
  const raw    = parseInt(slider.value) / 100;
  const Iij    = type === 'syn' ? raw : -raw;
  EPISTASIS_MATRIX.set(locA, locB, Iij, type);
  const sign = Iij >= 0 ? '+' : '−';
  valEl.textContent = `${sign}${raw.toFixed(2)}`;
  $('epiLastI').textContent = `${Iij >= 0 ? '+' : ''}${Iij.toFixed(2)}`;
}

// Eliminar par de la matriz
function deleteEpistasisPair(locA, locB) {
  EPISTASIS_MATRIX.delete(locA, locB);
  renderEpistasisMatrix();
}
