
// ═══════════════════════════════════════════════════════════════════
//  MSC PloidyEngine v10.2.0 — SCOPE M: PloidyGen
//  [v10.2] simulateMeiosis 4x: (a) asignación aleatoria de alelos a cromátidas
//         por meiosis (bivalentes aleatorios) → marginales = Mather con α=0;
//         (b) doble reducción = cromátidas hermanas del mismo cromosoma
//         (activeB = activeA), no dos cromosomas distintos.
//         NO es bit-idéntico a v10.1 en rutas 4x (cambia la secuencia RNG).
//  [v10.2] Selector de dosis mínima limitado a 1..maxDoseLocus.
//  --- v10.1.0 ---
//  Extiende v9.2.0 (Evidence Layer Audit)
//
//  CAMBIOS v10.1.0 (SCOPE M — cruces generalizados 2x/4x × 2x/4x):
//  [SM-1] GAMETE_COPIES + MeiosisEngine.renderAlleleState/gameteDist/zygoteDist
//  [SM-2] buildLocusGenotype(): nDamCopies/nSireCopies explícitos
//         (4x×2x y 2x×4x comparten maxDoseLocus=3 → no inferible)
//  [SM-3] D_contrib = dominance·effect·dose/maxDoseLocus (sin switch)
//  [SM-4] EpistasisMatrix.computeI(locusResults, maxDoseLocus)
//  [SM-5] simulateLinkedMCIteration / generateTriploidZygote: ploidyA/B, maxDoseLocus
//  [SM-6] runMonteCarlo(): lee parA-ploidy/parB-ploidy; escalas wSDT y normD
//         relativas a maxDoseLocus
//  [SM-7] updateParentalGenoOptions(), renderAnalytics() genérico
//  [SM-8] HaplotypicBlockEngine.setCrossContext(): IIH ponderado por copias
//  [SM-9] simulateMeiosis(..., role): origin/ancestorId por rol (dam/sire)
//  Regresión: 4x×2x + misma semilla ⇒ idéntico a v9.2.0.
//
//  [Histórico v8.0 — SCOPE K: Haplotypic Integrity Engine]
//
//  CAMBIOS v8.0 respecto a v7.0 (SCOPE K — Haplotypic Integrity):
//  [SK-1] HaplotypicBlockEngine: calcula bloques haplotípicos en cM
//         a partir de strandId/ancestorId. API: extractBlocks(),
//         countRecombEvents(), computeIIH_chromosome(), computeIIH_global(),
//         predictGenerationalDrift().
//  [SK-2] generateTriploidZygote(): expone chrResultsK con damGam y
//         sireGam por cromosoma para alimentar HaplotypicBlockEngine.
//  [SK-3] runMonteCarlo(): acumula IIH, L̄_bloque y nRecomb por
//         iteración; guarda skLastResult del último cigoto MC para render.
//  [SK-4] IIH poblacional: media ponderada sobre N iteraciones MC.
//  [SK-5] renderIIHInline(): tarjeta IIH resumida en tab Simulación.
//  [SK-6] renderScopeKTab(): panel completo — Hero IIH (ring SVG),
//         mapa de bloques por cromosoma con barras visuales,
//         tabla per-chrom, log de eventos de recombinación,
//         modelo de deriva generacional P→F1→BC1→S1→S2.
//  [SK-7] Tab "🧬 TRAZABILIDAD K" añadido a la barra de navegación.
//
//  PENDIENTE FASES SIGUIENTES:
//  [F2] Scope B: derivar alpha desde pairingMode
//  [F5] Scope F: h² como propiedad emergente (VG/VP real)
//  [F7] Scope A: validación automática completa post-simulación
//
//  Mexicanas Seeds Company — División Biotecnológica
// ═══════════════════════════════════════════════════════════════════

// ───────────────────────────────────────────────────────────────────
// [F1-1] PRNG: Mulberry32
// Uso: const rng = new RNG(seed); rng.next() → float en [0, 1)
// Math.random() se reserva ÚNICAMENTE para generar SIM_SEED inicial.
// Todo cálculo genético usa _RNG.next().
// ───────────────────────────────────────────────────────────────────
class RNG {
  constructor(seed) {
    // Fuerza a entero de 32 bits sin signo; garantiza estado inicial ≠ 0
    this._s = (seed >>> 0) || 0xDEADBEEF;
  }
  next() {
    // Mulberry32: period ~2^32, pasa PractRand 2GB sin fallos
    this._s = (this._s + 0x6D2B79F5) >>> 0;
    let z = Math.imul(this._s ^ (this._s >>> 15), 1 | this._s);
    z ^= z + Math.imul(z ^ (z >>> 7), 61 | z);
    return ((z ^ (z >>> 14)) >>> 0) / 0x100000000;
  }
  // Box-Muller usando este PRNG (reemplaza randomNormal global)
  normal(mean = 0, sd = 1) {
    const u1 = 1 - this.next(); // evita log(0)
    const u2 = this.next();
    const z  = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return z * sd + mean;
  }
}
// Instancia global — se reinicializa al inicio de cada runMonteCarlo()
let _RNG = new RNG(Date.now());

// [SM-1] Ploidía parental → copias que aporta su gameto
const GAMETE_COPIES = { 2: 1, 4: 2 };
