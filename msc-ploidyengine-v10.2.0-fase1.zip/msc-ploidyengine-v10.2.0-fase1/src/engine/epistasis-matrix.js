
// ───────────────────────────────────────────────────────────────────
// [SJ-1] EpistasisMatrix — SCOPE J
// Estructura de datos que codifica interacciones específicas locus×locus.
//
// Arquitectura:
//   _pairs: Map<canonicalKey, PairConfig>
//   canonicalKey: "locusA__locusB" con A < B (orden lexicográfico)
//     → garantiza idempotencia: (THCAS_1, TERP_MYR) ≡ (TERP_MYR, THCAS_1)
//
//   PairConfig: { locusA, locusB, Iij, type }
//     Iij    ∈ [-1, 1]     — coeficiente de interacción (configurable usuario)
//     type   ∈ 'syn'|'ant' — sinérgica (Iij>0) o antagónica (Iij<0)
//
// API:
//   set(locusA, locusB, Iij, type) — registra o actualiza par
//   get(locusA, locusB)            — retorna PairConfig o null
//   delete(locusA, locusB)         — elimina par
//   list()                         — retorna array de PairConfig
//   computeI(locusResults)         — calcula I total para un zigoto
//
// computeI(locusResults):
//   locusResults: array de { name, dose, effect } por locus en el zigoto
//   Para cada par (i,j) registrado, si ambos loci están en el haplotipo:
//     I_pair = Iij × effect_i × effect_j × doseFrac_i × doseFrac_j
//   Donde doseFrac = dose / 3  (normalización triploide 3x máx)
//   Sinérgica: I_pair > 0 → aumenta G
//   Antagónica: I_pair < 0 → reduce G
//   Retorna { totalI, contributions[] }
// ───────────────────────────────────────────────────────────────────
class EpistasisMatrix {
  constructor() {
    this._pairs = new Map();
  }

  // Clave canónica: orden lexicográfico para eliminar duplicados
  _key(a, b) {
    return a < b ? `${a}__${b}` : `${b}__${a}`;
  }

  // Registrar o actualizar un par epistático
  // Iij ∈ [-1, 1]; type: 'syn' (+) o 'ant' (−)
  set(locusA, locusB, Iij, type = 'syn') {
    if (locusA === locusB)
      throw new Error(`[EpistasisMatrix] un locus no puede interactuar consigo mismo: ${locusA}`);
    const key = this._key(locusA, locusB);
    // Clamp defensivo
    const coef = Math.max(-1, Math.min(1, Iij));
    this._pairs.set(key, { locusA, locusB, Iij: coef, type });
  }

  // Recuperar configuración de un par (null si no existe)
  get(locusA, locusB) {
    return this._pairs.get(this._key(locusA, locusB)) ?? null;
  }

  // Eliminar par
  delete(locusA, locusB) {
    this._pairs.delete(this._key(locusA, locusB));
  }

  // Listar todos los pares registrados
  list() {
    return Array.from(this._pairs.values());
  }

  // Número de pares activos
  get size() { return this._pairs.size; }

  // ── [SJ-2] computeI — Núcleo de la epistasis real ──────────────
  // Recibe el array de resultados de loci del zigoto.
  // Para cada par (i,j) en la matriz:
  //   1. Busca locus i y locus j en el haplotipo heredado.
  //   2. Si AMBOS están presentes (dose > 0 en al menos uno):
  //      I_pair = Iij × effect_i × effect_j × doseFrac_i × doseFrac_j
  //   3. Acumula en totalI.
  //
  // locusResults: [{ name, dose, effect }]
  // Retorna: { totalI, contributions }
  //   contributions: [{ locusA, locusB, Iij, I_pair, doseFracA, doseFracB }]
  computeI(locusResults, maxDoseLocus = 3) {
    // Construir índice rápido name→{dose, effect}
    const locusIdx = new Map();
    for (const l of locusResults) {
      locusIdx.set(l.name, { dose: l.dose, effect: l.effect });
    }

    let totalI = 0;
    const contributions = [];

    for (const pair of this._pairs.values()) {
      const li = locusIdx.get(pair.locusA);
      const lj = locusIdx.get(pair.locusB);

      // Si alguno de los loci no está en el zigoto actual → skip
      if (!li || !lj) continue;

      // Fracción de dosis normalizada (triploide: max dose = 3)
      const doseFracI = li.dose / maxDoseLocus;
      const doseFracJ = lj.dose / maxDoseLocus;

      // Contribución epistática par (i,j)
      // Signo se controla por Iij: positivo=sinérgico, negativo=antagónico
      const I_pair = pair.Iij * li.effect * lj.effect * doseFracI * doseFracJ;

      totalI += I_pair;
      contributions.push({
        locusA: pair.locusA,
        locusB: pair.locusB,
        Iij:    pair.Iij,
        type:   pair.type,
        doseFracA: doseFracI,
        doseFracB: doseFracJ,
        I_pair
      });
    }

    return { totalI, contributions };
  }
}

// ─── Instancia global de la matriz epistática ────────────────────
// La UI la modifica; el motor la consulta en cada iteración MC.
const EPISTASIS_MATRIX = new EpistasisMatrix();
