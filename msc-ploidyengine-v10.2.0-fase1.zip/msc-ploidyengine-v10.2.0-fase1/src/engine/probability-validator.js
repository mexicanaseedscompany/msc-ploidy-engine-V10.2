
// ───────────────────────────────────────────────────────────────────
// [F1-4] ProbabilityValidator
// Centraliza TODA la validación de distribuciones.
// ───────────────────────────────────────────────────────────────────
const ProbabilityValidator = {
  TOLERANCE: 1e-8,

  check(arr, label = '') {
    const errors = [];
    const total  = arr.reduce((s, p) => s + p, 0);
    if (Math.abs(total - 1) > this.TOLERANCE)
      errors.push(`ΣP = ${total.toFixed(12)} ≠ 1`);
    arr.forEach((p, i) => {
      if (p < -this.TOLERANCE)         errors.push(`P[${i}] = ${p.toFixed(8)} < 0`);
      if (p >  1 + this.TOLERANCE)     errors.push(`P[${i}] = ${p.toFixed(8)} > 1`);
    });
    if (errors.length)
      throw new Error(`[VALIDACIÓN FALLIDA] ${label}: ${errors.join(' | ')}`);
    return true;
  },

  // Suite completa: valida todas las combinaciones gaméticas/cigóticas
  // para un array de valores alpha. Retorna array de {ok, label, msg?}.
  runFullSuite(alphaValues = [0, 0.05, 0.10, 1 / 6]) {
    const results = [];
    for (const alpha of alphaValues) {
      for (let g = 0; g <= 4; g++) {
        const p = MeiosisEngine.tetraploidGameteProbs(g, alpha);
        results.push(safeValidate([p.AA, p.Aa, p.aa],
          `Gametos 4x g=${g} α=${alpha.toFixed(4)}`));
      }
      for (let g = 0; g <= 2; g++) {
        const p = MeiosisEngine.diploidGameteProbs(g);
        results.push(safeValidate([p.A, p.a],
          `Gametos 2x g=${g}`));
      }
      for (let g4 = 0; g4 <= 4; g4++) {
        for (let g2 = 0; g2 <= 2; g2++) {
          const z = MeiosisEngine.triploidZygoteProbs(g4, g2, alpha);
          results.push(safeValidate([z.AAA, z.AAa, z.Aaa, z.aaa],
            `Zigotos g4=${g4} g2=${g2} α=${alpha.toFixed(4)}`));
        }
      }
    }
    return results;
  }
};

function safeValidate(arr, label) {
  try   { ProbabilityValidator.check(arr, label); return { ok: true, label }; }
  catch (e) { return { ok: false, label, msg: e.message }; }
}
