
// ───────────────────────────────────────────────────────────────────
// [F1-5] PolyploidEngineV3 — wrapper de compatibilidad
// No contiene lógica propia. Delega en MeiosisEngine.
// La UI existente no requiere ningún cambio.
// ───────────────────────────────────────────────────────────────────
class PolyploidEngineV3 {
  constructor(alpha = 0.0) { this.alpha = alpha; }

  getTetraploidGametes(g) {
    const p = MeiosisEngine.tetraploidGameteProbs(g, this.alpha);
    ProbabilityValidator.check([p.AA, p.Aa, p.aa], `Gametos 4x g=${g}`);
    return p;
  }
  getDiploidGametes(g) {
    const p = MeiosisEngine.diploidGameteProbs(g);
    return p; // {A, a} — validación implícita en tetraploidGameteProbs
  }
  getTriploidZygotes(g4, g2) {
    const z = MeiosisEngine.triploidZygoteProbs(g4, g2, this.alpha);
    ProbabilityValidator.check([z.AAA, z.AAa, z.Aaa, z.aaa],
      `Zigotos g4=${g4} g2=${g2}`);
    return z;
  }
  // [F1-9] Uso legítimo: MC simple, un locus, sin ligamiento
  simulateLocus(g4, g2, minDose = 1) {
    const dose = MeiosisEngine.sampleTriploidZygoteSingle(g4, g2, this.alpha, _RNG);
    return dose >= minDose;
  }
  simulateQuantitativeLocus(g4, g2) {
    return MeiosisEngine.sampleTriploidZygoteSingle(g4, g2, this.alpha, _RNG);
  }
}
