
// ───────────────────────────────────────────────────────────────────
// [F1-3] RecombinationEngine
// Responsabilidad única: calcular r entre pares de loci
// ───────────────────────────────────────────────────────────────────
const RecombinationEngine = {
  // Función de Haldane: r = ½(1 − e^{−2d}), d en Morgans
  // Garantías: r(0)=0, r(∞)→0.5, monotónica creciente, nunca > 0.5
  haldane(pos1_cM, pos2_cM) {
    const d = Math.abs(pos2_cM - pos1_cM) / 100;
    return 0.5 * (1 - Math.exp(-2 * d));
  }
};
