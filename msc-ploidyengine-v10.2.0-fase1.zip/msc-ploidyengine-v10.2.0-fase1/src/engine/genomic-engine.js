
// ───────────────────────────────────────────────────────────────────
// [F1-6] GenomicPolyploidEngine v5
// Reescrito sobre MeiosisEngine. Soporta:
//   - genotypeCode único (compatibilidad v4.1)
//   - ParentalHaplotype con g por locus [F1-8]
//   - alleleState {AAA/AAa/Aaa/aaa} por locus [F1-7]
//   - Crossover via RecombinationEngine (Haldane) por locus adyacente
//   - Monte Carlo haplotípico separado del MC simple [F1-9]
// ───────────────────────────────────────────────────────────────────
class GenomicPolyploidEngine {
  constructor(alpha = 0.05) {
    this.alpha  = alpha;
    this.genome = [];
  }

  buildGenome(chrDefs) {
    this.genome = chrDefs.map(def => {
      const chr = new Chromosome(def.id, def.length_cM);
      def.loci.forEach(l =>
        chr.addLocus(l.name, l.pos_cM, l.effect,
                     l.dominance || 0, l.epistasis || 0, l.trait || ''));
      return chr;
    });
  }

  // ── [F1-10] effectiveAlpha — STUB ────────────────────────────────
  // ⚠ PENDIENTE Fase 2 (Scope B): eliminar doble contabilización.
  // Por ahora NO se usa en la ruta haplotípica genómica.
  // El MC cualitativo usa this.alpha directamente.
  // TODO F2: derivar alpha desde pairingMode sin multiplicación.
  effectiveAlpha_STUB(pairingMode) {
    // [BUG B] Este método introduce doble contabilización:
    // alpha ya incluye el efecto de cuadrivalentes en la estimación empírica.
    // Se preserva con nombre _STUB para que Fase 2 lo reemplace.
    return this.alpha * (1 + pairingMode.quadrivalent * 0.8);
  }

  // ── simulateMeiosis — [SCOPE C] Strand Tracking Real ───────────────
  // Genera el gameto haplotípico de UN parental para UN cromosoma
  // modelando las cromátidas físicas. Los genes adyacentes se heredan
  // juntos (bloque haplotípico) y sólo se separan si el PRNG supera
  // la probabilidad de crossover de Haldane entre ese par de loci.
  //
  // Modelo para parental 4x (madre):
  //   Se representan las 4 cromátidas del bivalente como vectores de alelos.
  //   La célula escoge 2 de esas 4 cromátidas para el gameto diploide 2x.
  //   Entre loci adyacentes, se decide si ocurre crossover (Haldane).
  //   Si ocurre, las dos cromátidas activas intercambian segmentos.
  //   → Resultado: dosis ∈ {0,1,2} con bloques haplotípicos preservados.
  //
  // Modelo para parental 2x (padre):
  //   Se representan las 2 cromátidas del haploide.
  //   strand ∈ {0,1} — la cromátida activa para este gameto.
  //   Crossover de Haldane determina si se cambia de cromátida.
  //   → Resultado: dosis ∈ {0,1} con continuidad haplotípica.
  //
  // chromosome: Chromosome — loci ordenados por pos_cM
  // ploidyLevel: 4 (madre) o 2 (padre)
  // parentalHaplotype: ParentalHaplotype | integer
  // alpha: coeficiente de reducción doble (doble reducción, solo 4x)
  //
  // Retorna array de { name, pos_cM, effect, dominance, epistasis,
  //                    trait, dose, strandId, ancestorId }
  //   strandId  — índice de cromátida activa al momento de copiar el locus
  //   ancestorId — etiqueta de pedigree real (Scope H)
  simulateMeiosis(chromosome, ploidyLevel, parentalHaplotype, alpha, role = null) {
    // Normalizar entrada: integer → ParentalHaplotype
    const haploMap = (typeof parentalHaplotype === 'number')
      ? ParentalHaplotype.fromUniform(parentalHaplotype)
      : parentalHaplotype;

    const gameteHaplotype = [];
    // [SM-9] role explícito (dam/sire); default retrocompatible por ploidía
    const origin = role ?? (ploidyLevel === 4 ? 'dam' : 'sire');

    if (ploidyLevel === 4) {
      // ─────────────────────────────────────────────────────────────────
      // MEIOSIS TETRAPLOIDE — strand tracking con 4 cromátidas
      //
      // Construimos las 4 cromátidas del tetraploide a partir del
      // genotipo parental en cada locus. Para cada locus, el genotypeCode
      // g ∈ {0..4} codifica cuántas copias del alelo A existen.
      // Las distribuimos en 4 cromátidas (h0..h3): las primeras g contienen
      // A y las restantes contienen a.
      //
      // La meiosis eige 2 cromátidas para el gameto diploide.
      // Iniciamos con dos cromátidas activas elegidas aleatoriamente.
      // Entre loci adyacentes, Haldane determina si ocurre crossover;
      // si ocurre, hacemos flip de una de las dos cromátidas activas.
      // Double reduction se modela con probabilidad alpha_loc: si el
      // crossover ocurre entre las dos cromátidas hermanas (sister
      // chromatid exchange), ambas cromátidas activas pueden terminar
      // siendo del mismo origen.
      // ─────────────────────────────────────────────────────────────────

      // Elegir las dos cromátidas activas para este gameto (índices 0-3)
      // La primera se elige al azar; la segunda es la complementaria
      // por defecto (bivalente normal), con probabilidad alpha de que
      // sea una cromátida hermana (doble reducción).
      // [v10.2] Permutación aleatoria alelo↔cromátida (una por meiosis/cromosoma):
      // define qué cromátidas físicas portan A. Sin esto, los bivalentes (0,1)|(2,3)
      // eran siempre homocigotos y AAaa producía solo gametos Aa.
      const perm = [0, 1, 2, 3];
      for (let k = 3; k > 0; k--) {
        const j = Math.floor(_RNG.next() * (k + 1));
        [perm[k], perm[j]] = [perm[j], perm[k]];
      }
      let activeA = Math.floor(_RNG.next() * 4); // cromátida activa #1
      let activeB;
      // Cromátida complementaria: para bivalente normal sería la de la
      // homóloga opuesta. Simplificamos: activa B = (activeA + 2) % 4 en
      // ausencia de double reduction, con prob alpha se asigna una hermana.
      // [F3-1] Double reduction — corrección: alpha es una propiedad
      // del cromosoma (distancia al centrómero / estructura del bivalente)
      // y NO debe escalar con la posición del primer locus anotado.
      // La versión anterior tenía: alphaFirst = alpha * exp(-pos_cM/50),
      // lo cual reducía artificialmente la doble reducción en cromosomas
      // cuyo primer QTL está lejos del extremo. Corregido.
      if (_RNG.next() < alpha) {
        // Doble reducción: segunda cromátida es hermana del mismo par
        // Pares hermanos: (0,1) y (2,3) → XOR 1 selecciona el par
        // [v10.2] Doble reducción (Mather): el gameto recibe las dos cromátidas
        // hermanas de UN mismo cromosoma → dosis 2 o 0 en ese segmento.
        activeB = activeA;
      } else {
        // Bivalente normal: segunda cromátida de la homóloga opuesta
        activeB = (activeA < 2) ? (2 + Math.floor(_RNG.next() * 2))
                                : Math.floor(_RNG.next() * 2);
      }

      for (let i = 0; i < chromosome.loci.length; i++) {
        const locus = chromosome.loci[i];
        const g     = haploMap.getG(locus.name);

        // Crossover inter-loci entre locus anterior y el actual
        if (i > 0) {
          const r = RecombinationEngine.haldane(
            chromosome.loci[i - 1].pos_cM, locus.pos_cM
          );
          if (_RNG.next() < r) {
            // Crossover: una de las dos cromátidas activas se intercambia
            // con una cromátida no activa del mismo par de homólogas.
            // Flip de activeB (el gameto ya eligió su "primer" cromátida
            // activa; el crossover afecta al segmento posterior).
            const nonActive = [0,1,2,3].filter(x => x !== activeA && x !== activeB);
            activeB = nonActive[Math.floor(_RNG.next() * nonActive.length)];
          }
        }

        // Leer alelos desde las 4 cromátidas implícitas del genotipo
        // Las primeras g cromátidas tienen alelo A, las demás tienen a.
        const alleleOfStrand = idx => (perm[idx] < g) ? 'A' : 'a';
        const alleleA = alleleOfStrand(activeA);
        const alleleB = alleleOfStrand(activeB);
        // Dosis del gameto diploide: número de alelos A en {activeA, activeB}
        const dose = (alleleA === 'A' ? 1 : 0) + (alleleB === 'A' ? 1 : 0);

        // Atributos de pedigree para Scope H
        const strandId   = activeA * 4 + activeB; // identificador único del par
        const ancestorId = `${origin}_4x_${chromosome.id}_hA${activeA}hB${activeB}`;

        gameteHaplotype.push({
          name:      locus.name,
          pos_cM:    locus.pos_cM,
          effect:    locus.effect,
          dominance: locus.dominance,
          epistasis: locus.epistasis,
          trait:     locus.trait,
          dose,       // ∈ {0,1,2}
          strandId,
          ancestorId,
          origin
        });
      }

    } else {
      // ─────────────────────────────────────────────────────────────────
      // MEIOSIS DIPLOIDE — strand tracking con 2 cromátidas
      //
      // El padre 2x tiene 2 cromátidas: strand 0 (alelo del gameto 'izq')
      // y strand 1 (alelo del gameto 'der'). Para g=0: ambas son a.
      // Para g=1: strand0=A, strand1=a. Para g=2: ambas son A.
      // Iniciamos con strand aleatorio; Haldane determina flips.
      // ─────────────────────────────────────────────────────────────────
      let currentStrand = _RNG.next() < 0.5 ? 0 : 1;

      for (let i = 0; i < chromosome.loci.length; i++) {
        const locus = chromosome.loci[i];
        const g     = haploMap.getG(locus.name);

        // Crossover inter-loci (Haldane) — flip de strand
        if (i > 0) {
          const r = RecombinationEngine.haldane(
            chromosome.loci[i - 1].pos_cM, locus.pos_cM
          );
          if (_RNG.next() < r) currentStrand ^= 1;
        }

        // Leer alelo desde el strand activo
        // g=0: [a,a]; g=1: [A,a]; g=2: [A,A]
        const strandAlleles = g === 0 ? ['a','a'] :
                              g === 1 ? ['A','a'] : ['A','A'];
        const dose = strandAlleles[currentStrand] === 'A' ? 1 : 0;
        const ancestorId = `${origin}_2x_${chromosome.id}_h${currentStrand}`;

        gameteHaplotype.push({
          name:      locus.name,
          pos_cM:    locus.pos_cM,
          effect:    locus.effect,
          dominance: locus.dominance,
          epistasis: locus.epistasis,
          trait:     locus.trait,
          dose,       // ∈ {0,1}
          strandId:  currentStrand,
          ancestorId,
          origin
        });
      }
    }

    return gameteHaplotype;
  }

  // [SJ-3] generateTriploidZygote — inyecta EpistasisMatrix
  // Cruza madre 4x × padre 2x, cromosoma a cromosoma, locus a locus.
  // Retorna representación completa con alleleState por locus [F1-7].
  //
  // dam4xHaplotype: ParentalHaplotype | integer (genotypeCode uniforme)
  // sire2xHaplotype: ParentalHaplotype | integer
  // pairingMode: { bivalent, quadrivalent } — RESERVADO para Fase 2
  // epistasisMatrix: EpistasisMatrix — instancia con pares configurados
  //
  // G = A + D + I:
  //   A: dosis × effect (lineal, correcto)
  //   D: función de alleleState (modelo Potts 1954)
  //   I: [SCOPE J] EpistasisMatrix inter-loci — reemplaza curvatura de dosis
  generateTriploidZygote(
    dam4xHaplotype  = 2,
    sire2xHaplotype = 1,
    pairingMode     = { bivalent: 0.6, quadrivalent: 0.4 },
    epistasisMatrix = EPISTASIS_MATRIX,
    maxDoseLocus    = 3,
    ploidyA         = 4,
    ploidyB         = 2
  ) {
    // [F1-10] Usar alpha directamente hasta que Fase 2 corrija effectiveAlpha
    const alphaToUse = this.alpha;

    let totalA = 0, totalD = 0;
    const chrResults = [];

    // [SJ-3] Acumulamos todos los loci del zigoto para consultar la matriz
    const allLocusResults = [];

    for (const chr of this.genome) {
      const damGam  = this.simulateMeiosis(chr, ploidyA, dam4xHaplotype,  alphaToUse, 'dam');
      const sireGam = this.simulateMeiosis(chr, ploidyB, sire2xHaplotype, alphaToUse, 'sire');

      const lociResults = chr.loci.map((l, i) => {
        const damDose  = damGam[i].dose;   // ∈ {0,1,2}
        const sireDose = sireGam[i].dose;  // ∈ {0,1}

        // [SCOPE H] ancestorId real desde strand tracking
        const locusGeno = MeiosisEngine.buildLocusGenotype(
          damDose, sireDose,
          damGam[i].ancestorId,
          sireGam[i].ancestorId,
          maxDoseLocus,
          GAMETE_COPIES[ploidyA] ?? 2,
          GAMETE_COPIES[ploidyB] ?? 1
        );

        // ── Efecto aditivo ──
        const A_contrib = locusGeno.dose * l.effect;

        // ── Efecto de dominancia (modelo Potts 1954) ──
        // [SM-3] generalizado: 3x → 0.333/0.667/1.000 (idéntico al switch previo)
        const D_contrib = locusGeno.dose > 0
          ? l.dominance * l.effect * (locusGeno.dose / maxDoseLocus)
          : 0;

        totalA += A_contrib;
        totalD += D_contrib;

        // Registro para la EpistasisMatrix post-loop
        allLocusResults.push({ name: l.name, dose: locusGeno.dose, effect: l.effect });

        return {
          name:        l.name,
          pos_cM:      l.pos_cM,
          effect:      l.effect,
          trait:       l.trait,
          dose:        locusGeno.dose,
          alleleState: locusGeno.alleleState,
          damDose:     locusGeno.damDose,
          sireDose:    locusGeno.sireDose,
          homologs:    locusGeno.homologs
        };
      });

      chrResults.push({ chrId: chr.id, loci: lociResults });
    }

    // [SJ-3] Epistasis inter-loci real via EpistasisMatrix
    const { totalI, contributions } = epistasisMatrix.computeI(allLocusResults, maxDoseLocus);

    return {
      totalG: totalA + totalD + totalI,
      totalA, totalD, totalI,
      epiContributions: contributions,   // [SJ-3] para renderizado UI
      chrResults,
      // [SK-2] Expose chrResultsWithGametes for Scope K block engine
      chrResultsK: chrResults.map((cr, idx) => ({
        chrId:        cr.chrId,
        chrLength_cM: this.genome[idx]?.length_cM ?? 100,
        damGam:       (() => {
          const chr = this.genome[idx];
          if (!chr) return [];
          const dg = this.simulateMeiosis(chr, ploidyA, dam4xHaplotype, alphaToUse, 'dam');
          return dg;
        })(),
        sireGam: (() => {
          const chr = this.genome[idx];
          if (!chr) return [];
          const sg = this.simulateMeiosis(chr, ploidyB, sire2xHaplotype, alphaToUse, 'sire');
          return sg;
        })()
      }))
    };
  }

  // ── [F3-2] buildMCGenome — Genoma sintético para el bucle MC ─────────
  // Construye un array de Chromosome a partir de los parámetros de la UI,
  // uno por carácter. Cada cromosoma tiene nLoci[c] loci equiespaciados.
  // El espaciado spacingCM controla el ligamiento efectivo:
  //   spacingCM = 5  → r ≈ 0.048  (ligamiento moderado–fuerte)
  //   spacingCM = 10 → r ≈ 0.091  (ligamiento moderado)
  //   spacingCM = 50 → r ≈ 0.432  (casi libre — comparable a muestreo ind.)
  //
  // Parámetros
  //   nLoci      {number[]}  — loci por carácter [n0, n1, n2]
  //   efectoAdit {number}    — efecto aditivo por locus (% unidades)
  //   domCoef    {number}    — coeficiente de dominancia global
  //   epiCoef    {number}    — coeficiente de epistasis global
  //   traitNames {string[]}  — nombre de rasgo por cromosoma
  //   spacingCM  {number}    — distancia entre loci adyacentes (default: 10 cM)
  //
  // Retorna: Chromosome[]
  static buildMCGenome(
    nLoci,
    efectoAdit,
    domCoef,
    epiCoef,
    traitNames = ['cannabinoids', 'terpenes', 'morphology'],
    spacingCM  = 10
  ) {
    return nLoci.map((n, c) => {
      const chr = new Chromosome(`MCChr${c}`, n * spacingCM);
      for (let l = 0; l < n; l++) {
        chr.addLocus(
          `MC_C${c}_L${l}`,       // nombre único por locus
          (l + 1) * spacingCM,    // pos_cM: spacingCM, 2×spacingCM, …
          efectoAdit,
          domCoef,
          epiCoef,
          traitNames[c] ?? `trait_${c}`
        );
      }
      return chr;
    });
  }

  // ── [F3-3] simulateLinkedMCIteration — reemplaza sampleTriploidZygoteSingle ──
  // Núcleo del bucle Monte Carlo con ligamiento genético real.
  //
  // [SJ-4] Acepta epistasisMatrix para calcular I real en cada iteración.
  //
  // Retorna { doseTrait, passCount, charOk, haploBonus, totalI_matrix }
  //   totalI_matrix: contribución epistática real de la EpistasisMatrix
  simulateLinkedMCIteration(mcGenome, g4, g2, alpha, minDose, epistasisMatrix = EPISTASIS_MATRIX,
                            ploidyA = 4, ploidyB = 2, maxDoseLocus = 3) {
    const dam4xHP  = ParentalHaplotype.fromUniform(g4);
    const sire2xHP = ParentalHaplotype.fromUniform(g2);

    const doseTrait = [0, 0, 0];
    const charOk    = [true, true, true];
    let hapIntactPairs = 0;
    let hapTotalPairs  = 0;

    // [SJ-4] Colectar loci del zigoto para la EpistasisMatrix
    const allLocusResultsMC = [];

    for (let c = 0; c < mcGenome.length; c++) {
      const chr     = mcGenome[c];
      const damGam  = this.simulateMeiosis(chr, ploidyA, dam4xHP,  alpha, 'dam');
      const sireGam = this.simulateMeiosis(chr, ploidyB, sire2xHP, alpha, 'sire');

      let prevAncDam    = null;
      let prevAncSire   = null;
      let prevFavorable = false;

      for (let li = 0; li < chr.loci.length; li++) {
        const dose = damGam[li].dose + sireGam[li].dose;
        doseTrait[c] += dose;

        if (dose < minDose) charOk[c] = false;

        // ── Rastreo de bloques haplotípicos ─────────────────────────
        const isFavorable = dose >= 2;
        if (isFavorable && prevFavorable) {
          hapTotalPairs++;
          if (damGam[li].ancestorId  === prevAncDam &&
              sireGam[li].ancestorId === prevAncSire) {
            hapIntactPairs++;
          }
        }
        if (isFavorable) {
          prevAncDam  = damGam[li].ancestorId;
          prevAncSire = sireGam[li].ancestorId;
        }
        prevFavorable = isFavorable;

        // [SJ-4] Registrar locus para EpistasisMatrix
        allLocusResultsMC.push({
          name:   chr.loci[li].name,
          dose,
          effect: chr.loci[li].effect
        });
      }
    }

    const passCount = charOk.filter(Boolean).length;
    const haploBonus = hapTotalPairs > 0
      ? hapIntactPairs / hapTotalPairs
      : 0.5;

    // [SJ-4] Epistasis real via EpistasisMatrix
    const { totalI: totalI_matrix } = epistasisMatrix.computeI(allLocusResultsMC, maxDoseLocus);

    return { doseTrait, passCount, charOk, haploBonus, totalI_matrix };
  }
}
