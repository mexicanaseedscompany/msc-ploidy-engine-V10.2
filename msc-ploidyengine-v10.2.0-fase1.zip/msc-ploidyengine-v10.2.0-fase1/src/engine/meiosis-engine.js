
// ───────────────────────────────────────────────────────────────────
// [F1-2] MeiosisEngine
// ÚNICA fuente de verdad para distribuciones y muestreo gaméticos.
// Tanto PolyploidEngineV3 (MC simple) como GenomicPolyploidEngine
// (haplotipo genómico) delegan aquí.
// ───────────────────────────────────────────────────────────────────
const MeiosisEngine = {

  // [SM-1] String alélico genérico: renderAlleleState(1,3)→'Aaa'
  renderAlleleState(dose, maxDoseLocus) {
    const n = Math.max(0, Math.min(dose, maxDoseLocus));
    return 'A'.repeat(n) + 'a'.repeat(maxDoseLocus - n);
  },

  // [SM-1] Distribución gamética por ploidía: [{dose,label,p}]
  gameteDist(ploidy, g, alpha) {
    if (ploidy === 4) {
      const p = this.tetraploidGameteProbs(g, alpha);
      return [{dose:2,label:'AA',p:p.AA},{dose:1,label:'Aa',p:p.Aa},{dose:0,label:'aa',p:p.aa}];
    }
    const p = this.diploidGameteProbs(g);
    return [{dose:1,label:'A',p:p.A},{dose:0,label:'a',p:p.a}];
  },

  // [SM-1] Distribución de dosis cigótica (convolución) → array [P(dosis=0..max)]
  zygoteDist(distA, distB, maxDose) {
    const out = new Array(maxDose + 1).fill(0);
    for (const a of distA) for (const b of distB) out[a.dose + b.dose] += a.p * b.p;
    return out;
  },

  // ── Distribución gamética tetraploide ──────────────────────────
  // g     ∈ {0,1,2,3,4}  = dosis A del parental (aaaa…AAAA)
  // alpha ∈ [0, 1/6]     = coeficiente de reducción doble
  // Retorna distribución de gametos 2x: {AA, Aa, aa}
  // Fórmulas: Mather (1936), validadas para autotetraploides.
  tetraploidGameteProbs(g, alpha) {
    // Clamping defensivo: alpha biológicamente ≤ 1/6 ≈ 0.1667
    const a = Math.max(0, Math.min(alpha, 1 / 6));
    let AA = 0, Aa = 0, aa = 0;
    switch (g) {
      case 0: aa = 1.0;                                              break; // aaaa
      case 1: Aa = (1 - a) / 2;   aa = (1 + a) / 2;                break; // Aaaa
      case 2: AA = (1 + 2*a) / 6; Aa = (2 - 2*a) / 3; aa = (1 + 2*a) / 6; break; // AAaa
      case 3: AA = (1 + a) / 2;   Aa = (1 - a) / 2;                break; // AAAa
      case 4: AA = 1.0;                                              break; // AAAA
      default: throw new Error(`MeiosisEngine: genotypeCode 4x inválido: ${g}`);
    }
    return { AA, Aa, aa };
  },

  // ── Distribución gamética diploide ─────────────────────────────
  // g ∈ {0,1,2} = dosis A del parental (aa, Aa, AA)
  // Retorna distribución de gametos 1x: {A, a}
  diploidGameteProbs(g) {
    switch (g) {
      case 0: return { A: 0.0, a: 1.0 };
      case 1: return { A: 0.5, a: 0.5 };
      case 2: return { A: 1.0, a: 0.0 };
      default: throw new Error(`MeiosisEngine: genotypeCode 2x inválido: ${g}`);
    }
  },

  // ── Distribución de zigotos triploides ─────────────────────────
  // Producto directo de distribuciones gaméticas 4x × 1x
  // Retorna {AAA, AAa, Aaa, aaa}
  triploidZygoteProbs(g4, g2, alpha) {
    const gam4 = this.tetraploidGameteProbs(g4, alpha);
    const gam2 = this.diploidGameteProbs(g2);
    return {
      AAA: gam4.AA * gam2.A,
      AAa: gam4.AA * gam2.a + gam4.Aa * gam2.A,
      Aaa: gam4.Aa * gam2.a + gam4.aa * gam2.A,
      aaa: gam4.aa * gam2.a
    };
  },

  // ── Muestrear dosis del gameto tetraploide ──────────────────────
  // Usa _RNG. Retorna dosis ∈ {0, 1, 2}
  // ⚠ SOLO para loci independientes (sin ligamiento).
  //   Para múltiples loci ligados usar simulateMeiosis() en GenomicEngine.
  sampleTetraploidGamete(g, alpha, rng) {
    const { AA, Aa } = this.tetraploidGameteProbs(g, alpha);
    const r = rng.next();
    if (r < AA)       return 2;
    if (r < AA + Aa)  return 1;
    return 0;
  },

  // ── Muestrear dosis del gameto diploide ────────────────────────
  // Usa _RNG. Retorna dosis ∈ {0, 1}
  // ⚠ SOLO para loci independientes.
  sampleDiploidGamete(g, rng) {
    const { A } = this.diploidGameteProbs(g);
    return rng.next() < A ? 1 : 0;
  },

  // ── Muestrear zigoto triploide — UN locus independiente ─────────
  // [F1-9] Uso legítimo: bucle Monte Carlo simple (sin ligamiento).
  //         NO usar en generateTriploidZygote() genómico.
  // Retorna dosis ∈ {0, 1, 2, 3}
  sampleTriploidZygoteSingle(g4, g2, alpha, rng) {
    return this.sampleTetraploidGamete(g4, alpha, rng)
         + this.sampleDiploidGamete(g2, rng);
  },

  // ── Construir genotipo por locus — [SM-2] generalizado ─────────────
  // maxDoseLocus = nDamCopies + nSireCopies (3 para 4x×2x y 2x×4x).
  // nDamCopies/nSireCopies explícitos: NO inferibles desde maxDoseLocus.
  // Regresión 4x×2x: idéntico a v9.2.0 (mismos ancestorId y homólogos).
  buildLocusGenotype(damDose, sireDose,
                     damAncestorId  = 'dam_4x_h1',
                     sireAncestorId = 'sire_2x_h0',
                     maxDoseLocus   = 3,
                     nDamCopies     = 2,
                     nSireCopies    = 1) {
    const dose        = damDose + sireDose;
    const alleleState = MeiosisEngine.renderAlleleState(dose, maxDoseLocus);

    const mkAlleles = (n, d) => Array.from({ length: n }, (_, i) => i < d ? 'A' : 'a');
    const damAlleles  = mkAlleles(nDamCopies,  damDose);
    const sireAlleles = mkAlleles(nSireCopies, sireDose);

    // ancestorId por homólogo: gameto de 2 copias codifica 'hA{i}hB{j}'
    const splitAncestors = (id, n) => {
      if (n !== 2) return Array.from({ length: n }, () => id);
      const base = id.replace(/_hA\d+hB\d+$/, '');
      const a = id.match(/_hA(\d+)/), b = id.match(/hB(\d+)/);
      return [`${base}_hA${a ? a[1] : '0'}`, `${base}_hB${b ? b[1] : '1'}`];
    };
    const damIds  = splitAncestors(damAncestorId,  nDamCopies);
    const sireIds = splitAncestors(sireAncestorId, nSireCopies);

    const homologs = [
      ...damAlleles.map((allele, i) => ({
        id: `h${i + 1}`, origin: 'dam', allele,
        sourcePloidy: nDamCopies === 2 ? 4 : 2, ancestorId: damIds[i] })),
      ...sireAlleles.map((allele, i) => ({
        id: `h${nDamCopies + i + 1}`, origin: 'sire', allele,
        sourcePloidy: nSireCopies === 2 ? 4 : 2, ancestorId: sireIds[i] }))
    ];

    return { dose, alleleState, damDose, sireDose, homologs };
  }
};
