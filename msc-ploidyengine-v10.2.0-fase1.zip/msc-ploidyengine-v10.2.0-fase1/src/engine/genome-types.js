
// ───────────────────────────────────────────────────────────────────
// [F1-8] ParentalHaplotype
// Representa el genotipo parental locus a locus.
// Permite que THCAS=AAAa, CBDAS=aaaa, TERP=AAaa en el mismo parental.
// ───────────────────────────────────────────────────────────────────
class ParentalHaplotype {
  // locusGenotypeMap: { [locusName]: g } donde g ∈ {0..4} para 4x, {0..2} para 2x
  // defaultG: valor por defecto si un locus no está en el mapa
  constructor(locusGenotypeMap = {}, defaultG = 2) {
    this._map      = locusGenotypeMap;
    this._default  = defaultG;
  }
  getG(locusName) {
    return (locusName in this._map) ? this._map[locusName] : this._default;
  }
  // Construir desde un genotypeCode único (modo compatibilidad v4.1)
  static fromUniform(g) {
    return new ParentalHaplotype({}, g);
  }
}

// ───────────────────────────────────────────────────────────────────
// Clase Chromosome — sin cambios funcionales, compatible v5
// ───────────────────────────────────────────────────────────────────
class Chromosome {
  constructor(id, length_cM) {
    this.id = id;
    this.length_cM = length_cM;
    this.loci = [];
  }
  addLocus(name, pos_cM, effect, dominance = 0, epistasis = 0, trait = '') {
    this.loci.push({ name, pos_cM, effect, dominance, epistasis, trait });
    this.loci.sort((a, b) => a.pos_cM - b.pos_cM);
  }
}
