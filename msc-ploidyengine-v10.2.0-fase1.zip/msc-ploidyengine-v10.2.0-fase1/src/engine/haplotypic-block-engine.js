
// ───────────────────────────────────────────────────────────────────
// [SK-1] HaplotypicBlockEngine — SCOPE K
//
// Responsabilidad: a partir del gameteHaplotype (array de loci con
// strandId y ancestorId producidos por simulateMeiosis), calcula:
//   1. Los bloques haplotípicos de longitud en cM (segmentos sin
//      recombinación entre loci adyacentes del mismo ancestorId).
//   2. La longitud media de bloque L̄ (cM).
//   3. El número de eventos de recombinación observados en ese gameto.
//   4. El Índice de Integridad Haplotípica (IIH) por cromosoma y global.
//
// Definiciones:
//   Bloque = secuencia maximal de loci adyacentes con el mismo ancestorId.
//   Longitud de bloque = pos_cM del último locus − pos_cM del primero.
//   Si un bloque tiene un solo locus su longitud se imputa como
//   la mitad del intervalo entre sus vecinos (o MC_SPACING_CM/2 si es único).
//
// IIH por cromosoma:
//   IIH_chr = (Σ length_i × isIntact_i) / length_chr_total
//   donde isIntact_i = 1 si el bloque hereda del ancestorId esperado
//   del parental "positivo" (dam para 4x, sire para 2x).
//
// IIH global:
//   IIH = Σ(IIH_chr × length_chr) / Σ length_chr  (media ponderada por longitud)
// ───────────────────────────────────────────────────────────────────
const HaplotypicBlockEngine = {

  // [SM-8] Contexto de cruce (default 4x×2x)
  _gameteCopiesA: 2,
  _gameteCopiesB: 1,
  setCrossContext(ploidyA, ploidyB) {
    this._gameteCopiesA = GAMETE_COPIES[ploidyA] ?? 2;
    this._gameteCopiesB = GAMETE_COPIES[ploidyB] ?? 1;
  },

  // ── [SK-1a] extractBlocks ───────────────────────────────────────
  // Dado el gameteHaplotype de UN cromosoma (array ordenado por pos_cM),
  // retorna el array de bloques haplotípicos.
  //
  // gameteHaplotype: [{ name, pos_cM, dose, strandId, ancestorId, origin }]
  // Retorna: [{ ancestorId, strandId, loci[], startCM, endCM, lengthCM, isRecombinant }]
  //   isRecombinant: true si el bloque difiere del ancestorId del primer locus del gameto
  //   (proxy: primer bloque = "ancestral", subsiguientes = recombinados si cambia)
  extractBlocks(gameteHaplotype) {
    if (!gameteHaplotype || gameteHaplotype.length === 0) return [];

    const blocks = [];
    let currentBlock = null;
    const firstAncestorId = gameteHaplotype[0].ancestorId;

    for (let i = 0; i < gameteHaplotype.length; i++) {
      const locus = gameteHaplotype[i];

      if (!currentBlock || locus.ancestorId !== currentBlock.ancestorId) {
        // Cerrar bloque anterior
        if (currentBlock) {
          // Calcular endCM del bloque cerrado como pos_cM del último locus
          currentBlock.endCM     = currentBlock.loci[currentBlock.loci.length - 1].pos_cM;
          currentBlock.lengthCM  = Math.max(0, currentBlock.endCM - currentBlock.startCM);
          blocks.push(currentBlock);
        }
        // Nuevo bloque
        currentBlock = {
          ancestorId:    locus.ancestorId,
          strandId:      locus.strandId,
          loci:          [],
          startCM:       locus.pos_cM,
          endCM:         locus.pos_cM,
          lengthCM:      0,
          isRecombinant: locus.ancestorId !== firstAncestorId
        };
      }
      currentBlock.loci.push(locus);
    }

    // Cerrar el último bloque abierto
    if (currentBlock) {
      currentBlock.endCM    = currentBlock.loci[currentBlock.loci.length - 1].pos_cM;
      currentBlock.lengthCM = Math.max(0, currentBlock.endCM - currentBlock.startCM);
      blocks.push(currentBlock);
    }

    // Impute length para bloques de un solo locus
    const spacing = (gameteHaplotype.length > 1)
      ? Math.abs(gameteHaplotype[1].pos_cM - gameteHaplotype[0].pos_cM)
      : 10; // fallback MC_SPACING_CM

    blocks.forEach(b => {
      if (b.lengthCM === 0 && b.loci.length === 1) {
        b.lengthCM = spacing * 0.5; // imputación conservadora
      }
    });

    return blocks;
  },

  // ── [SK-1b] countRecombEvents ───────────────────────────────────
  // Cuenta transiciones de ancestorId en el gameteHaplotype:
  // cada cambio = 1 evento de recombinación observado.
  countRecombEvents(gameteHaplotype) {
    let events = 0;
    for (let i = 1; i < gameteHaplotype.length; i++) {
      if (gameteHaplotype[i].ancestorId !== gameteHaplotype[i-1].ancestorId) {
        events++;
      }
    }
    return events;
  },

  // ── [SK-1c] computeIIH_chromosome ──────────────────────────────
  // Calcula el IIH para un único cromosoma (gamete parcial).
  // damGam:  gameteHaplotype del parental 4x (origen 'dam')
  // sireGam: gameteHaplotype del parental 2x (origen 'sire')
  // chrLength_cM: longitud total del cromosoma
  //
  // Retorna { damIIH, sireIIH, IIH_chr, damBlocks, sireBlocks,
  //           damRecombEvents, sireRecombEvents, meanBlockCM }
  computeIIH_chromosome(damGam, sireGam, chrLength_cM) {
    const damBlocks  = this.extractBlocks(damGam);
    const sireBlocks = this.extractBlocks(sireGam);

    // IIH dam: fracción del cromosoma en el primer (ancestral) bloque
    const damAncestral = damBlocks.length > 0 ? damBlocks[0].ancestorId : '';
    const damAncLen    = damBlocks.reduce((s, b) =>
      s + (b.ancestorId === damAncestral ? b.lengthCM : 0), 0);
    const damIIH = chrLength_cM > 0 ? Math.min(1, damAncLen / chrLength_cM) : 1;

    // IIH sire: ídem para sire
    const sireAncestral = sireBlocks.length > 0 ? sireBlocks[0].ancestorId : '';
    const sireAncLen    = sireBlocks.reduce((s, b) =>
      s + (b.ancestorId === sireAncestral ? b.lengthCM : 0), 0);
    const sireIIH = chrLength_cM > 0 ? Math.min(1, sireAncLen / chrLength_cM) : 1;

    // IIH combinado del cromosoma: promedio ponderado 2:1 (dam 4x aporta 2 cromátidas)
    const gA = this._gameteCopiesA ?? 2;
    const gB = this._gameteCopiesB ?? 1;
    const IIH_chr = (gA * damIIH + gB * sireIIH) / (gA + gB);

    // Longitud media de bloque (dam + sire juntos)
    const allBlocks     = [...damBlocks, ...sireBlocks];
    const totalBlockLen = allBlocks.reduce((s, b) => s + b.lengthCM, 0);
    const meanBlockCM   = allBlocks.length > 0 ? totalBlockLen / allBlocks.length : chrLength_cM;

    return {
      damIIH, sireIIH, IIH_chr,
      damBlocks, sireBlocks,
      damRecombEvents:  this.countRecombEvents(damGam),
      sireRecombEvents: this.countRecombEvents(sireGam),
      meanBlockCM
    };
  },

  // ── [SK-1d] computeIIH_global ──────────────────────────────────
  // Calcula el IIH global desde el zigoto triploide muestral.
  // Requiere acceso al genoma y a los dos haplotipos gaméticos completos.
  //
  // chrResults: array de { chrId, damGam, sireGam, chrLength_cM }
  // Retorna { IIH_global, perChrom[], meanBlockCM_global, totalRecombEvents }
  computeIIH_global(chrResults) {
    let weightedIIH   = 0;
    let totalLen      = 0;
    let totalRecomb   = 0;
    let totalBlockLen = 0;
    let totalBlocks   = 0;
    const perChrom    = [];

    for (const chr of chrResults) {
      const chrLen = chr.chrLength_cM;
      const res    = this.computeIIH_chromosome(chr.damGam, chr.sireGam, chrLen);

      weightedIIH   += res.IIH_chr * chrLen;
      totalLen      += chrLen;
      totalRecomb   += res.damRecombEvents + res.sireRecombEvents;
      totalBlockLen += res.meanBlockCM * (res.damBlocks.length + res.sireBlocks.length);
      totalBlocks   += res.damBlocks.length + res.sireBlocks.length;

      perChrom.push({ chrId: chr.chrId, chrLen, ...res });
    }

    const IIH_global    = totalLen > 0 ? weightedIIH / totalLen : 1;
    const meanBlockCM_global = totalBlocks > 0 ? totalBlockLen / totalBlocks : 0;

    return { IIH_global, perChrom, meanBlockCM_global, totalRecombEvents: totalRecomb };
  },

  // ── [SK-1e] predictGenerationalDrift ───────────────────────────
  // Modela la degradación del IIH a través de generaciones.
  // Usa un modelo exponencial de fragmentación:
  //   IIH(g) = IIH_0 × exp(−λ × g)
  // donde λ = (1/2) × r_medio × n_loci  (tasa de fragmentación por generación)
  //
  // Para BC1 la aportación del donante se reduce a 50% del genoma por
  // retrocruzamiento, por lo que el IIH de introgresión es ×0.5 adicional.
  //
  // iih0: IIH inicial (simulación actual = P→F1 3x)
  // nLoci: número total de loci en el genoma MC
  // rMean: tasa de recombinación media (Haldane, usamos 0.091 @ 10 cM)
  // Retorna array de { gen, label, iih, color }
  predictGenerationalDrift(iih0, nLoci, rMean = 0.091) {
    const lambda = rMean * nLoci * 0.5; // tasa de fragmentación
    const gens   = [
      { label: 'P→F1',  g: 0, factor: 1.0,   bc: false },
      { label: 'F1→BC1',g: 1, factor: 0.50,  bc: true  },
      { label: 'BC1→S1',g: 2, factor: 0.75,  bc: false },
      { label: 'S1→S2', g: 3, factor: 0.875, bc: false },
      { label: 'S2→S3', g: 4, factor: 0.9375,bc: false },
    ];
    return gens.map(gen => {
      const fragDecay = Math.exp(-lambda * gen.g);
      const iih       = Math.min(1, Math.max(0, iih0 * gen.factor * fragDecay));
      const col = iih >= 0.75 ? '#00e5a0' : iih >= 0.50 ? '#f5a623' : '#f85149';
      return { gen: gen.label, iih, color: col, isBC: gen.bc };
    });
  }
};

// ─── Estado global SCOPE K ───────────────────────────────────────
let SK_STATE = null; // Almacena el último resultado del análisis K
