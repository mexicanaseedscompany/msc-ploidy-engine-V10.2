;(function () {
  'use strict';
  // ═══════════════════════════════════════════════════════════════════
  //  MSCBreeding · data-model — schema, enums, validadores  (FASE 1)
  //
  //  Reglas de diseño:
  //   · Un campo ausente NO se inventa: create() lo deja en null. null = "desconocido".
  //   · Los registros legacy (record_origin='legacy') solo exigen identificadores y metadatos.
  //   · La procedencia (provenance) es una enumeración cerrada y CADA entidad solo admite
  //     los valores que le corresponden: una simulación no puede declararse OBSERVED, etc.
  //   · validate() nunca elimina ni corrige datos: solo clasifica VALID / WARNING / INVALID.
  // ═══════════════════════════════════════════════════════════════════
  var NS = globalThis.MSCBreeding;
  if (!NS) throw new Error('MSCBreeding: cargar breeding-namespace.js primero');
  var SCHEMA_VERSION = NS.schema_version;

  function freezeAll(o) { Object.keys(o).forEach(function (k) { Object.freeze(o[k]); }); return Object.freeze(o); }

  var ENUMS = freezeAll({
    provenance:        ['SIMULATED', 'OBSERVED', 'CALIBRATED', 'PREDICTED', 'VALIDATED', 'INFERRED'],
    record_origin:     ['direct', 'imported', 'legacy'],
    sex:               ['female', 'male', 'hermaphrodite', 'unknown'],
    trait_type:        ['continuous', 'ordinal', 'binary', 'categorical', 'percentage', 'chemical'],
    quality_status:    ['VALID', 'WARNING', 'INVALID'],
    parental_source:   ['assumed', 'measured', 'unknown'],
    evidence_level:    ['L0', 'L1', 'L2', 'L3'],
    capability:        ['available', 'unavailable', 'assumed'],
    model_kind:        ['engine_calibration', 'statistical'],
    model_status:      ['candidate', 'active', 'retired'],
    validation_method: ['random_holdout', 'family_holdout', 'generational_holdout', 'cross_holdout', 'future_generation'],
    engine_channel:    ['phenotype', 'sdt:0', 'sdt:1', 'sdt:2', 'none', 'unknown']
  });

  // Procedencias admitidas por entidad (separación estricta SIMULATED/OBSERVED/…)
  var PROVENANCE_RULES = freezeAll({
    Observation:           ['OBSERVED'],
    SimulationContext:     ['SIMULATED'],
    PredictedDistribution: ['SIMULATED', 'CALIBRATED', 'PREDICTED', 'INFERRED'],
    CalibrationRecord:     ['CALIBRATED'],
    ValidationResult:      ['VALIDATED'],
    PredictionAudit:       ['SIMULATED', 'CALIBRATED', 'PREDICTED', 'INFERRED']
  });

  // ── Verificadores de tipo ────────────────────────────────────────
  var DATE_RE = /^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?$/;
  var TYPES = {
    string:  function (v) { return typeof v === 'string' && v.length > 0; },
    number:  function (v) { return typeof v === 'number' && isFinite(v); },
    integer: function (v) { return Number.isInteger(v); },
    boolean: function (v) { return typeof v === 'boolean'; },
    date:    function (v) {
      if (typeof v !== 'string' || !DATE_RE.test(v)) return false;
      var y = +v.slice(0, 4), mo = +v.slice(5, 7), d = +v.slice(8, 10), dt = new Date(Date.UTC(y, mo - 1, d));
      if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return false;   // 31 de febrero, mes 13...
      var tm = /[T ](\d{2}):(\d{2})(?::(\d{2}))?/.exec(v);
      return !(tm && (+tm[1] > 23 || +tm[2] > 59 || (tm[3] !== undefined && +tm[3] > 59)));
    },
    object:  function (v) { return v !== null && typeof v === 'object' && !Array.isArray(v); },
    array:   function (v) { return Array.isArray(v); },
    scalar:  function (v) { return (typeof v === 'number' && isFinite(v)) || typeof v === 'string' || typeof v === 'boolean'; }
  };

  // ── Definición de campos: F(tipo, opciones) ──────────────────────
  //  req:true  → obligatorio siempre · nl:true → obligatorio salvo registros legacy
  //  min/max   → rango numérico · enum → clave de ENUMS · def → valor por defecto explícito
  function F(t, o) { return Object.assign({ t: t }, o || {}); }
  var META = {
    schema_version: F('string', { req: true }),
    created_at:     F('date',   { req: true }),
    updated_at:     F('date',   { req: true })
  };
  function spec(fields, extra) {
    var e = Object.assign({ fields: Object.assign({}, fields, META), rules: [], key: null }, extra || {});
    return e;
  }
  function issue(level, field, code, message) { return { level: level, field: field, code: code, message: message }; }

  var SCHEMA = {
    Plant: spec({
      plant_id: F('string', { req: true }), family_id: F('string'), population_id: F('string'),
      mother_id: F('string'), father_id: F('string'),
      generation: F('string'), generation_index: F('integer', { min: 0 }),
      sex: F('string', { enum: 'sex' }), ploidy: F('integer', { min: 1 }),
      environment_id: F('string'), date_created: F('date'), date_evaluated: F('date'), notes: F('string'),
      record_origin: F('string', { req: true, enum: 'record_origin' })
    }, { key: 'plant_id', rules: [function (r) {
      var out = [];
      if (r.mother_id && r.mother_id === r.plant_id) out.push(issue('error', 'mother_id', 'SELF_PARENT', 'una planta no puede ser su propia madre'));
      if (r.father_id && r.father_id === r.plant_id) out.push(issue('error', 'father_id', 'SELF_PARENT', 'una planta no puede ser su propio padre'));
      if (r.date_created && r.date_evaluated && Date.parse(r.date_evaluated) < Date.parse(r.date_created))
        out.push(issue('error', 'date_evaluated', 'EVALUATED_BEFORE_CREATED', 'date_evaluated anterior a date_created'));
      return out; }] }),

    Cross: spec({
      cross_id: F('string', { req: true }), mother_id: F('string'), father_id: F('string'),
      cross_date: F('date'), generation: F('string'), population_size: F('integer', { min: 1 }),
      environment_id: F('string'),
      // Genotipo parental ABSTRACTO usado por el motor (clase de dosis), no un genotipo medido
      parental_assumption: F('object'),
      notes: F('string'), record_origin: F('string', { req: true, enum: 'record_origin' })
    }, { key: 'cross_id', rules: [function (r) {
      var out = [];
      if (r.mother_id == null) out.push(issue('warning', 'mother_id', 'PARENT_UNKNOWN', 'madre desconocida'));
      if (r.father_id == null) out.push(issue('warning', 'father_id', 'PARENT_UNKNOWN', 'padre desconocido'));
      var pa = r.parental_assumption;
      if (pa != null) {
        if (!TYPES.object(pa)) return out;
        if (pa.source == null || ENUMS.parental_source.indexOf(pa.source) < 0)
          out.push(issue('error', 'parental_assumption.source', 'INVALID_ENUM', 'source debe ser assumed|measured|unknown'));
        ['ploidy_a', 'ploidy_b', 'dose_class_a', 'dose_class_b'].forEach(function (k) {
          if (pa[k] != null && !Number.isInteger(pa[k])) out.push(issue('error', 'parental_assumption.' + k, 'WRONG_TYPE', k + ' debe ser entero o null'));
        });
      }
      return out; }] }),

    Population: spec({
      population_id: F('string', { req: true }), cross_id: F('string'), generation: F('string'),
      planned_size: F('integer', { min: 1 }), actual_size: F('integer', { min: 0 }),
      environment_id: F('string'), date: F('date'),
      record_origin: F('string', { req: true, enum: 'record_origin' })
    }, { key: 'population_id', rules: [function (r) {
      return (r.planned_size != null && r.actual_size != null && r.actual_size > r.planned_size)
        ? [issue('warning', 'actual_size', 'ACTUAL_GT_PLANNED', 'actual_size mayor que planned_size')] : []; }] }),

    Environment: spec({
      environment_id: F('string', { req: true }), location: F('string'), season: F('string'),
      temperature: F('number'), humidity: F('number', { min: 0, max: 100 }), light: F('string'),
      substrate: F('string'), nutrition_program: F('string'), irrigation_program: F('string'),
      management_protocol: F('string'), date_start: F('date'), date_end: F('date'), notes: F('string')
    }, { key: 'environment_id', rules: [function (r) {
      return (r.date_start && r.date_end && Date.parse(r.date_end) < Date.parse(r.date_start))
        ? [issue('error', 'date_end', 'END_BEFORE_START', 'date_end anterior a date_start')] : []; }] }),

    Trait: spec({
      trait_id: F('string', { req: true }), name: F('string', { req: true }),
      type: F('string', { req: true, enum: 'trait_type' }), unit: F('string'),
      scale_min: F('number'), scale_max: F('number'), higher_is_better: F('boolean'),
      measurement_method: F('string'),
      heritability: F('number', { min: 0, max: 1 }), heritability_source: F('string'),
      // Canal del motor con el que este carácter es comparable; 'unknown' hasta que se documente
      engine_channel: F('string', { enum: 'engine_channel', def: 'unknown' })
    }, { key: 'trait_id', rules: [function (r) {
      var out = [];
      if (r.scale_min != null && r.scale_max != null && !(r.scale_min < r.scale_max))
        out.push(issue('error', 'scale_max', 'BAD_SCALE', 'scale_min debe ser menor que scale_max'));
      if (r.heritability != null && r.heritability_source == null)
        out.push(issue('error', 'heritability_source', 'SOURCE_REQUIRED', 'una heredabilidad debe declarar su fuente (no se acepta sin origen)'));
      return out; }] }),

    Observation: spec({
      observation_id: F('string', { req: true }), plant_id: F('string', { req: true }), trait_id: F('string', { req: true }),
      value: F('scalar', { req: true }), unit: F('string'), measurement_method: F('string'), observer: F('string'),
      date: F('date'), environment_id: F('string'), confidence: F('number', { min: 0, max: 1 }),
      replicate: F('integer', { min: 1 }), provenance: F('string', { req: true, enum: 'provenance' }),
      record_origin: F('string', { req: true, enum: 'record_origin' })
    }, { key: 'observation_id' }),

    Genotype: spec({
      plant_id: F('string', { req: true }), marker_id: F('string', { req: true }),
      chromosome: F('string'), position: F('number', { min: 0 }), allele: F('string'),
      dosage: F('integer', { min: 0 }), quality: F('number'), source: F('string')
    }, { key: function (r) { return (r.plant_id == null || r.marker_id == null) ? null : r.plant_id + '|' + r.marker_id; } }),

    SimulationContext: spec({
      simulation_id: F('string', { req: true }), legacy_id: F('integer'),
      engine_version: F('string', { nl: true }), seed: F('integer', { nl: true, min: 0 }), N: F('integer', { nl: true, min: 1 }),
      ploidy_a: F('integer', { nl: true, min: 1 }), ploidy_b: F('integer', { nl: true, min: 1 }),
      dose_class_a: F('integer', { nl: true, min: 0 }), dose_class_b: F('integer', { nl: true, min: 0 }),
      alpha: F('number', { nl: true, min: 0, max: 1 }), pairing_mode: F('object'),
      muBase: F('number', { nl: true }), efectoAdit: F('number', { nl: true }), h2: F('number', { nl: true, min: 0, max: 1 }),
      sigmaE: F('number', { nl: true, min: 0 }), domCoef: F('number', { nl: true }), epiCoef: F('number', { nl: true }),
      trait_weights: F('array'), epistasis_configuration: F('array'), genome_configuration: F('object'),
      evidence_level_selected: F('string', { nl: true, enum: 'evidence_level' }), evidence_flags: F('object'),
      environment_id: F('string'),
      original: F('object'),   // copia literal del registro legacy (strings originales), sin reinterpretar
      provenance: F('string', { req: true, enum: 'provenance' }),
      record_origin: F('string', { req: true, enum: 'record_origin' })
    }, { key: 'simulation_id' }),

    PredictedDistribution: spec({
      prediction_id: F('string', { req: true }), simulation_id: F('string'), trait_id: F('string'), trait_channel: F('string'),
      n_virtual: F('integer', { min: 1 }), mean: F('number', { nl: true }), variance: F('number', { min: 0 }),
      sd: F('number', { min: 0 }), cv: F('number'), quantiles: F('object'), uncertainty: F('object'),
      model_id: F('string'), model_version: F('string'), calibration_id: F('string'), training_dataset_version: F('string'),
      provenance: F('string', { req: true, enum: 'provenance' }),
      record_origin: F('string', { req: true, enum: 'record_origin' })
    }, { key: 'prediction_id', rules: [function (r) {
      var out = [];
      if (r.provenance === 'PREDICTED') ['model_id', 'model_version', 'training_dataset_version'].forEach(function (k) {
        if (r[k] == null) out.push(issue('error', k, 'PREDICTED_NEEDS_MODEL', 'una predicción PREDICTED debe indicar ' + k)); });
      if (r.provenance === 'CALIBRATED' && r.calibration_id == null)
        out.push(issue('error', 'calibration_id', 'CALIBRATED_NEEDS_CALIBRATION', 'CALIBRATED requiere calibration_id'));
      if (r.provenance === 'SIMULATED' && (r.model_id != null || r.calibration_id != null))
        out.push(issue('error', 'provenance', 'SIMULATED_WITH_MODEL', 'una salida SIMULATED no puede referir un modelo ni una calibración'));
      var q = r.quantiles;
      if (q != null && TYPES.object(q)) {
        var order = ['p10', 'p25', 'p50', 'p75', 'p90', 'p95'], prev = null;
        order.forEach(function (k) { if (q[k] != null) {
          if (!TYPES.number(q[k])) out.push(issue('error', 'quantiles.' + k, 'WRONG_TYPE', 'cuantil no numérico'));
          else { if (prev !== null && q[k] < prev) out.push(issue('error', 'quantiles.' + k, 'QUANTILES_NOT_MONOTONE', 'los cuantiles deben ser no decrecientes')); prev = q[k]; } } });
      }
      var u = r.uncertainty;
      if (u != null && TYPES.object(u) && u.interval_low != null && u.interval_high != null && u.interval_low > u.interval_high)
        out.push(issue('error', 'uncertainty', 'BAD_INTERVAL', 'interval_low mayor que interval_high'));
      return out; }] }),

    CalibrationRecord: spec({
      calibration_id: F('string', { req: true }), simulation_id: F('string'), trait_id: F('string'),
      observation_ids: F('array'), n_observations: F('integer', { min: 0 }), metrics: F('object'),
      model_version_before: F('string'), model_version_after: F('string'),
      legacy_accuracy: F('number'),   // métrica histórica 100−|error%|; solo compatibilidad
      provenance: F('string', { req: true, enum: 'provenance' }),
      record_origin: F('string', { req: true, enum: 'record_origin' })
    }, { key: 'calibration_id' }),

    ModelVersion: spec({
      model_id: F('string', { req: true }), version: F('string', { req: true }),
      kind: F('string', { req: true, enum: 'model_kind' }), algorithm: F('string', { req: true }),
      training_dataset_version: F('string'), training_date: F('date'), features: F('array'), parameters: F('object'),
      validation_method: F('string', { enum: 'validation_method' }), metrics: F('object'),
      status: F('string', { req: true, enum: 'model_status', def: 'candidate' }), notes: F('string')
    }, { key: function (r) { return (r.model_id == null || r.version == null) ? null : r.model_id + '@' + r.version; }, rules: [function (r) {
      var m = r.metrics, out = [];
      if (r.status === 'active' && !(m && TYPES.object(m) && m.test != null))
        out.push(issue('warning', 'metrics', 'NO_OUT_OF_SAMPLE_METRICS', 'modelo active sin métricas de test fuera de muestra'));
      return out; }] }),

    BreedingCycle: spec({
      cycle_id: F('string', { req: true }), generation: F('string'), training_dataset_version: F('string'),
      model_version: F('string'), crosses: F('array'), predictions: F('array'), observations: F('array'),
      validation_results: F('array'), date_start: F('date'), date_end: F('date')
    }, { key: 'cycle_id', rules: [function (r) {
      return (r.date_start && r.date_end && Date.parse(r.date_end) < Date.parse(r.date_start))
        ? [issue('error', 'date_end', 'END_BEFORE_START', 'date_end anterior a date_start')] : []; }] }),

    ValidationResult: spec({
      validation_id: F('string', { req: true }), model_id: F('string'), model_version: F('string'),
      method: F('string', { req: true, enum: 'validation_method' }),
      training_units: F('object', { req: true }), test_units: F('object', { req: true }),
      leakage_prone: F('boolean'), disjoint: F('boolean'),
      metrics: F('object', { req: true }),
      provenance: F('string', { req: true, enum: 'provenance' })
    }, { key: 'validation_id', rules: [function (r) {
      var out = [];
      if (r.metrics && TYPES.object(r.metrics) && r.metrics.test == null)
        out.push(issue('error', 'metrics.test', 'VALIDATED_NEEDS_TEST_METRICS', 'VALIDATED exige métricas de test fuera de muestra'));
      if (r.method === 'random_holdout' && r.leakage_prone !== true)
        out.push(issue('error', 'leakage_prone', 'RANDOM_HOLDOUT_MUST_FLAG_LEAKAGE', 'random_holdout debe declararse leakage_prone=true'));
      if (r.method !== 'random_holdout' && r.disjoint !== true)
        out.push(issue('error', 'disjoint', 'SPLIT_NOT_DISJOINT', 'la validación por familia/generación/cruce exige unidades disjuntas (disjoint=true)'));
      return out; }] }),

    PredictionAudit: spec({
      audit_id: F('string', { req: true }), prediction_id: F('string', { req: true }),
      dataset_version: F('string'), model_id: F('string'), model_version: F('string'),
      parameters: F('object'), seed: F('integer', { min: 0 }), training_population: F('object'),
      generation: F('string'), environment_id: F('string'), evidence: F('object'), inputs_hash: F('string'),
      provenance: F('string', { req: true, enum: 'provenance' })
    }, { key: 'audit_id' }),

    EvidenceState: spec({
      evidence_state_id: F('string', { req: true }),
      selected_level: F('string', { req: true, enum: 'evidence_level' }),   // techo máximo, NO capacidad
      levels: F('object', { req: true })
    }, { key: 'evidence_state_id', rules: [function (r) {
      var out = [], L = r.levels;
      if (!TYPES.object(L)) return out;
      Object.keys(L).forEach(function (lv) {
        var s = L[lv], f = 'levels.' + lv;
        if (ENUMS.evidence_level.indexOf(lv) < 0) { out.push(issue('error', f, 'INVALID_ENUM', 'nivel desconocido')); return; }
        if (!TYPES.object(s)) { out.push(issue('error', f, 'WRONG_TYPE', 'se esperaba objeto')); return; }
        ['data_available', 'data_required', 'data_missing', 'inference_used'].forEach(function (k) {
          if (!TYPES.array(s[k])) out.push(issue('error', f + '.' + k, 'WRONG_TYPE', k + ' debe ser un arreglo')); });
        ['observed_data', 'simulated_data'].forEach(function (k) {
          if (!TYPES.boolean(s[k])) out.push(issue('error', f + '.' + k, 'WRONG_TYPE', k + ' debe ser booleano')); });
        if (ENUMS.capability.indexOf(s.capability) < 0) out.push(issue('error', f + '.capability', 'INVALID_ENUM', 'capability inválida'));
        if (s.capability === 'available' && TYPES.array(s.data_missing) && s.data_missing.length > 0)
          out.push(issue('error', f + '.capability', 'CAPABILITY_WITHOUT_DATA', 'capability=available con datos faltantes: un nivel seleccionado no crea capacidad'));
        if (s.capability === 'assumed' && s.simulated_data !== true)
          out.push(issue('warning', f + '.simulated_data', 'ASSUMED_WITHOUT_SIMULATED_FLAG', 'capacidad "assumed" debería marcar simulated_data=true'));
      });
      return out; }] })
  };
  Object.keys(SCHEMA).forEach(function (n) { SCHEMA[n].name = n; });

  // ── Utilidades ───────────────────────────────────────────────────
  // jsonUnsafe(): rutas con valores que JSON.stringify alteraria EN SILENCIO (NaN/Infinity -> null,
  // Date -> string, funciones omitidas). Un dato asi NO se guarda: convertir NaN en null falsificaria "desconocido".
  function isPlain(v) {
    if (v === null || typeof v !== 'object' || Object.prototype.toString.call(v) !== '[object Object]') return false;
    var proto = Object.getPrototypeOf(v);
    return proto === null || Object.getPrototypeOf(proto) === null;   // plano de cualquier realm; clases/Date/Map no
  }
  function jsonUnsafe(v, path, depth, out) {
    out = out || []; depth = depth || 0; path = path || '';
    if (depth > 20) { out.push(path || '(raiz)'); return out; }
    var t = typeof v;
    if (v === null || t === 'string' || t === 'boolean' || t === 'undefined') return out;   // undefined = ausente
    if (t === 'number') { if (!isFinite(v)) out.push(path || '(raiz)'); return out; }
    if (t === 'function' || t === 'symbol' || t === 'bigint') { out.push(path || '(raiz)'); return out; }
    if (Array.isArray(v)) { v.forEach(function (x, k) { jsonUnsafe(x, path + '[' + k + ']', depth + 1, out); }); return out; }
    if (!isPlain(v)) { out.push(path || '(raiz)'); return out; }   // Date, Map, instancias de clase
    Object.keys(v).forEach(function (k) { jsonUnsafe(v[k], path ? path + '.' + k : k, depth + 1, out); });
    return out;
  }
  function clone(o) { return o === undefined ? undefined : JSON.parse(JSON.stringify(o)); }
  // copy(): copia profunda de arreglos/objetos planos que conserva los valores tal cual (a diferencia de JSON).
  function copy(v) {
    if (Array.isArray(v)) return v.map(copy);
    if (isPlain(v)) {
      var o = {}; Object.keys(v).forEach(function (k) { o[k] = copy(v[k]); }); return o;
    }
    return v;
  }
  function nowISO() { return new Date().toISOString(); }
  function entityOf(name) { var s = SCHEMA[name]; if (!s) throw new Error('MSCBreeding: entidad desconocida: ' + name); return s; }
  function keyOf(name, rec) { var k = entityOf(name).key; return typeof k === 'function' ? k(rec) : rec[k]; }

  // create(): NO inventa datos. Campos no suministrados → null (desconocido); solo se aplican
  // defaults declarados en el schema (engine_channel, status), provenance única por entidad y metadatos.
  function create(name, fields, opts) {
    var s = entityOf(name), o = opts || {}, ts = (o.clock ? o.clock() : nowISO());
    var rec = {};
    Object.keys(s.fields).forEach(function (f) { rec[f] = null; });
    Object.keys(fields || {}).forEach(function (f) { rec[f] = copy(fields[f]); });   // copy(): NO altera NaN/Infinity (validate() los marca)
    Object.keys(s.fields).forEach(function (f) {
      var d = s.fields[f];
      if (rec[f] === null && d.def !== undefined) rec[f] = d.def;
    });
    if (rec.schema_version == null) rec.schema_version = SCHEMA_VERSION;
    if (rec.created_at == null) rec.created_at = ts;
    if (rec.updated_at == null) rec.updated_at = ts;
    var pr = PROVENANCE_RULES[name];
    if (pr && pr.length === 1 && (fields == null || fields.provenance == null)) rec.provenance = pr[0];
    return rec;
  }

  // ── Validación ───────────────────────────────────────────────────
  function checkField(name, def, v, out) {
    if (!TYPES[def.t](v)) { out.push(issue('error', name, 'WRONG_TYPE', 'se esperaba ' + def.t)); return; }
    if (def.min !== undefined && v < def.min) out.push(issue('error', name, 'OUT_OF_RANGE', 'menor que ' + def.min));
    if (def.max !== undefined && v > def.max) out.push(issue('error', name, 'OUT_OF_RANGE', 'mayor que ' + def.max));
    if (def.enum && ENUMS[def.enum].indexOf(v) < 0) out.push(issue('error', name, 'INVALID_ENUM', 'valor fuera de ' + def.enum + ': ' + ENUMS[def.enum].join('|')));
  }

  function validate(name, rec) {
    var s = entityOf(name), issues = [];
    if (!TYPES.object(rec)) return { entity: name, status: 'INVALID', errors: [issue('error', '', 'WRONG_TYPE', 'el registro debe ser un objeto')], warnings: [] };
    jsonUnsafe(rec).forEach(function (pth) { issues.push(issue('error', pth, 'NOT_JSON_SAFE', 'valor no representable en JSON sin alterarse (NaN/Infinity/Date/funcion/objeto no plano)')); });
    var legacy = rec.record_origin === 'legacy';
    Object.keys(s.fields).forEach(function (f) {
      var d = s.fields[f], v = rec[f];
      var must = d.req || (d.nl && !legacy);
      if (v === undefined || v === null) {
        if (must) issues.push(issue('error', f, v === undefined ? 'MISSING_REQUIRED' : 'NULL_REQUIRED', 'campo obligatorio'));
        return;
      }
      checkField(f, d, v, issues);
    });
    Object.keys(rec).forEach(function (f) { if (!(f in s.fields)) issues.push(issue('warning', f, 'UNKNOWN_FIELD', 'campo no definido en el schema')); });
    if (rec.schema_version != null && rec.schema_version !== SCHEMA_VERSION)
      issues.push(issue('warning', 'schema_version', 'SCHEMA_VERSION_MISMATCH', 'schema_version ' + rec.schema_version + ' ≠ ' + SCHEMA_VERSION));
    var pr = PROVENANCE_RULES[name];
    if (pr && rec.provenance != null && ENUMS.provenance.indexOf(rec.provenance) >= 0 && pr.indexOf(rec.provenance) < 0)
      issues.push(issue('error', 'provenance', 'PROVENANCE_NOT_ALLOWED', name + ' solo admite provenance ' + pr.join('|') + ', no ' + rec.provenance));
    if (!issues.some(function (i) { return i.level === 'error' && (i.code === 'WRONG_TYPE' || i.code === 'MISSING_REQUIRED'); }))
      s.rules.forEach(function (rule) { issues = issues.concat(rule(rec)); });
    var errors = issues.filter(function (i) { return i.level === 'error'; });
    var warnings = issues.filter(function (i) { return i.level === 'warning'; });
    return { entity: name, status: errors.length ? 'INVALID' : (warnings.length ? 'WARNING' : 'VALID'), errors: errors, warnings: warnings };
  }

  // Coherencia valor↔carácter (el valor se valida contra el tipo/escala del Trait registrado)
  function validateObservationValue(obs, trait) {
    var out = [], v = obs.value, t = trait.type, f = 'value';
    if (t === 'continuous' || t === 'percentage' || t === 'chemical') {
      if (!TYPES.number(v)) out.push(issue('error', f, 'WRONG_TYPE', 'valor numérico esperado para ' + t));
      else {
        if (t === 'percentage' && (v < 0 || v > 100)) out.push(issue('error', f, 'OUT_OF_RANGE', 'porcentaje fuera de 0–100'));
        if (trait.scale_min != null && v < trait.scale_min) out.push(issue('error', f, 'OUT_OF_RANGE', 'menor que scale_min'));
        if (trait.scale_max != null && v > trait.scale_max) out.push(issue('error', f, 'OUT_OF_RANGE', 'mayor que scale_max'));
      }
    } else if (t === 'ordinal') {
      if (!TYPES.integer(v)) out.push(issue('error', f, 'WRONG_TYPE', 'entero esperado para ordinal'));
      else if ((trait.scale_min != null && v < trait.scale_min) || (trait.scale_max != null && v > trait.scale_max))
        out.push(issue('error', f, 'OUT_OF_RANGE', 'fuera de la escala ordinal'));
    } else if (t === 'binary') {
      if (!(v === 0 || v === 1 || v === true || v === false)) out.push(issue('error', f, 'WRONG_TYPE', 'binario: 0/1/true/false'));
    } else if (t === 'categorical') {
      if (!TYPES.string(v)) out.push(issue('error', f, 'WRONG_TYPE', 'categoría (string) esperada'));
    }
    if (trait.unit != null && obs.unit != null && obs.unit !== trait.unit)
      out.push(issue('warning', 'unit', 'UNIT_MISMATCH', 'unidad ' + obs.unit + ' ≠ unidad del carácter ' + trait.unit));
    var errors = out.filter(function (i) { return i.level === 'error'; }), warnings = out.filter(function (i) { return i.level === 'warning'; });
    return { entity: 'Observation.value', status: errors.length ? 'INVALID' : (warnings.length ? 'WARNING' : 'VALID'), errors: errors, warnings: warnings };
  }

  // Descripción del schema (para documentación generada)
  function describe(name) {
    var s = entityOf(name);
    return Object.keys(s.fields).map(function (f) {
      var d = s.fields[f];
      return { field: f, type: d.t, required: d.req ? 'siempre' : (d.nl ? 'salvo legacy' : 'no'), enum: d.enum || null,
               min: d.min === undefined ? null : d.min, max: d.max === undefined ? null : d.max, default: d.def === undefined ? null : d.def };
    });
  }

  NS.register('data-model', {
    SCHEMA_VERSION: SCHEMA_VERSION, ENUMS: ENUMS, PROVENANCE_RULES: PROVENANCE_RULES, SCHEMA: SCHEMA,
    entities: function () { return Object.keys(SCHEMA); },
    create: create, validate: validate, validateObservationValue: validateObservationValue,
    keyOf: keyOf, describe: describe, clone: clone, jsonUnsafe: jsonUnsafe
  });
})();
