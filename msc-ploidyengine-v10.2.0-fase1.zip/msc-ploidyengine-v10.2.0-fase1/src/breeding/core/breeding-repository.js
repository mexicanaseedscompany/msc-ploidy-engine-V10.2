;(function () {
  'use strict';
  // ═══════════════════════════════════════════════════════════════════
  //  MSCBreeding · repository — interfaz BreedingRepository + InMemoryRepository  (FASE 1)
  //
  //  Contrato (el resto de la capa depende SOLO de esta interfaz, no del almacenamiento):
  //    insert, get, has, list, count, update, remove, clear, snapshot, restore  (todas devuelven Promise)
  //    collections() es sincrona (lista estatica).
  //  La interfaz es ASINCRONA desde el inicio: IndexedDB / servidor / API podran sustituir a la implementacion
  //  en memoria SIN reescribir a los llamadores. Los errores son promesas rechazadas (RepositoryError).
  //  Garantías:
  //    · Nunca sobrescribe en silencio: insert con clave existente lanza DuplicateKeyError.
  //    · Registros INVALID se rechazan (ValidationError con el informe); WARNING se acepta y se informa.
  //    · update no puede cambiar la clave ni la procedencia (no se "promueve" SIMULATED→OBSERVED).
  //    · Entra y sale por copia profunda: nada del estado interno se comparte con quien llama.
  //    · Sin localStorage, sin DOM, sin aleatoriedad. Sustituir por IndexedDB/servidor = otra implementación.
  // ═══════════════════════════════════════════════════════════════════
  var NS = globalThis.MSCBreeding;
  if (!NS || !NS.modules['data-model']) throw new Error('MSCBreeding: cargar namespace y data-model primero');
  var DM = NS.modules['data-model'];

  var COLLECTIONS = Object.freeze({
    plants: 'Plant', crosses: 'Cross', populations: 'Population', environments: 'Environment',
    traits: 'Trait', observations: 'Observation', genotypes: 'Genotype',
    simulations: 'SimulationContext', predictions: 'PredictedDistribution', calibrations: 'CalibrationRecord',
    models: 'ModelVersion', cycles: 'BreedingCycle', validations: 'ValidationResult',
    audits: 'PredictionAudit', evidence_states: 'EvidenceState'
  });

  function RepositoryError(code, message, detail) {
    var e = new Error(message); e.name = 'RepositoryError'; e.code = code; if (detail !== undefined) e.detail = detail; return e;
  }
  function ent(collection) {
    var n = COLLECTIONS[collection];
    if (!n) throw RepositoryError('UNKNOWN_COLLECTION', 'colección desconocida: ' + collection);
    return n;
  }

  // ── Interfaz (documentada; las implementaciones deben proveer todos los métodos) ──
  var INTERFACE = Object.freeze(['insert', 'get', 'has', 'list', 'count', 'update', 'remove', 'clear', 'collections', 'snapshot', 'restore']);
  function implementsRepository(obj) {
    return INTERFACE.filter(function (m) { return !obj || typeof obj[m] !== 'function'; });   // métodos faltantes
  }

  // ── Implementación en memoria ────────────────────────────────────
  function InMemoryRepository(opts) {
    var o = opts || {};
    var clock = o.clock || function () { return new Date().toISOString(); };
    var store = {};
    Object.keys(COLLECTIONS).forEach(function (c) { store[c] = new Map(); });
    var self = {};

    self.collections = function () { return Object.keys(COLLECTIONS); };

    self.insert = function (collection, record) {
      var name = ent(collection);
      var report = DM.validate(name, record);          // se valida el ORIGINAL (antes de clonar: NaN no se vuelve null)
      var rec = DM.clone(record);
      if (report.status === 'INVALID') throw RepositoryError('VALIDATION_FAILED', 'registro inválido para ' + collection, report);
      var key = DM.keyOf(name, rec);
      if (key == null || key === '') throw RepositoryError('MISSING_KEY', 'clave ausente en ' + collection);
      if (store[collection].has(key)) throw RepositoryError('DUPLICATE_KEY', 'ya existe ' + collection + '/' + key + ' (no se sobrescribe)', { key: key });
      store[collection].set(key, rec);
      return { key: key, record: DM.clone(rec), validation: report };
    };

    self.get = function (collection, key) { ent(collection); var r = store[collection].get(key); return r === undefined ? null : DM.clone(r); };
    self.has = function (collection, key) { ent(collection); return store[collection].has(key); };
    self.count = function (collection) { ent(collection); return store[collection].size; };
    self.list = function (collection, predicate) {
      ent(collection); var out = [];
      store[collection].forEach(function (r) { var c = DM.clone(r); if (!predicate || predicate(c)) out.push(c); });
      return out;
    };

    // update: merge superficial. Prohibido cambiar clave y procedencia. Concurrencia optimista opcional.
    self.update = function (collection, key, patch, options) {
      var name = ent(collection), cur = store[collection].get(key);
      if (cur === undefined) throw RepositoryError('NOT_FOUND', 'no existe ' + collection + '/' + key);
      var ex = options && options.expected_updated_at;
      if (ex !== undefined && ex !== cur.updated_at) throw RepositoryError('CONFLICT', 'updated_at cambió: esperado ' + ex + ', actual ' + cur.updated_at);
      var bad = DM.jsonUnsafe(patch || {});
      if (bad.length) throw RepositoryError('VALIDATION_FAILED', 'el parche contiene valores no representables en JSON: ' + bad.join(', '), { unsafe: bad });
      var next = Object.assign(DM.clone(cur), DM.clone(patch || {}));
      if (DM.keyOf(name, next) !== key) throw RepositoryError('KEY_IMMUTABLE', 'la clave no puede modificarse');
      if ('provenance' in (patch || {}) && patch.provenance !== cur.provenance)
        throw RepositoryError('PROVENANCE_IMMUTABLE', 'la procedencia no puede cambiarse (' + cur.provenance + ' → ' + patch.provenance + '); cree un registro nuevo');
      if ('created_at' in (patch || {}) && patch.created_at !== cur.created_at) throw RepositoryError('CREATED_AT_IMMUTABLE', 'created_at es inmutable');
      next.updated_at = clock();
      var report = DM.validate(name, next);
      if (report.status === 'INVALID') throw RepositoryError('VALIDATION_FAILED', 'la actualización dejaría el registro inválido', report);
      store[collection].set(key, next);
      return { key: key, record: DM.clone(next), validation: report };
    };

    self.remove = function (collection, key) {
      ent(collection); var r = store[collection].get(key);
      if (r === undefined) throw RepositoryError('NOT_FOUND', 'no existe ' + collection + '/' + key);
      store[collection].delete(key); return DM.clone(r);
    };
    self.clear = function (collection) { ent(collection); var n = store[collection].size; store[collection].clear(); return n; };

    self.snapshot = function () {
      var cols = {};
      Object.keys(COLLECTIONS).forEach(function (c) { cols[c] = self.list(c); });
      return { schema_version: DM.SCHEMA_VERSION, created_at: clock(), collections: cols };
    };
    // restore: por defecto SOLO sobre un repositorio vacío (no sobrescribe en silencio)
    self.restore = function (snap, options) {
      if (!snap || !snap.collections) throw RepositoryError('BAD_SNAPSHOT', 'snapshot inválido');
      if (snap.schema_version !== DM.SCHEMA_VERSION) throw RepositoryError('SCHEMA_MISMATCH', 'schema_version ' + snap.schema_version + ' ≠ ' + DM.SCHEMA_VERSION);
      var nonEmpty = Object.keys(COLLECTIONS).some(function (c) { return store[c].size > 0; });
      if (nonEmpty && !(options && options.replace === true)) throw RepositoryError('NOT_EMPTY', 'el repositorio no está vacío; use {replace:true} explícito');
      // validar todo ANTES de tocar el estado (restauración atómica)
      var staged = {};
      Object.keys(snap.collections).forEach(function (c) {
        var name = ent(c); staged[c] = new Map();
        snap.collections[c].forEach(function (r) {
          var rep = DM.validate(name, r);
          if (rep.status === 'INVALID') throw RepositoryError('VALIDATION_FAILED', 'snapshot contiene registro inválido en ' + c, rep);
          var k = DM.keyOf(name, r);
          if (staged[c].has(k)) throw RepositoryError('DUPLICATE_KEY', 'clave duplicada en snapshot: ' + c + '/' + k);
          staged[c].set(k, DM.clone(r));
        });
      });
      Object.keys(COLLECTIONS).forEach(function (c) { store[c] = staged[c] || new Map(); });
      return Object.keys(COLLECTIONS).reduce(function (n, c) { return n + store[c].size; }, 0);
    };
    // Fachada asincrona: la logica es sincrona en memoria; toda excepcion pasa a promesa rechazada.
    var api = { collections: self.collections };
    ['insert', 'get', 'has', 'list', 'count', 'update', 'remove', 'clear', 'snapshot', 'restore'].forEach(function (m) {
      api[m] = function () { var a = arguments; return new Promise(function (resolve) { resolve(self[m].apply(null, a)); }); };
    });
    return api;
  }

  NS.register('repository', {
    COLLECTIONS: COLLECTIONS, INTERFACE: INTERFACE, RepositoryError: RepositoryError,
    implementsRepository: implementsRepository, InMemoryRepository: InMemoryRepository
  });
})();
