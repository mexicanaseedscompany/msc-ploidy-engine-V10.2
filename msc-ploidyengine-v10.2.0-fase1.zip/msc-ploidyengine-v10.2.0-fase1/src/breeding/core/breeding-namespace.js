;(function () {
  'use strict';
  // ═══════════════════════════════════════════════════════════════════
  //  MSCBreeding — Breeding Intelligence Layer  (FASE 1: INERTE)
  //
  //  Único símbolo global que introduce la capa. Fase 1 NO se conecta al motor:
  //    · no lee ni escribe _RNG, SIM_*, simLibrary, EPISTASIS_MATRIX ni el DOM
  //    · no usa localStorage ni Math.random
  //    · nada del motor lee `enabled`; con enabled=false o true el motor es idéntico
  //  Verificado por tests/golden (Golden Master en modos default/off/on).
  // ═══════════════════════════════════════════════════════════════════
  var root = globalThis;
  if (root.MSCBreeding) return;   // idempotente: una segunda carga no reemplaza nada

  var NS = {
    enabled: false,               // interruptor de la capa; false por defecto
    phase: 1,
    version: '1.0.0-phase1',
    schema_version: '1.0.0',
    modules: {},

    // Umbrales de suficiencia de datos: NO definidos. Se fijarán cuando existan datos reales
    // de plantas, familias y cruces. null = "no definido" (nunca se interpreta como 0).
    config: {
      insufficientData: {
        minPlants: null,
        minFamilies: null,
        minCrosses: null,
        minObservationsPerTrait: null
      }
    },

    register: function (name, api) {
      if (NS.modules[name]) throw new Error('MSCBreeding: módulo duplicado: ' + name);
      NS.modules[name] = api;
      return api;
    },

    status: function () {
      return { enabled: NS.enabled, phase: NS.phase, version: NS.version, schema_version: NS.schema_version,
               modules: Object.keys(NS.modules).sort(), engine_coupled: false };
    },

    setInsufficientDataThresholds: function (t) {
      var cfg = NS.config.insufficientData;
      Object.keys(t || {}).forEach(function (k) {
        if (!(k in cfg)) throw new Error('MSCBreeding: umbral desconocido: ' + k);
        if (t[k] !== null && !(Number.isInteger(t[k]) && t[k] >= 0)) throw new Error('MSCBreeding: umbral inválido para ' + k);
        cfg[k] = t[k];
      });
      return Object.assign({}, cfg);
    },

    // counts: {plants, families, crosses, observationsPerTrait}. Sin umbrales definidos → 'UNDEFINED'
    // (nunca 'SUFFICIENT' por omisión). Solo compara; no decide nada más.
    evaluateSufficiency: function (counts) {
      var cfg = NS.config.insufficientData, c = counts || {};
      var map = { minPlants: 'plants', minFamilies: 'families', minCrosses: 'crosses', minObservationsPerTrait: 'observationsPerTrait' };
      var undefinedT = [], short = [];
      Object.keys(map).forEach(function (k) {
        if (cfg[k] === null) { undefinedT.push(k); return; }
        if (!(typeof c[map[k]] === 'number' && c[map[k]] >= cfg[k])) short.push(k);
      });
      if (undefinedT.length) return { status: 'UNDEFINED', thresholds_undefined: undefinedT, short: short };
      return { status: short.length ? 'INSUFFICIENT DATA' : 'SUFFICIENT', thresholds_undefined: [], short: short };
    }
  };

  root.MSCBreeding = NS;
})();
