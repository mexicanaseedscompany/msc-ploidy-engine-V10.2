
// ═══════════════════════════════════════════════════════════════════
//  SCOPE K — Render Functions
// ═══════════════════════════════════════════════════════════════════

// [SK-5] renderIIHInline — mini card shown in Simulación tab
function renderIIHInline(iih, meanBlockCM, meanRecomb) {
  const iihPct  = (iih * 100).toFixed(1);
  const col     = iih >= 0.75 ? 'var(--accent)' : iih >= 0.50 ? 'var(--warn)' : 'var(--danger)';
  const label   = iih >= 0.75 ? 'INTEGRIDAD ALTA' : iih >= 0.50 ? 'INTEGRIDAD MODERADA' : 'FRAGMENTADO';
  const grade   = iih >= 0.75 ? 'elite' : iih >= 0.50 ? 'ok' : iih >= 0.30 ? 'warn' : 'bad';

  $('iihInlineCard').innerHTML = `
    <div style="background:var(--surface);border:1px solid ${col};border-radius:6px;padding:12px 16px;">
      <div style="font-size:9px;color:var(--muted);letter-spacing:.10em;font-weight:700;margin-bottom:8px;">
        🧬 SCOPE K — ÍNDICE DE INTEGRIDAD HAPLOTÍPICA (IIH) &nbsp;
        <span class="iih-grade-badge ${grade}">${label}</span>
      </div>
      <div style="display:flex;gap:20px;flex-wrap:wrap;align-items:center;">
        <div style="text-align:center;min-width:70px;">
          <div style="font-size:28px;font-weight:700;color:${col};">${iihPct}%</div>
          <div style="font-size:8px;color:var(--muted);margin-top:2px;">IIH POBLACIONAL</div>
        </div>
        <div style="flex:1;min-width:160px;">
          <div style="font-size:9px;color:var(--muted);margin-bottom:3px;">
            Longitud media de bloque: <strong style="color:var(--accent2)">${meanBlockCM.toFixed(2)} cM</strong> &nbsp;·&nbsp;
            Recomb. por ciclo: <strong style="color:var(--warn)">${meanRecomb.toFixed(2)}</strong>
          </div>
          <div style="background:var(--surface2);border-radius:3px;height:9px;overflow:hidden;border:1px solid var(--border);">
            <div style="height:100%;border-radius:3px;background:${col};width:${Math.max(iih*100,.3).toFixed(1)}%;transition:width .7s ease;"></div>
          </div>
          <div style="font-size:8px;color:var(--muted);margin-top:3px;">
            Ver análisis completo → Tab 🧬 TRAZABILIDAD K
          </div>
        </div>
      </div>
    </div>`;
}

// [SK-6] renderScopeKTab — full Scope K trazabilidad panel
function renderScopeKTab(iih, meanBlockCM, meanRecomb, skLastResult, driftGens, alpha, N) {

  // ── Hero Panel ──────────────────────────────────────────────────
  const iihPct  = (iih * 100).toFixed(1);
  const col     = iih >= 0.75 ? '#00e5a0' : iih >= 0.50 ? '#f5a623' : '#f85149';
  const grade   = iih >= 0.75 ? 'elite' : iih >= 0.50 ? 'ok' : iih >= 0.30 ? 'warn' : 'bad';
  const gradeLabel = iih >= 0.75 ? 'ÉLITE — CLON ORIGINAL' : iih >= 0.50 ? 'MODERADA' : iih >= 0.30 ? 'FRAGMENTADA' : 'ALTA DISPERSIÓN';

  // SVG ring params
  const R  = 34; const C = 2 * Math.PI * R;
  const filled = C * iih;

  $('iihHeroPanel').innerHTML = `
    <div class="iih-hero">
      <div class="iih-score-ring">
        <svg viewBox="0 0 80 80">
          <circle class="ring-bg" cx="40" cy="40" r="${R}"/>
          <circle class="ring-fg" cx="40" cy="40" r="${R}"
            stroke="${col}"
            stroke-dasharray="${filled.toFixed(2)} ${C.toFixed(2)}"
            stroke-dashoffset="0"/>
        </svg>
        <div class="iih-score-label">
          <span class="iih-score-num" style="color:${col};">${iihPct}</span>
          <span class="iih-score-pct">IIH %</span>
        </div>
      </div>

      <div class="iih-hero-body">
        <div class="iih-hero-title">ÍNDICE DE INTEGRIDAD HAPLOTÍPICA (IIH) — SCOPE K</div>
        <div class="iih-hero-formula">
          IIH = Σ(longitud_bloque_intacto × peso_origen) / longitud_genoma_total
        </div>
        <div class="iih-hero-stats">
          <div class="iih-hstat"><div class="iih-hstat-n" style="color:var(--accent2);">${meanBlockCM.toFixed(2)}</div><div class="iih-hstat-l">LONGITUD MEDIA<br>BLOQUE (cM)</div></div>
          <div class="iih-hstat"><div class="iih-hstat-n" style="color:var(--warn);">${meanRecomb.toFixed(2)}</div><div class="iih-hstat-l">RECOMB.<br>MEDIA/CICLO</div></div>
          <div class="iih-hstat"><div class="iih-hstat-n" style="color:var(--muted);">${N ? N.toLocaleString('es-MX') : '—'}</div><div class="iih-hstat-l">ITERACIONES<br>MC</div></div>
        </div>
      </div>

      <div class="iih-grade">
        <div class="iih-grade-badge ${grade}">${gradeLabel}</div>
        <div class="iih-grade-sub">α = ${alpha.toFixed(4)}</div>
      </div>
    </div>`;

  // ── Block Map per chromosome ─────────────────────────────────────
  if (skLastResult && skLastResult.perChrom && skLastResult.perChrom.length > 0) {
    let mapHTML = '';

    skLastResult.perChrom.forEach(chr => {
      const chrLen = chr.chrLen;

      // Build dam track HTML
      let damTrackHTML = '';
      let damTicksHTML = '';
      chr.damBlocks.forEach(block => {
        const left  = ((block.startCM / chrLen) * 100).toFixed(2);
        const width = Math.max(.5, (block.lengthCM / chrLen) * 100).toFixed(2);
        const cls   = block.isRecombinant ? 'recombined' : 'ancestral';
        const title = `${block.ancestorId} | ${block.lengthCM.toFixed(1)} cM | ${block.loci.length} loci`;
        damTrackHTML += `<div class="block-segment ${cls}"
          style="left:${left}%;width:${width}%;" title="${title}"></div>`;
      });
      // Locus ticks and names on dam track
      (chr.damGam || []).forEach(locus => {
        const pos = ((locus.pos_cM / chrLen) * 100).toFixed(2);
        damTicksHTML += `<div class="block-locus-tick" style="left:${pos}%;"></div>
          <div class="block-locus-name" style="left:${pos}%;">${locus.name.replace('QTL_','').replace('MC_C','L')}</div>`;
      });

      // Build sire track HTML
      let sireTrackHTML = '';
      chr.sireBlocks.forEach(block => {
        const left  = ((block.startCM / chrLen) * 100).toFixed(2);
        const width = Math.max(.5, (block.lengthCM / chrLen) * 100).toFixed(2);
        const cls   = block.isRecombinant ? 'sire-alt' : 'sire-orig';
        const title = `${block.ancestorId} | ${block.lengthCM.toFixed(1)} cM | ${block.loci.length} loci`;
        sireTrackHTML += `<div class="block-segment ${cls}"
          style="left:${left}%;width:${width}%;" title="${title}"></div>`;
      });

      const damEvts  = chr.damRecombEvents;
      const sireEvts = chr.sireRecombEvents;
      const chrIIH   = (chr.IIH_chr * 100).toFixed(1);
      const iihCol   = chr.IIH_chr >= 0.75 ? '#00e5a0' : chr.IIH_chr >= 0.50 ? '#f5a623' : '#f85149';

      mapHTML += `
        <div class="block-map-card">
          <div class="block-map-head">
            <span>${chr.chrId} — ${chrLen} cM &nbsp;·&nbsp;
              IIH<sub>chr</sub>: <span style="color:${iihCol};font-size:11px;">${chrIIH}%</span>
            </span>
            <div class="block-map-badges">
              <span class="bm-badge dam">♀ DAM: ${chr.damBlocks.length} bloq. / ${damEvts} recomb.</span>
              <span class="bm-badge sire">♂ SIRE: ${chr.sireBlocks.length} bloq. / ${sireEvts} recomb.</span>
            </div>
          </div>

          <div class="block-track-wrap">
            <div class="block-track-label" style="top:0px;">♀ DAM 4x</div>
            <div class="block-track dam-track">
              ${damTrackHTML}
              ${damTicksHTML}
            </div>
            <div class="block-track-label" style="top:22px;">♂ SIRE 2x</div>
            <div class="block-track sire-track">
              ${sireTrackHTML}
            </div>
          </div>
          <div class="block-track-axis">
            <span>0 cM</span>
            <span>${(chrLen / 2).toFixed(0)} cM</span>
            <span>${chrLen} cM</span>
          </div>

          <div class="block-metrics-grid">
            <div class="bm-card hi">
              <div class="bm-num green">${chrIIH}%</div>
              <div class="bm-lab">IIH CROMOSOMA</div>
            </div>
            <div class="bm-card">
              <div class="bm-num">${(chr.damIIH*100).toFixed(1)}%</div>
              <div class="bm-lab">IIH DAM 4x</div>
            </div>
            <div class="bm-card">
              <div class="bm-num blue">${(chr.sireIIH*100).toFixed(1)}%</div>
              <div class="bm-lab">IIH SIRE 2x</div>
            </div>
            <div class="bm-card">
              <div class="bm-num warn">${chr.meanBlockCM.toFixed(2)}</div>
              <div class="bm-lab">L̄ BLOQUE (cM)</div>
            </div>
            <div class="bm-card">
              <div class="bm-num">${chr.damBlocks.length + chr.sireBlocks.length}</div>
              <div class="bm-lab">TOTAL BLOQUES</div>
            </div>
            <div class="bm-card">
              <div class="bm-num red">${damEvts + sireEvts}</div>
              <div class="bm-lab">EVENTOS RECOMB.</div>
            </div>
          </div>
        </div>`;
    });

    $('blockMapDisplay').innerHTML = mapHTML;

    // ── Per-chromosome IIH table ─────────────────────────────────
    let chrTableHTML = `
      <table class="iih-chr-table">
        <thead>
          <tr>
            <th>Cromosoma</th>
            <th>Longitud (cM)</th>
            <th>IIH DAM ♀</th>
            <th>IIH SIRE ♂</th>
            <th>IIH CHR</th>
            <th>L̄ Bloque (cM)</th>
            <th>Bloques</th>
            <th>Recomb.</th>
            <th>Fragmentación</th>
          </tr>
        </thead>
        <tbody>`;
    skLastResult.perChrom.forEach(chr => {
      const iihCol = chr.IIH_chr >= 0.75 ? '#00e5a0' : chr.IIH_chr >= 0.50 ? '#f5a623' : '#f85149';
      const fragPct = ((1 - chr.IIH_chr) * 100).toFixed(1);
      const barWidth = Math.max(.3, chr.IIH_chr * 100).toFixed(1);
      chrTableHTML += `
        <tr>
          <td style="color:var(--accent);font-weight:700;">${chr.chrId}</td>
          <td>${chr.chrLen.toFixed(1)}</td>
          <td>${(chr.damIIH*100).toFixed(1)}%</td>
          <td style="color:var(--accent2);">${(chr.sireIIH*100).toFixed(1)}%</td>
          <td><span style="color:${iihCol};font-weight:700;">${(chr.IIH_chr*100).toFixed(1)}%</span>
            &nbsp;<span class="iih-mini-bar" style="width:${barWidth}px;background:${iihCol};"></span>
          </td>
          <td style="color:var(--warn)">${chr.meanBlockCM.toFixed(2)}</td>
          <td>${chr.damBlocks.length + chr.sireBlocks.length}</td>
          <td style="color:var(--danger)">${chr.damRecombEvents + chr.sireRecombEvents}</td>
          <td style="color:var(--muted)">${fragPct}%</td>
        </tr>`;
    });
    chrTableHTML += `</tbody></table>`;
    $('iihChrTable').innerHTML = chrTableHTML;

    // ── Recombination event log ───────────────────────────────────
    let logHTML = '';
    skLastResult.perChrom.forEach(chr => {
      const allGam = [...(chr.damGam || []), ...(chr.sireGam || [])];
      const origin = { 'dam': '♀ DAM', 'sire': '♂ SIRE' };
      let lastAnc = null;

      (chr.damGam || []).forEach((locus, i) => {
        if (i > 0 && locus.ancestorId !== lastAnc) {
          const prev = chr.damGam[i - 1];
          const dCM  = Math.abs(locus.pos_cM - prev.pos_cM);
          const r    = RecombinationEngine.haldane(prev.pos_cM, locus.pos_cM);
          logHTML += `<div class="recomb-log-entry">
            <span class="recomb-log-chr">${chr.chrId}</span>
            <span class="recomb-log-desc">
              ♀ Crossover entre <strong>${prev.name}</strong> (${prev.pos_cM}cM) → <strong>${locus.name}</strong> (${locus.pos_cM}cM) |
              ${prev.ancestorId} ↠ ${locus.ancestorId}
            </span>
            <span class="recomb-log-cm">Δ${dCM.toFixed(1)} cM</span>
            <span class="recomb-log-effect break">BREAK r=${r.toFixed(3)}</span>
          </div>`;
        } else if (i > 0) {
          const prev = chr.damGam[i - 1];
          const dCM  = Math.abs(locus.pos_cM - prev.pos_cM);
          logHTML += `<div class="recomb-log-entry">
            <span class="recomb-log-chr">${chr.chrId}</span>
            <span class="recomb-log-desc">
              ♀ Bloque continuo <strong>${prev.name}</strong>→<strong>${locus.name}</strong> |
              ancestorId: ${locus.ancestorId}
            </span>
            <span class="recomb-log-cm">Δ${dCM.toFixed(1)} cM</span>
            <span class="recomb-log-effect intact">INTACT</span>
          </div>`;
        }
        lastAnc = locus.ancestorId;
      });
      lastAnc = null;
      (chr.sireGam || []).forEach((locus, i) => {
        if (i > 0 && locus.ancestorId !== lastAnc) {
          const prev = chr.sireGam[i - 1];
          const dCM  = Math.abs(locus.pos_cM - prev.pos_cM);
          const r    = RecombinationEngine.haldane(prev.pos_cM, locus.pos_cM);
          logHTML += `<div class="recomb-log-entry">
            <span class="recomb-log-chr">${chr.chrId}</span>
            <span class="recomb-log-desc">
              ♂ Crossover entre <strong>${prev.name}</strong> (${prev.pos_cM}cM) → <strong>${locus.name}</strong> (${locus.pos_cM}cM) |
              ${prev.ancestorId} ↠ ${locus.ancestorId}
            </span>
            <span class="recomb-log-cm">Δ${dCM.toFixed(1)} cM</span>
            <span class="recomb-log-effect break">BREAK r=${r.toFixed(3)}</span>
          </div>`;
        } else if (i > 0) {
          const prev = chr.sireGam[i - 1];
          const dCM  = Math.abs(locus.pos_cM - prev.pos_cM);
          logHTML += `<div class="recomb-log-entry">
            <span class="recomb-log-chr">${chr.chrId}</span>
            <span class="recomb-log-desc">
              ♂ Bloque continuo <strong>${prev.name}</strong>→<strong>${locus.name}</strong> |
              ancestorId: ${locus.ancestorId}
            </span>
            <span class="recomb-log-cm">Δ${dCM.toFixed(1)} cM</span>
            <span class="recomb-log-effect intact">INTACT</span>
          </div>`;
        }
        lastAnc = locus.ancestorId;
      });
    });
    $('recombEventLog').innerHTML = logHTML || `<div class="recomb-log-entry"><span class="recomb-log-desc" style="color:var(--muted);">Sin eventos de recombinación en el último cigoto muestral.</span></div>`;

  } else {
    $('blockMapDisplay').innerHTML = '<div style="font-size:10px;color:var(--muted);text-align:center;padding:20px 0;">Sin datos de bloque disponibles.</div>';
    $('iihChrTable').innerHTML = '<div style="font-size:10px;color:var(--muted);text-align:center;padding:20px 0;">Sin datos.</div>';
  }

  // ── Generational Drift Panel ──────────────────────────────────────
  let driftHTML = `
    <div class="drift-header">PREDICCIÓN DE DEGRADACIÓN DEL IIH — MODELO λ-EXPONENCIAL</div>
    <div class="gen-legend">
      <div class="gen-legend-item"><div class="gen-legend-dot" style="background:#00e5a0;"></div>IIH ≥ 75% — Élite</div>
      <div class="gen-legend-item"><div class="gen-legend-dot" style="background:#f5a623;"></div>IIH 50–74% — Moderado</div>
      <div class="gen-legend-item"><div class="gen-legend-dot" style="background:#f85149;"></div>IIH &lt; 50% — Fragmentado</div>
    </div>
    <div class="drift-grid">`;

  driftGens.forEach((g, i) => {
    const pct_iih = (g.iih * 100).toFixed(1);
    const barW = Math.max(2, g.iih * 100).toFixed(1);
    driftHTML += `
      <div class="drift-cell">
        <div class="drift-gen">${g.gen}</div>
        <div class="drift-iih" style="color:${g.color};">${pct_iih}%</div>
        <div class="drift-bar" style="background:${g.color};width:${barW}%;"></div>
        ${g.isBC ? '<div style="font-size:7px;color:var(--accent2);margin-top:2px;">↳ BACKXROSS</div>' : ''}
      </div>`;
    if (i < driftGens.length - 1) {
      driftHTML += `<div class="drift-arrow">→</div>`;
    }
  });

  driftHTML += `</div>
    <p style="font-size:8px;color:var(--muted);margin-top:8px;">
      Modelo: IIH(g) = IIH₀ × factor_backcross(g) × exp(−λ·g)
      &nbsp;donde λ = r̄ × n_loci × 0.5 &nbsp;·&nbsp;
      r̄ = 0.091 (Haldane @ 10 cM) &nbsp;·&nbsp;
      BC1 aplica factor 0.50 (introgesión 50% genoma donante).
    </p>`;

  $('driftPanel').innerHTML = driftHTML;

  // ── Save state for external access ────────────────────────────────
  SK_STATE = { iih, meanBlockCM, meanRecomb, skLastResult, driftGens, alpha, N };
}
