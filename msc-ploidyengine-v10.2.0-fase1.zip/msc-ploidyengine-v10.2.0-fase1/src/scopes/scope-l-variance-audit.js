
// ─── [SCOPE L] renderVarianceAudit ───────────────────────────────────
// Renderiza el panel de descomposición de varianza en la pestaña Auditoría.
// Lee window._SL_VARIANCE_AUDIT que fue escrito por runMonteCarlo().
function renderVarianceAudit() {
  const el = $('varianceAuditPanel');
  if (!el) return;
  const va = window._SL_VARIANCE_AUDIT;
  if (!va) {
    el.innerHTML = `<div style="font-size:10px;color:var(--muted);text-align:center;padding:20px 0;">
      ⏳ Ejecuta la Simulación Principal para calcular la descomposición de varianza.
    </div>`;
    return;
  }

  const { V_P, V_A, V_D, V_I, V_E, V_G,
          Cov_AD, Cov_AI, Cov_DI, V_sum,
          delta_abs, delta_pct, h2_input, h2_narrow, h2_broad, N } = va;

  const statusCls  = delta_pct < 1 ? 'ok' : delta_pct < 5 ? 'warn' : 'fail';
  const statusTxt  = delta_pct < 1 ? '✓ NEUTRALIDAD VERIFICADA'
                   : delta_pct < 5 ? '⚠ DISCREPANCIA MODERADA'
                   : '✗ FALLA DE NEUTRALIDAD';

  // Proporciones sobre V_P
  const pA  = (V_A / V_P * 100).toFixed(1);
  const pD  = (V_D / V_P * 100).toFixed(1);
  const pI  = (V_I / V_P * 100).toFixed(1);
  const pE  = (V_E / V_P * 100).toFixed(1);
  const pCv = ((2*Cov_AD + 2*Cov_AI + 2*Cov_DI) / V_P * 100).toFixed(1);
  const pTot = (V_sum / V_P * 100).toFixed(2);

  const h2Delta = Math.abs(h2_narrow - h2_input);
  const h2Cls   = h2Delta < 0.05 ? 'ok' : h2Delta < 0.15 ? 'warn' : 'fail';
  const h2Txt   = h2Delta < 0.05 ? '✓ coherente con input'
                : h2Delta < 0.15 ? '⚠ diverge moderado'
                : '✗ diverge crítico';

  // Covarianza status
  const covThresh = 0.02;
  const covADok = Math.abs(Cov_AD / V_P) < covThresh;
  const covAIok = Math.abs(Cov_AI / V_P) < covThresh;
  const covDIok = Math.abs(Cov_DI / V_P) < covThresh;
  const ortogonal = covADok && covAIok && covDIok;

  el.innerHTML = `
    <div class="vaudit-panel">
      <div class="vaudit-head">
        🔬 SCOPE L — DESCOMPOSICIÓN DE VARIANZA · V_P = V_A + V_D + V_I + V_E
        <span class="vaudit-status ${statusCls}">${statusTxt}</span>
      </div>

      <div class="vaudit-equation">
        <strong>P = μ_base + A + D + I + E</strong>
        &nbsp;·&nbsp; V_P = V_A + V_D + V_I + V_E + 2Cov(A,D) + 2Cov(A,I) + 2Cov(D,I)
        &nbsp;·&nbsp; Σ = <strong style="color:${parseFloat(pTot)>99&&parseFloat(pTot)<101?'var(--ok)':'var(--danger)'}">${pTot}%</strong> de V_P
      </div>

      <div class="vaudit-grid">
        <div class="vaudit-card vp">
          <div class="vaudit-num vp">${V_P.toFixed(5)}</div>
          <div class="vaudit-lab">V_P OBSERVADA (σ²)</div>
        </div>
        <div class="vaudit-card va">
          <div class="vaudit-num va">${V_A.toFixed(5)}</div>
          <div class="vaudit-lab">V_A ADITIVA — ${pA}%</div>
        </div>
        <div class="vaudit-card vd">
          <div class="vaudit-num vd">${V_D.toFixed(5)}</div>
          <div class="vaudit-lab">V_D DOMINANCIA — ${pD}%</div>
        </div>
        <div class="vaudit-card vi">
          <div class="vaudit-num vi">${V_I.toFixed(5)}</div>
          <div class="vaudit-lab">V_I EPISTASIS — ${pI}%</div>
        </div>
        <div class="vaudit-card ve">
          <div class="vaudit-num ve">${V_E.toFixed(5)}</div>
          <div class="vaudit-lab">V_E AMBIENTAL — ${pE}%</div>
        </div>
        <div class="vaudit-card delta">
          <div class="vaudit-num ${statusCls}">${delta_pct.toFixed(3)}%</div>
          <div class="vaudit-lab">|ΔV_P| RELATIVO</div>
        </div>
      </div>

      <!-- Barras de proporción -->
      <div class="vaudit-bar-row">
        <div class="vaudit-bar-meta"><span>V_A (aditiva)</span><span style="color:var(--ok)">${pA}%</span></div>
        <div class="vaudit-bar-track"><div class="vaudit-bar-fill" style="width:${Math.min(parseFloat(pA),100)}%;background:var(--ok);"></div></div>
      </div>
      <div class="vaudit-bar-row">
        <div class="vaudit-bar-meta"><span>V_D (dominancia)</span><span style="color:var(--accent2)">${pD}%</span></div>
        <div class="vaudit-bar-track"><div class="vaudit-bar-fill" style="width:${Math.min(parseFloat(pD),100)}%;background:var(--accent2);"></div></div>
      </div>
      <div class="vaudit-bar-row">
        <div class="vaudit-bar-meta"><span>V_I (epistasis)</span><span style="color:var(--accent3)">${pI}%</span></div>
        <div class="vaudit-bar-track"><div class="vaudit-bar-fill" style="width:${Math.min(parseFloat(pI),100)}%;background:var(--accent3);"></div></div>
      </div>
      <div class="vaudit-bar-row">
        <div class="vaudit-bar-meta"><span>V_E (ambiental)</span><span style="color:var(--warn)">${pE}%</span></div>
        <div class="vaudit-bar-track"><div class="vaudit-bar-fill" style="width:${Math.min(parseFloat(pE),100)}%;background:var(--warn);"></div></div>
      </div>
      ${parseFloat(pCv) !== 0 ? `
      <div class="vaudit-bar-row">
        <div class="vaudit-bar-meta"><span>2×Cov cruzadas</span><span style="color:var(--muted)">${pCv}%</span></div>
        <div class="vaudit-bar-track"><div class="vaudit-bar-fill" style="width:${Math.min(Math.abs(parseFloat(pCv)),100)}%;background:var(--muted);opacity:.5;"></div></div>
      </div>` : ''}

      <!-- Heredabilidades -->
      <div class="vaudit-h2-compare">
        <div class="vaudit-h2-card">
          <div class="vaudit-h2-num" style="color:var(--muted)">${h2_input.toFixed(4)}</div>
          <div class="vaudit-h2-lab">h² INPUT (slider del usuario)</div>
        </div>
        <div class="vaudit-h2-card" style="border-color:var(--${h2Cls==='ok'?'ok':h2Cls==='warn'?'warn':'danger'});">
          <div class="vaudit-h2-num" style="color:var(--${h2Cls==='ok'?'ok':h2Cls==='warn'?'warn':'danger'})">${h2_narrow.toFixed(4)}</div>
          <div class="vaudit-h2-lab">h²_narrow EMPÍRICA (V_A/V_P)</div>
        </div>
      </div>
      <div style="text-align:center;font-size:9px;margin-top:6px;color:var(--${h2Cls==='ok'?'ok':h2Cls==='warn'?'warn':'danger'});">
        ${h2Txt} &nbsp;·&nbsp; Δh² = ${h2Delta.toFixed(4)}
        &nbsp;·&nbsp; h²_broad (V_G/V_P) = ${h2_broad.toFixed(4)}
      </div>

      <!-- Ortogonalidad -->
      <div class="vaudit-detail" style="margin-top:12px;">
        <div class="row">
          <span class="label">Cov(A,D) / V_P</span>
          <span class="value" style="color:var(--${covADok?'ok':'warn'})">${(Cov_AD/V_P*100).toFixed(3)}% &nbsp; ${covADok?'✓':'⚠'}</span>
        </div>
        <div class="row">
          <span class="label">Cov(A,I) / V_P</span>
          <span class="value" style="color:var(--${covAIok?'ok':'warn'})">${(Cov_AI/V_P*100).toFixed(3)}% &nbsp; ${covAIok?'✓':'⚠'}</span>
        </div>
        <div class="row">
          <span class="label">Cov(D,I) / V_P</span>
          <span class="value" style="color:var(--${covDIok?'ok':'warn'})">${(Cov_DI/V_P*100).toFixed(3)}% &nbsp; ${covDIok?'✓':'⚠'}</span>
        </div>
        <div class="row">
          <span class="label">Ortogonalidad global</span>
          <span class="value" style="color:var(--${ortogonal?'ok':'warn'})">${ortogonal?'✓ COMPONENTES ORTOGONALES':'⚠ COV NO NULAS — V_A/V_P no es h²_narrow exacta'}</span>
        </div>
        <div class="row">
          <span class="label">N iteraciones verificadas</span>
          <span class="value" style="color:var(--accent)">${N.toLocaleString('es-MX')}</span>
        </div>
        <div class="row">
          <span class="label">Σ(componentes) / V_P</span>
          <span class="value" style="color:var(--${parseFloat(pTot)>99&&parseFloat(pTot)<101?'ok':'danger'})">${pTot}% ${parseFloat(pTot)>99&&parseFloat(pTot)<101?'✓':'✗'}</span>
        </div>
      </div>

      ${!ortogonal ? `<div class="vaudit-bug-note">
        ⚠ <strong>Covarianzas no nulas detectadas</strong> — los componentes A, D, I no son ortogonales entre sí.
        Esto es esperado en poliploides con dominancia epistática (el efecto aditivo correlaciona con la dosis que también
        genera dominancia). Las estimaciones de h²_narrow por regresión padre-hijo son válidas,
        pero V_A/V_P ≠ h² del slider porque éste asume ortogonalidad de los componentes.
      </div>` : ''}

      <p style="font-size:9px;color:var(--muted);margin-top:10px;">
        Modelo corregido (Scope L): <code style="color:var(--accent2)">P = μ_base + A + D + I + E</code>
        donde A = dosis × efectoAdit (lineal), D = A × domCoef × normD (desviación), I = EpistasisMatrix o fallback,
        E ~ N(0, σ_E). Ver <code style="color:var(--accent3)">console.log</code> para tabla completa.
      </p>
    </div>`;
}
