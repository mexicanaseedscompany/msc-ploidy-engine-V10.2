
// ═══════════════════════════════════════════════════════════════════
//  EVIDENCE LAYER — UI v9.1
//  Interfaz gráfica para selección de nivel de evidencia.
//  PURAMENTE VISUAL — sin conexión al motor de simulación.
//  No modifica ningún cálculo, ninguna variable del motor,
//  ningún parámetro de runMonteCarlo().
//
//  Estado gestionado:
//    EL_ACTIVE_LEVEL  — nivel seleccionado actualmente (0..3)
//    EL_PENDING_LEVEL — nivel seleccionado pero no aplicado aún
//    EL_APPLIED       — true si el nivel fue aplicado (botón pulsado)
//
//  Arquitectura:
//    elSelectLevel(n)  — actualiza selección visual
//    elApply()         — marca como aplicado (stub: sin efecto en motor)
//    elToggle()        — colapsa/expande el panel
//    elRenderContent() — renderiza capacidades, flags y datos requeridos
// ═══════════════════════════════════════════════════════════════════

let EL_ACTIVE_LEVEL  = 3; // Nivel actualmente aplicado
let EL_PENDING_LEVEL = 3; // Nivel seleccionado en la UI (puede diferir)
let EL_APPLIED       = true;

// ── Datos de definición de cada nivel ────────────────────────────────
// Fuente de verdad para el render. No afecta al motor.

const EL_LEVELS = {
  0: {
    label:       'L0 — FENOTÍPICO',
    name:        'Fenotípico',
    cls:         'l0',
    modules:     3,
    totalModules:10,
    progressPct: '30%',
    footerNote:  '<strong>Nivel 0 seleccionado.</strong> Solo distribuciones observadas en campo. El motor usará un único locus ficticio sin ligamiento. Todos los parámetros moleculares serán inferidos con incertidumbre alta.',

    capabilities: [
      { on: true,  text: 'Monte Carlo básico (1 locus)',      badge: null },
      { on: true,  text: 'Distribución fenotípica (μ, σ, CV)',badge: null },
      { on: true,  text: 'Calibración pred. vs. observado',   badge: null },
      { on: false, text: 'Frecuencias gaméticas analíticas',  badge: null },
      { on: false, text: 'Ligamiento real (Haldane)',         badge: null },
      { on: false, text: 'Mapa QTL y cromosómico',            badge: null },
      { on: false, text: 'Epistasis inter-loci (Scope J)',    badge: null },
      { on: false, text: 'Variance Audit V_A/V_D/V_I/V_E',   badge: null },
      { on: false, text: 'Integridad haplotípica IIH (Scope K)', badge: null },
      { on: false, text: 'Deriva generacional BC→S',          badge: null },
    ],

    flags: [
      { name: 'use_linked_meiosis',          val: false,          type: 'false' },
      { name: 'recombination_engine_active', val: false,          type: 'false' },
      { name: 'loci_spacing_mode',           val: 'independent',  type: 'text'  },
      { name: 'epistasis_mode',              val: 'none',         type: 'text'  },
      { name: 'quantitative_model',          val: 'additive',     type: 'text'  },
      { name: 'scope_k_active',              val: false,          type: 'false' },
      { name: 'scope_l_active',              val: false,          type: 'false' },
      { name: 'sample_zygote_active',        val: false,          type: 'false' },
      { name: 'elite_score_formula',         val: 'wsdt_only',    type: 'text'  },
      { name: 'warn_on_inference',           val: true,           type: 'true'  },
    ],

    inputs: [
      { name: 'mu_observed',    status: 'req',  desc: 'Media fenotípica observada en campo (%)' },
      { name: 'sigma_observed', status: 'req',  desc: 'Desviación estándar de campo' },
      { name: 'n_observed',     status: 'opt',  desc: 'Tamaño de muestra de campo' },
      { name: 'h2_external',    status: 'opt',  desc: 'h² de literatura (si disponible)' },
      { name: 'g4, g2',         status: 'inf',  desc: 'Inferidos con defaults documentados' },
      { name: 'nLoci[]',        status: 'inf',  desc: 'Inferidos: 1 locus ficticio por carácter' },
      { name: 'alpha',          status: 'inf',  desc: 'Inferido: 0.05 por defecto' },
      { name: 'pos_cM',         status: 'inf',  desc: 'No aplica — sin mapa de ligamiento' },
    ]
  },

  1: {
    label:       'L1 — MARCADORES',
    name:        'Marcadores',
    cls:         'l1',
    modules:     5,
    totalModules:10,
    progressPct: '50%',
    footerNote:  '<strong>Nivel 1 seleccionado.</strong> Genotypescode reales de parentales disponibles. El motor usará frecuencias gaméticas analíticas y MC con loci cuasi-independientes (r ≈ 0.43). Sin mapa de ligamiento ni IIH.',

    capabilities: [
      { on: true,  text: 'Monte Carlo básico (1 locus)',       badge: null },
      { on: true,  text: 'Distribución fenotípica (μ, σ, CV)', badge: null },
      { on: true,  text: 'Calibración pred. vs. observado',    badge: null },
      { on: true,  text: 'Frecuencias gaméticas analíticas',   badge: null },
      { on: true,  text: 'MC con loci cuasi-independientes',   badge: null },
      { on: false, text: 'Ligamiento real (Haldane inter-QTL)',badge: null },
      { on: false, text: 'Mapa QTL y cromosómico',             badge: null },
      { on: false, text: 'Epistasis inter-loci (Scope J)',     badge: null },
      { on: false, text: 'Variance Audit V_A/V_D/V_I/V_E',    badge: null },
      { on: false, text: 'Integridad haplotípica IIH (Scope K)', badge: null },
    ],

    flags: [
      { name: 'use_linked_meiosis',          val: true,           type: 'true'  },
      { name: 'recombination_engine_active', val: false,          type: 'false' },
      { name: 'loci_spacing_mode',           val: 'independent',  type: 'text'  },
      { name: 'mc_spacing_cm',               val: 50,             type: 'text'  },
      { name: 'epistasis_mode',              val: 'fallback',     type: 'text'  },
      { name: 'quantitative_model',          val: 'additive_dom', type: 'text'  },
      { name: 'scope_k_active',              val: false,          type: 'false' },
      { name: 'scope_l_active',              val: false,          type: 'false' },
      { name: 'sample_zygote_active',        val: true,           type: 'true'  },
      { name: 'haplotype_level',             val: 1,              type: 'text'  },
    ],

    inputs: [
      { name: 'g4',           status: 'req',  desc: 'Genotypescode parental 4x [0..4]' },
      { name: 'g2',           status: 'req',  desc: 'Genotypescode parental 2x [0..2]' },
      { name: 'nLoci[]',      status: 'req',  desc: 'Número de loci por carácter' },
      { name: 'alpha',        status: 'opt',  desc: 'Coef. reducción doble (default 0.05)' },
      { name: 'traitWeights', status: 'opt',  desc: 'Pesos por carácter (default 50/30/20)' },
      { name: 'mu_observed',  status: 'opt',  desc: 'Para calibración vs. observado' },
      { name: 'pos_cM',       status: 'inf',  desc: 'No aplica — spacing=50 cM (cuasi-libre)' },
      { name: 'ancestorId',   status: 'inf',  desc: 'Sintético — sin pedigree real' },
    ]
  },

  2: {
    label:       'L2 — QTL MAPEADOS',
    name:        'QTL Mapeados',
    cls:         'l2',
    modules:     7,
    totalModules:10,
    progressPct: '70%',
    footerNote:  '<strong>Nivel 2 seleccionado.</strong> QTLs con posición cM y efecto cuantificado. Ligamiento Haldane real entre loci. Scope J (epistasis) y Scope L (variance audit) activos. Scope K desactivado por falta de densidad haplotípica.',

    capabilities: [
      { on: true,  text: 'Monte Carlo con ligamiento Haldane', badge: null },
      { on: true,  text: 'Distribución fenotípica completa',   badge: null },
      { on: true,  text: 'Frecuencias gaméticas analíticas',   badge: null },
      { on: true,  text: 'Mapa QTL y tabla de recombinación',  badge: null },
      { on: true,  text: 'Epistasis inter-QTL (Scope J)',      badge: { cls: 'new', txt: 'J' } },
      { on: true,  text: 'Variance Audit V_A/V_D/V_I/V_E',    badge: { cls: 'new', txt: 'L' } },
      { on: true,  text: 'Haplotipo muestral Nivel 3',         badge: null },
      { on: false, text: 'IIH poblacional (Scope K)',          badge: { cls: 'warn', txt: 'SIN DENSIDAD' } },
      { on: false, text: 'Mapa de bloques cromosómicos',       badge: null },
      { on: false, text: 'Deriva generacional BC→S',           badge: null },
    ],

    flags: [
      { name: 'use_linked_meiosis',          val: true,     type: 'true'  },
      { name: 'recombination_engine_active', val: true,     type: 'true'  },
      { name: 'loci_spacing_mode',           val: 'real',   type: 'text'  },
      { name: 'epistasis_mode',              val: 'matrix', type: 'text'  },
      { name: 'epistasis_matrix_in_mc',      val: false,    type: 'false' },
      { name: 'quantitative_model',          val: 'full',   type: 'text'  },
      { name: 'scope_k_active',              val: false,    type: 'false' },
      { name: 'scope_l_active',              val: true,     type: 'true'  },
      { name: 'scope_l_covariances',         val: true,     type: 'true'  },
      { name: 'elite_score_formula',         val: 'wsdt_only', type: 'text' },
    ],

    inputs: [
      { name: 'chromosomes[]',     status: 'req',  desc: 'Mapa de cromosomas con loci y longitud cM' },
      { name: 'loci[].pos_cM',     status: 'req',  desc: 'Posición en cM de cada QTL' },
      { name: 'loci[].effect',     status: 'req',  desc: 'Efecto aditivo por locus' },
      { name: 'loci[].dominance',  status: 'req',  desc: 'Coef. de dominancia por locus' },
      { name: 'epistasis_pairs[]', status: 'opt',  desc: 'Pares (locusA, locusB, Iij) si disponibles' },
      { name: 'g4 por locus',      status: 'opt',  desc: 'ParentalHaplotype diferenciado (o uniforme)' },
      { name: 'dense_markers',     status: 'inf',  desc: 'No aplica — IIH desactivado en este nivel' },
      { name: 'ancestorId',        status: 'inf',  desc: 'Sintético desde strand tracking' },
    ]
  },

  3: {
    label:       'L3 — GENÓMICO COMPLETO',
    name:        'Genómico Completo',
    cls:         'l3',
    modules:     10,
    totalModules:10,
    progressPct: '100%',
    footerNote:  '<strong>Nivel 3 activo.</strong> Todos los módulos habilitados. El motor correrá con strand tracking real, IIH poblacional (Scope K), descomposición de varianza (Scope L) y epistasis inter-loci (Scope J).',

    capabilities: [
      { on: true,  text: 'MC con ligamiento Haldane + strand tracking', badge: null },
      { on: true,  text: 'Distribución fenotípica + h²_narrow',         badge: null },
      { on: true,  text: 'Frecuencias gaméticas analíticas',            badge: null },
      { on: true,  text: 'Mapa QTL y tabla de recombinación',           badge: null },
      { on: true,  text: 'Epistasis inter-QTL (Scope J)',               badge: { cls: 'new', txt: 'J' } },
      { on: true,  text: 'Variance Audit V_A/V_D/V_I/V_E (Scope L)',   badge: { cls: 'new', txt: 'L' } },
      { on: true,  text: 'IIH poblacional y per-cromosoma (Scope K)',   badge: { cls: 'new', txt: 'K' } },
      { on: true,  text: 'Mapa de bloques haplotípicos cM',             badge: null },
      { on: true,  text: 'Deriva generacional IIH (P→BC1→S2)',          badge: null },
      { on: true,  text: 'Haplotipo muestral Nivel 3 + pedigree',       badge: null },
    ],

    flags: [
      { name: 'use_linked_meiosis',          val: true,          type: 'true'  },
      { name: 'recombination_engine_active', val: true,          type: 'true'  },
      { name: 'loci_spacing_mode',           val: 'real',        type: 'text'  },
      { name: 'epistasis_mode',              val: 'matrix',      type: 'text'  },
      { name: 'scope_k_active',              val: true,          type: 'true'  },
      { name: 'iih_mc_accumulate',           val: true,          type: 'true'  },
      { name: 'generational_drift_active',   val: true,          type: 'true'  },
      { name: 'scope_l_active',              val: true,          type: 'true'  },
      { name: 'scope_l_covariances',         val: true,          type: 'true'  },
      { name: 'elite_score_formula',         val: 'wsdt_haplo',  type: 'text'  },
    ],

    inputs: [
      { name: 'chromosomes[]',         status: 'req',  desc: 'Mapa genómico con todos los loci' },
      { name: 'loci[].pos_cM + effect',status: 'req',  desc: 'Posición y efecto de cada QTL' },
      { name: 'dense_markers',         status: 'req',  desc: 'Panel de marcadores inter-QTL para bloques cM' },
      { name: 'epistasis_pairs[]',     status: 'opt',  desc: 'Pares epistáticos (Iij, tipo)' },
      { name: 'flow_cytometry_ploidy', status: 'opt',  desc: 'Validación de ploidía por citometría' },
      { name: 'haplotype_resolved',    status: 'opt',  desc: 'ancestorId reales por cromátida (si disponibles)' },
      { name: 'g4 por locus',          status: 'opt',  desc: 'Haplotipo parental diferenciado por locus' },
      { name: 'mu_observed',           status: 'opt',  desc: 'Para calibración vs. observado' },
    ]
  }
};

// ── Funciones de la Evidence Layer UI ────────────────────────────────

// Seleccionar un nivel — solo actualiza la UI, no toca el motor
function elSelectLevel(n) {
  if (n === EL_PENDING_LEVEL) return; // ya está seleccionado

  EL_PENDING_LEVEL = n;
  EL_APPLIED = (n === EL_ACTIVE_LEVEL);

  // Actualizar cards
  [0,1,2,3].forEach(i => {
    const card = $(`elCard${i}`);
    card.classList.remove('active', 'l0', 'l1', 'l2', 'l3');
    card.classList.add(`l${i}`);
    if (i === n) card.classList.add('active');
  });

  // Actualizar pill en header
  const pill = $('elActivePill');
  pill.className = `el-active-pill l${n}`;
  pill.textContent = EL_APPLIED
    ? `◉ ${EL_LEVELS[n].label}`
    : `◎ ${EL_LEVELS[n].label} — PENDIENTE`;

  // Actualizar barra de progreso
  const pct = EL_LEVELS[n].progressPct;
  const fill = $('elProgressFill');
  fill.style.width = pct;
  fill.className = `el-progress-fill l${n}`;

  const pctLabel = $('elProgressPct');
  pctLabel.textContent = `${EL_LEVELS[n].modules} / ${EL_LEVELS[n].totalModules}`;
  pctLabel.className = `el-progress-pct l${n}`;

  // Actualizar capabilities, flags e inputs
  elRenderContent(n);

  // Botón aplicar
  const btn = $('elApplyBtn');
  if (EL_APPLIED) {
    btn.textContent = '✓ CONFIGURACIÓN APLICADA';
    btn.disabled = true;
  } else {
    btn.textContent = `▶ APLICAR NIVEL ${n}`;
    btn.disabled = false;
  }
}

// Renderizar el contenido dinámico del panel según nivel
function elRenderContent(n) {
  const def = EL_LEVELS[n];
  const cls = def.cls;

  // ── Capabilities ──
  const capEl = $('elCapabilities');
  capEl.className = `el-capabilities ${cls}`;

  $('elCapBadge').className = `el-cap-head-badge ${cls}`;
  $('elCapBadge').textContent = def.label;

  $('elCapGrid').innerHTML = def.capabilities.map(c => {
    const iconCls = c.on ? `on-${cls}` : 'off';
    const iconChar = c.on ? '✓' : '—';
    const textCls = c.on ? '' : 'off';
    const badgeHTML = c.badge
      ? `<span class="el-cap-badge ${c.badge.cls}">${c.badge.txt}</span>`
      : '';
    return `<div class="el-cap-item">
      <span class="el-cap-icon ${iconCls}">${iconChar}</span>
      <span class="el-cap-text ${textCls}">${c.text}</span>
      ${badgeHTML}
    </div>`;
  }).join('');

  // ── Flags ──
  $('elFlagsGrid').innerHTML = def.flags.map(f => {
    const valCls = f.type === 'true' ? 'true' : f.type === 'false' ? 'false' : 'text';
    const valTxt = typeof f.val === 'boolean' ? (f.val ? 'true' : 'false') : String(f.val);
    return `<div class="el-flag-row">
      <span class="el-flag-name">${f.name}</span>
      <span class="el-flag-val ${valCls}">${valTxt}</span>
    </div>`;
  }).join('');

  // ── Inputs requeridos ──
  const statusLabel = { req: 'REQUERIDO', opt: 'OPCIONAL', inf: 'INFERIDO' };
  $('elInputsGrid').innerHTML = def.inputs.map(inp => `
    <div class="el-input-row">
      <span class="el-input-status ${inp.status}">${statusLabel[inp.status]}</span>
      <span class="el-input-name">${inp.name}</span>
      <span class="el-input-desc">${inp.desc}</span>
    </div>`
  ).join('');

  // ── Footer note ──
  $('elFooterNote').innerHTML = def.footerNote;
}

// Colapsar / expandir panel
function elToggle() {
  const wrapper = $('elWrapper');
  const isExpanded = wrapper.classList.contains('expanded');
  wrapper.classList.toggle('expanded', !isExpanded);
  wrapper.querySelector('.el-header').setAttribute('aria-expanded', String(!isExpanded));
}

// ── elApplyControlVisibility(level) — Auditoría EL v9.2.0 ────────────
// Aplica el estado A/B/C/D de cada control según el nivel de evidencia activo.
// A = editable (sin cambios), B = visible+bloqueado, C = oculto, D = calculado
function elApplyControlVisibility(level) {
  // ── Helpers ──
  function lockRow(id, badge) {
    const el = $(id); if (!el) return;
    el.classList.add('el-locked');
    const b = badge ? $(badge) : null;
    if (b) b.style.display = 'inline';
  }
  function unlockRow(id, badge) {
    const el = $(id); if (!el) return;
    el.classList.remove('el-locked');
    const b = badge ? $(badge) : null;
    if (b) b.style.display = 'none';
  }
  function hideRow(id) { const el = $(id); if (el) el.classList.add('el-hidden'); }
  function showRow(id) { const el = $(id); if (el) el.classList.remove('el-hidden'); }

  // ── 1. Factor α (alphaSlider) ──
  // B en L0/L1 (bloqueado α=0.05), A en L2+
  if (level < 2) {
    lockRow('row-alpha', 'badge-alpha');
    // Fijar valor a 500 (=0.05) silenciosamente
    const sl = $('alphaSlider');
    if (sl) { sl.value = 500; updateAlpha(); }
  } else {
    unlockRow('row-alpha', 'badge-alpha');
  }

  // ── 2. Modo apareamiento biv/quad ──
  // C en L0/L1 (oculto), B visible+bloqueado en L2, A en L3
  if (level < 2) {
    hideRow('row-pairing');
  } else if (level === 2) {
    showRow('row-pairing');
    lockRow('row-pairing', null);
  } else {
    showRow('row-pairing');
    unlockRow('row-pairing', null);
  }

  // ── 3. nLoci (c1, c2, c3) ──
  // D en L0 (calculado, oculto), B en L1 (visible, bloqueado), A en L2+
  const nlociNote = $('nloci-l0-note');
  if (level < 1) {
    hideRow('row-nloci');
    if (nlociNote) nlociNote.style.display = 'block';
  } else if (level === 1) {
    showRow('row-nloci');
    lockRow('row-nloci', null);
    if (nlociNote) nlociNote.style.display = 'none';
  } else {
    showRow('row-nloci');
    unlockRow('row-nloci', null);
    if (nlociNote) nlociNote.style.display = 'none';
  }

  // ── 4. Efecto aditivo (efectoAdit) ──
  // D en L0 (calculado, bloqueado), B en L1 (visible, bloqueado), A en L2+
  if (level < 1) {
    lockRow('row-efectoAdit', 'badge-efectoAdit');
    // Derivar A desde μBase y h²: A ≈ (muBase × h²) / (defaultDosis)
    const muB = parseFloat($('muBase').value) || 12;
    const h2  = (parseInt($('h2Slider').value) || 75) / 100;
    const aEst = parseFloat(((muB * h2) / (3 * 2.5)).toFixed(2));
    const sl = $('efectoAdit');
    if (sl) { sl.value = Math.min(Math.max(aEst, 0.2), 5); updateAdit(); }
  } else if (level === 1) {
    lockRow('row-efectoAdit', 'badge-efectoAdit');
    const badge = $('badge-efectoAdit');
    if (badge) badge.textContent = '🔒 Editable desde L2';
  } else {
    unlockRow('row-efectoAdit', 'badge-efectoAdit');
  }

  // ── 5. Dominancia (dominance) ──
  // D en L0/L1 (fijo 0.50), A en L2+
  if (level < 2) {
    lockRow('row-dominance', 'badge-dominance');
    const sl = $('dominance'); if (sl) { sl.value = 50; updateDominance(); }
  } else {
    unlockRow('row-dominance', 'badge-dominance');
  }

  // ── 6. Epistasis global I (slider) ──
  // C en L0/L1 (oculto), B en L2 (visible, bloqueado), A en L3
  if (level < 2) {
    hideRow('row-epistasis');
  } else if (level === 2) {
    showRow('row-epistasis');
    lockRow('row-epistasis', null);
  } else {
    showRow('row-epistasis');
    unlockRow('row-epistasis', null);
  }

  // ── 7. Scope J epiMatrixPanel ──
  // C en L0/L1, B (visible, no editable) en L2, A en L3
  const epiPanel = $('epiMatrixPanel');
  const epiEdit  = $('row-epiEdit');
  const epiL2note = $('epi-l2-note');
  if (level < 2) {
    if (epiPanel) epiPanel.classList.add('el-hidden');
  } else if (level === 2) {
    if (epiPanel) epiPanel.classList.remove('el-hidden');
    if (epiEdit)  epiEdit.classList.add('el-hidden');
    if (epiL2note) epiL2note.style.display = 'block';
  } else {
    if (epiPanel) epiPanel.classList.remove('el-hidden');
    if (epiEdit)  epiEdit.classList.remove('el-hidden');
    if (epiL2note) epiL2note.style.display = 'none';
  }
}

// Aplicar nivel — actualiza UI y relanza el motor con el nuevo EL_ACTIVE_LEVEL
function elApply() {
  if (EL_PENDING_LEVEL === EL_ACTIVE_LEVEL) return;

  EL_ACTIVE_LEVEL = EL_PENDING_LEVEL;
  EL_APPLIED = true;

  // Actualizar pill
  const pill = $('elActivePill');
  pill.className = `el-active-pill l${EL_ACTIVE_LEVEL}`;
  pill.textContent = `◉ ${EL_LEVELS[EL_ACTIVE_LEVEL].label}`;

  // Deshabilitar botón
  const btn = $('elApplyBtn');
  btn.textContent = '✓ CONFIGURACIÓN APLICADA';
  btn.disabled = true;

  // Nota de confirmación
  const note = $('elFooterNote');
  const existing = note.innerHTML;
  note.innerHTML = `<span style="color:var(--ok)">✓ Nivel ${EL_ACTIVE_LEVEL} aplicado.</span> ${existing}`;
  setTimeout(() => { note.innerHTML = EL_LEVELS[EL_ACTIVE_LEVEL].footerNote; }, 2200);

  // [Paso 6] Motor conectado: relanzar simulación con el nuevo nivel activo.
  // runMonteCarlo() lee EL_ACTIVE_LEVEL en su arranque → las flags useQTL,
  // useEpistasis, useIIH se recalculan automáticamente con el nuevo nivel.
  console.log(`[EvidenceLayer] Nivel ${EL_ACTIVE_LEVEL} aplicado → relanzando motor.`);
  elApplyControlVisibility(EL_ACTIVE_LEVEL); // [v9.2.0] Audit: ajustar visibilidad
  runMonteCarlo();
}

// ── Init Evidence Layer ───────────────────────────────────────────────
function elInit() {
  elRenderContent(EL_ACTIVE_LEVEL);
  // Asegurar estado visual correcto en arranque
  $(`elCard${EL_ACTIVE_LEVEL}`).classList.add('active');
  $('elApplyBtn').disabled = true;
  $('elApplyBtn').textContent = '✓ CONFIGURACIÓN APLICADA';
  elApplyControlVisibility(EL_ACTIVE_LEVEL); // [v9.2.0] Audit: visibilidad inicial
}
$('runBtn').addEventListener('click', runMonteCarlo);

updateAlpha(); updateN(); updateMuBase(); updateAdit(); updateH2(); updateSigma();
updateDominance(); updateEpistasis(); updatePairing();
['c1','c2','c3'].forEach(id => updateChar(id, id+'v'));

// [SJ-5] Inicializar panel de la Matriz Epistática con par de ejemplo
EPISTASIS_MATRIX.set('THCAS_1', 'TERP_MYR', 0.45, 'syn');
EPISTASIS_MATRIX.set('CBDAS_1', 'QTL_Morfol', -0.30, 'ant');
renderEpistasisMatrix();

elInit(); // [EvidenceLayer v9.1] Panel de selección de nivel de evidencia

runMonteCarlo();
runValidation();
loadLibrary(); // [Scope G] Restaurar memoria persistente al arrancar
