# Changelog

## 10.2.0
- Meiosis 4x: asignación aleatoria alelo↔cromátida por meiosis y doble reducción como cromátidas hermanas
  (las dosis simuladas ahora coinciden con la tabla analítica; antes AAaa producía solo gametos Aa).
- Selector de dosis mínima acotado a 1..maxDoseLocus.
- Código fuente modularizado (`src/`), compilador (`build.js`) y pruebas (`tests/`).

## 10.1.0 (Scope M — PloidyGen)
- Cruces generalizados 2x/4x × 2x/4x: `GAMETE_COPIES`, `renderAlleleState`, `gameteDist`, `zygoteDist`.
- `buildLocusGenotype` con copias explícitas por parental (4x×2x y 2x×4x comparten maxDoseLocus=3).
- Dominancia `dose/maxDoseLocus` (sin `switch`), `EpistasisMatrix.computeI(…, maxDoseLocus)`,
  IIH ponderado por copias gaméticas, selectores de ploidía en la UI, `renderAnalytics` genérico.
- `simulateMeiosis(..., role)`: origen y `ancestorId` por rol dam/sire.
