#!/usr/bin/env node
// Compila src/ → dist/MSC_PloidyEngine_v<versión>.html (archivo único, autónomo).
const fs = require('fs'), path = require('path');
const pkg = require('./package.json');
const src = p => fs.readFileSync(path.join(__dirname, 'src', p), 'utf8');
const { files } = JSON.parse(src('manifest.json'));
const js = files.map(f => fs.readFileSync(path.join(__dirname, f), 'utf8')).join('');
const html = src('index.template.html').replace('/*@@SCRIPT@@*/', () => js);
const out = path.join(__dirname, 'dist', `MSC_PloidyEngine_v${pkg.version.replace(/\./g, '-')}-PloidyGen.html`);
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html, 'utf8');
console.log(`OK  ${path.relative(__dirname, out)}  (${(html.length / 1024).toFixed(0)} KB, ${files.length} módulos)`);
