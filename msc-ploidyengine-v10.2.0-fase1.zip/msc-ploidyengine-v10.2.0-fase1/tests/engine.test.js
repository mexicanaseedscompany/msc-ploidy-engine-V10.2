// Pruebas del motor (Node ≥ 18, sin dependencias). Uso: npm test
const E = require('./load-engine')();
let pass = 0, fail = 0;
const ok = (c, msg) => { c ? pass++ : (fail++, console.log('  ✗ FALLA:', msg)); };
const near = (a, b, tol, msg) => ok(Math.abs(a - b) <= tol, `${msg} (obtenido ${a.toFixed(4)}, esperado ${b.toFixed(4)} ±${tol})`);
const sec = t => console.log('\n' + t);

const chr = { id: 'C1', length_cM: 100, loci: [
  { name: 'a', pos_cM: 10, effect: 1, dominance: .5, epistasis: 0, trait: 't' },
  { name: 'b', pos_cM: 40, effect: 1, dominance: .5, epistasis: 0, trait: 't' },
  { name: 'c', pos_cM: 70, effect: 1, dominance: .5, epistasis: 0, trait: 't' }] };

sec('1. Utilidades de dosis');
ok(E.MeiosisEngine.renderAlleleState(1, 3) === 'Aaa', "renderAlleleState(1,3)='Aaa'");
ok(E.MeiosisEngine.renderAlleleState(2, 4) === 'AAaa', "renderAlleleState(2,4)='AAaa'");
ok(E.GAMETE_COPIES[4] === 2 && E.GAMETE_COPIES[2] === 1, 'GAMETE_COPIES');
const bl = E.MeiosisEngine.buildLocusGenotype(2, 1, 'dam_4x_C1_hA0hB1', 'sire_2x_C1_h0', 3, 2, 1);
ok(bl.alleleState === 'AAA' && bl.homologs.length === 3, 'buildLocusGenotype 4x×2x → AAA, 3 homólogos');
const b2 = E.MeiosisEngine.buildLocusGenotype(1, 2, 'dam_2x_C1_h0', 'sire_4x_C1_hA0hB1', 3, 1, 2);
ok(b2.homologs.filter(h => h.origin === 'dam').length === 1 && b2.homologs.filter(h => h.origin === 'sire').length === 2, '2x×4x → 1 homólogo dam + 2 sire');

sec('2. Meiosis 4x vs. tabla de Mather (primer locus, 100 000 gametos)');
const NS = 100000;
for (const alpha of [0, 0.05, 1 / 6]) for (const g of [0, 1, 2, 3, 4]) {
  E.setSeed(500 + g); const eng = new E.GenomicPolyploidEngine(alpha); const h = E.ParentalHaplotype.fromUniform(g);
  const c = [0, 0, 0];
  for (let i = 0; i < NS; i++) c[eng.simulateMeiosis(chr, 4, h, alpha, 'dam')[0].dose]++;
  const p = E.MeiosisEngine.tetraploidGameteProbs(g, alpha), tag = `g=${g} α=${alpha.toFixed(3)}`;
  if (g === 1) { // el modelo de cromátidas hermanas produce AA = α/4 (la tabla lo suma en aa)
    near(c[2] / NS, alpha / 4, .006, `${tag} AA≈α/4`); near(c[1] / NS, p.Aa, .006, `${tag} Aa`);
  } else if (g === 3) {
    near(c[0] / NS, alpha / 4, .006, `${tag} aa≈α/4`); near(c[1] / NS, p.Aa, .006, `${tag} Aa`);
  } else { near(c[0] / NS, p.aa, .006, `${tag} aa`); near(c[1] / NS, p.Aa, .006, `${tag} Aa`); near(c[2] / NS, p.AA, .006, `${tag} AA`); }
}

sec('3. Meiosis 2x');
for (const g of [0, 1, 2]) {
  E.setSeed(9); const eng = new E.GenomicPolyploidEngine(0); let s = 0;
  for (let i = 0; i < 20000; i++) s += eng.simulateMeiosis(chr, 2, E.ParentalHaplotype.fromUniform(g), 0, 'sire')[0].dose;
  near(s / 20000, g / 2, .01, `2x g=${g} P(A)`);
}

sec('4. Cruces generalizados (consistencia + distribución de dosis)');
for (const [pA, pB, gA, gB] of [[4, 2, 2, 1], [2, 2, 1, 1], [4, 4, 2, 2], [2, 4, 1, 2], [4, 4, 3, 1]]) {
  const maxD = E.GAMETE_COPIES[pA] + E.GAMETE_COPIES[pB], alpha = 0.05, tag = `${pA}x×${pB}x`;
  E.setSeed(42); E.HaplotypicBlockEngine.setCrossContext(pA, pB);
  const eng = new E.GenomicPolyploidEngine(alpha);
  eng.buildGenome([{ id: 'C1', length_cM: 100, loci: chr.loci }]);
  const epi = new E.EpistasisMatrix(), hist = new Array(maxD + 1).fill(0); let bad = 0, n = 0;
  for (let i = 0; i < 3000; i++) {
    const z = eng.generateTriploidZygote(gA, gB, {}, epi, maxD, pA, pB);
    for (const l of z.chrResults[0].loci) { hist[l.dose]++; n++;
      if (l.dose < 0 || l.dose > maxD || l.alleleState.length !== maxD || l.homologs.length !== maxD ||
          l.homologs.filter(h => h.allele === 'A').length !== l.dose) bad++; }
    const iih = E.HaplotypicBlockEngine.computeIIH_global(z.chrResultsK).IIH_global;
    if (!(iih >= 0 && iih <= 1)) bad++;
  }
  ok(bad === 0, `${tag}: ${bad} inconsistencias estructurales`);
  const theo = E.MeiosisEngine.zygoteDist(E.MeiosisEngine.gameteDist(pA, gA, alpha), E.MeiosisEngine.gameteDist(pB, gB, alpha), maxD);
  hist.forEach((h, d) => near(h / n, theo[d], .02, `${tag} P(dosis=${d})`));
}

sec('5. Determinismo (misma semilla → mismo resultado)');
const run = () => { E.setSeed(2024); const eng = new E.GenomicPolyploidEngine(.05);
  return JSON.stringify(eng.simulateMeiosis(chr, 4, E.ParentalHaplotype.fromUniform(2), .05, 'dam')); };
ok(run() === run(), 'simulateMeiosis reproducible');

sec('6. Epistasis y normalización');
const epi = new E.EpistasisMatrix(); epi.set('a', 'b', 0.5, 'syn');
const r3 = epi.computeI([{ name: 'a', dose: 3, effect: 1 }, { name: 'b', dose: 3, effect: 1 }], 3);
const r4 = epi.computeI([{ name: 'a', dose: 4, effect: 1 }, { name: 'b', dose: 4, effect: 1 }], 4);
near(r3.totalI, r4.totalI, 1e-12, 'computeI: dosis máxima ⇒ misma fracción para 3x y 4x');

console.log(`\n${fail ? '✗' : '✓'} ${pass} correctas, ${fail} fallidas`);
process.exit(fail ? 1 : 0);
