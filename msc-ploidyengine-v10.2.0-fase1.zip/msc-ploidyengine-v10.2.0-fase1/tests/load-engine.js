// Carga los módulos src/engine/*.js en un contexto aislado (sin DOM) y expone sus símbolos.
const fs = require('fs'), path = require('path'), vm = require('vm');
module.exports = function loadEngine() {
  const root = path.join(__dirname, '..', 'src');
  const { files } = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
  const code = files.filter(f => f.startsWith('src/engine/'))
    .map(f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8')).join('') + `
;({ RNG, GAMETE_COPIES, RecombinationEngine, EpistasisMatrix, HaplotypicBlockEngine, MeiosisEngine,
    ProbabilityValidator, ParentalHaplotype, GenomicPolyploidEngine,
    setSeed: s => { _RNG = new RNG(s); } })`;
  return vm.runInNewContext(code, { console, Math, Date });
};
