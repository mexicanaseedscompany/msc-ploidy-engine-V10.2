// Pruebas de CARACTERIZACIÓN: documentan el comportamiento ACTUAL de persistencia, simRecord y registerObserved().
// No prescriben lo deseable: fijan lo que hoy ocurre (incluido el defecto conocido nº 5, marcado KNOWN-BUG).
// Cualquier cambio futuro en este comportamiento debe ser deliberado y aprobado.
const H = require('./harness');
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : (fail++, console.log('  ✗', m)); };
const eq = (a, b, m) => ok(JSON.stringify(a) === JSON.stringify(b), `${m}: obtenido ${JSON.stringify(a)} ≠ esperado ${JSON.stringify(b)}`);
const sec = t => console.log('\n' + t);
const lsAll = w => { const o = {}; for (let i = 0; i < w.localStorage.length; i++) { const k = w.localStorage.key(i); o[k] = w.localStorage.getItem(k); } return o; };
const setObs = (P, v) => { P.set('obsInput', v); P.w.registerObserved(); };

(async () => {
  for (const mode of ['default', 'off', 'on']) {
    const probe = await H.openPage({ mode: 'default' });
    const hasNS = typeof probe.w.MSCBreeding !== 'undefined'; probe.dom.window.close();
    if (mode !== 'default' && !hasNS) continue;
    sec(`Caracterización — modo capa MSCBreeding: ${mode}`);

    // C1: forma de simRecord tras la simulación de arranque
    let P = await H.openPage({ mode, randomBase: 500000000 });
    ok(P.errs.filter(e => !/localStorage/.test(e)).length === 0, 'sin errores de página en el arranque');
    eq(P.ev('SIM_COUNT'), 1, 'arranque: SIM_COUNT=1 (la página ejecuta una simulación al cargar)');
    const rec = P.json('simLibrary[0]');
    eq(Object.keys(rec), ['id','date','version','seed','cross','alpha','pairing','loci','minDose','N','traitWeights','epistasisMatrix','prediction','observed','error','modelAccuracy'], 'claves de simRecord (orden incluido)');
    eq(Object.keys(rec.prediction), ['mu','sigma','cv','eliteP','pTheo','sdtAbove','wsdtMean','sdtMeanTrait','top1n','top5n','top10n','bestScore','bestPheno'], 'claves de simRecord.prediction');
    ok(typeof rec.id === 'number' && typeof rec.seed === 'number' && typeof rec.N === 'number' && typeof rec.minDose === 'number', 'id/seed/N/minDose son números');
    ok(typeof rec.alpha === 'string' && typeof rec.prediction.mu === 'string' && typeof rec.prediction.sigma === 'string', 'alpha y prediction.mu/sigma se guardan como STRING (toFixed)');
    ok(Array.isArray(rec.traitWeights) && rec.traitWeights.every(x => typeof x === 'string'), 'traitWeights: strings');
    ok(rec.observed === null && rec.error === null && rec.modelAccuracy === null, 'observed/error/modelAccuracy = null antes de calibrar');
    ok(/^\d+x\(g\d\) × \d+x\(g\d\)$/.test(rec.cross), `cross es un string parseable: "${rec.cross}"`);
    for (const missing of ['muBase','efectoAdit','h2','heredab','sigmaE','domCoef','epiCoef','ploidyA','ploidyB','environment','evidenceLevel','genome'])
      ok(!(missing in rec), `simRecord NO contiene "${missing}" (dato no registrado hoy)`);
    eq(rec.version, '10.2.0-PloidyGen', 'version de simRecord');

    // C2: persistencia tras la simulación
    let ls = lsAll(P.w);
    eq(Object.keys(ls).sort(), ['msc_ploidy_count_v5', 'msc_ploidy_library_v5'], 'claves de localStorage escritas');
    eq(ls['msc_ploidy_count_v5'], '1', 'count persistido');
    eq(JSON.parse(ls['msc_ploidy_library_v5']), P.json('simLibrary'), 'library persistida == simLibrary');
    ok(!Object.keys(ls).some(k => /breeding/i.test(k)), 'la capa MSCBreeding NO escribe en localStorage');
    const saved = { ...ls };

    // C3: recarga — loadLibrary() al arrancar
    const P2 = await H.openPage({ mode, storage: saved, randomBase: 600000000 });
    const ids = P2.json('simLibrary.map(s=>s.id)');
    eq(ids, [1, 2], 'tras recarga: registro restaurado (id 1) + simulación de arranque (id 2)');
    eq(P2.ev('SIM_COUNT'), 2, 'tras recarga: SIM_COUNT=2');
    eq(P2.json('simLibrary[0].seed'), rec.seed, 'el registro restaurado conserva su seed');
    P2.dom.window.close();

    // C4: registerObserved()
    P.alerts.length = 0; setObs(P, '');
    eq(P.alerts.length, 1, 'obsInput vacío → alert');
    eq(P.json('simLibrary[0].observed'), null, 'obsInput vacío → sin cambios');
    const mu = P.ev('SIM_STATE.mu');
    setObs(P, '25.5');
    let r = P.json('simLibrary[0]');
    const err = 25.5 - mu, acc = 100 - Math.abs(err / mu * 100);
    eq(r.observed, (25.5).toFixed(3), 'observed = obs.toFixed(3)');
    eq(r.error, err.toFixed(3), 'error = (obs − μ).toFixed(3)');
    eq(r.modelAccuracy, acc.toFixed(2), 'modelAccuracy = (100 − |error%|).toFixed(2)');
    ok(P.d.getElementById('accuracyDisplay').textContent.includes('EXACTITUD MODELO'), 'accuracyDisplay renderiza tarjetas');
    eq(JSON.parse(lsAll(P.w)['msc_ploidy_library_v5'])[0].observed, '25.500', 'la calibración se persiste en localStorage');
    setObs(P, '30');   // segunda calibración: sobrescribe sin historial
    eq(P.json('simLibrary[0].observed'), '30.000', 'segunda calibración SOBRESCRIBE la primera (sin historial)');
    setObs(P, '5000'); // error enorme → exactitud negativa
    ok(parseFloat(P.json('simLibrary[0].modelAccuracy')) < 0, 'exactitud puede ser NEGATIVA con errores grandes (100−|error%|)');
    eq(P.json('Object.keys(simLibrary[0]).length'), 16, 'registerObserved no añade claves a simRecord (sin n, trait, unidad, ambiente)');

    // C5: papelera y restauración
    P.alerts.length = 0; const before = P.json('simLibrary');
    P.w.clearLibrary();
    eq(P.json('simLibrary.length'), 0, 'clearLibrary vacía simLibrary');
    eq(P.ev('SIM_COUNT'), 0, 'clearLibrary reinicia SIM_COUNT a 0');
    eq(JSON.parse(lsAll(P.w)['msc_ploidy_trash_v5']), before, 'papelera contiene la biblioteca previa');
    eq(P.d.getElementById('btnRestore').style.display, 'inline-block', 'botón Restaurar visible');

    // C6: defecto conocido nº 5 — registerObserved() sobre simLibrary[length-1], no sobre SIM_STATE.simRecord
    await P.set('nSlider', 3); P.w.runMonteCarlo(); await P.idle();      // B: recibe id 1 (SIM_COUNT se reinició)
    const seedB = P.ev('SIM_STATE.simRecord.seed'), seedA = before[0].seed;
    eq(P.ev('SIM_STATE.simRecord.id'), 1, 'KNOWN-BUG: tras clearLibrary la nueva simulación B reutiliza id=1');
    P.w.restoreLibrary();                                                 // biblioteca = [B(id1), A(id1)]
    eq(P.json('simLibrary.map(s=>s.id)'), [1, 1], 'KNOWN-BUG: ids duplicados tras restaurar');
    eq(P.json('simLibrary.map(s=>s.seed)'), [seedB, seedA], 'orden de biblioteca: [B, A]');
    setObs(P, '20');
    eq(P.json('simLibrary[1].observed'), '20.000', 'KNOWN-BUG nº5: la calibración se asignó a A (último de la lista)…');
    eq(P.json('simLibrary[0].observed'), null, '…y NO a B, que es la simulación cuya μ se usó (SIM_STATE)');
    eq(P.json('simLibrary[1].error'), (20 - P.ev('SIM_STATE.mu')).toFixed(3), 'el error se calculó con μ de B pero se guardó en A');
    eq(P.json('Object.keys(localStorage).includes("msc_ploidy_trash_v5")'), false, 'restoreLibrary elimina la papelera');

    // C7: calibrar con biblioteca vacía — el dato se pierde en silencio
    P.w.clearLibrary(); P.alerts.length = 0; setObs(P, '20');
    eq(P.json('simLibrary.length'), 0, 'biblioteca vacía: nada se guarda');
    ok(P.d.getElementById('accuracyDisplay').textContent.includes('EXACTITUD MODELO'), 'pero la UI muestra el resultado igualmente (observación no persistida)');
    eq(P.alerts.length, 0, 'sin aviso al usuario');

    // C8: nombres de claves (contrato con datos ya guardados por usuarios)
    eq([P.ev('STORAGE_KEY'), P.ev('TRASH_KEY')], ['msc_ploidy_library_v5', 'msc_ploidy_trash_v5'], 'nombres de clave *_v5');
    ok(!Object.keys(lsAll(P.w)).some(k => /breeding/i.test(k)), 'ninguna clave msc_breeding* en localStorage');
    P.dom.window.close();
  }
  console.log(`\n${fail ? '✗' : '✓'} Caracterización: ${pass} comprobaciones correctas, ${fail} fallidas`);
  process.exit(fail ? 1 : 0);
})();
