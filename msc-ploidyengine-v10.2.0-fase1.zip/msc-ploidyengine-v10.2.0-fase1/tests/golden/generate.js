#!/usr/bin/env node
// Genera los fixtures de referencia. SOLO se ejecuta a propósito:  node tests/golden/generate.js --write
// Los fixtures se generaron con el motor v10.2.0 SIN la capa MSCBreeding (línea base de la Fase 1).
const fs = require('fs'), path = require('path');
const H = require('./harness'), EG = require('./engine-golden');
if (!process.argv.includes('--write')) { console.log('Uso: node tests/golden/generate.js --write   (sobrescribe fixtures)'); process.exit(1); }
const FX = path.join(__dirname, 'fixtures');
(async () => {
  fs.mkdirSync(FX, { recursive: true });
  const files = {};
  const put = (name, obj) => { const s = JSON.stringify(obj, null, 2) + '\n'; fs.writeFileSync(path.join(FX, name), s); files[name] = H.sha256(s); };
  for (const sc of H.SCENARIOS) {
    const P = await H.openPage({ mode: 'default', randomBase: sc.randomBase });
    await H.runScenario(P, sc);
    if (P.errs.filter(e => !/localStorage/.test(e)).length) throw new Error(`errores de página en ${sc.id}: ${P.errs}`);
    put(`golden_ui_${sc.id}.json`, { scenario: { ...sc }, snapshot: H.snapshot(P) });
    P.dom.window.close();
  }
  const E = EG.load(); const eng = {};
  for (const c of EG.CASES) eng[c.id] = { case: c, result: EG.runCase(E, c) };
  put('golden_engine.json', eng);
  // línea base de archivos protegidos (sha256 de cada archivo de src/ salvo manifest.json)
  const prot = {};
  const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(e => { const p = path.join(d, e.name); e.isDirectory() ? walk(p) : (e.name !== 'manifest.json' && (prot[path.relative(H.ROOT, p)] = H.sha256(fs.readFileSync(p)))); });
  walk(path.join(H.ROOT, 'src'));
  put('protected-files.baseline.json', { note: 'sha256 de src/** (excepto src/manifest.json) en la línea base v10.2.0, antes de la Fase 1', files: prot });
  const meta = { generated_with: { node: process.version, jsdom: require('jsdom/package.json').version },
    baseline_dist_sha256: H.sha256(fs.readFileSync(H.DIST)), fixtures_sha256: files };
  fs.writeFileSync(path.join(FX, 'MANIFEST.json'), JSON.stringify(meta, null, 2) + '\n');
  console.log(`OK  ${Object.keys(files).length} fixtures + MANIFEST.json`);
})();
