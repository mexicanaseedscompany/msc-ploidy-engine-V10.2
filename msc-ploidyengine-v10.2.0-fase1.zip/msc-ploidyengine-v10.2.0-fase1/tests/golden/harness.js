// Arnés compartido de Golden Master y caracterización (jsdom, sin modificar la app).
// Determinismo: Math.random se sustituye por una secuencia fija (solo se usa para SIM_SEED),
// y `date` de simRecord / marcas de tiempo del DOM se normalizan.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { JSDOM, VirtualConsole } = require('jsdom');
const pkg = require('../../package.json');

const ROOT = path.join(__dirname, '..', '..');
const DIST = path.join(ROOT, 'dist', `MSC_PloidyEngine_v${pkg.version.replace(/\./g, '-')}-PloidyGen.html`);
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
const sleep = ms => new Promise(r => setTimeout(r, ms));

// Secuencia determinista para Math.random: r_k → SIM_SEED = randomBase + k·7919
const seedStub = (randomBase) => { let k = 0; return () => ((randomBase + (k++) * 7919) + 0.5) / 999999999; };

// mode: 'default' (no se toca MSCBreeding) | 'off' (enabled=false) | 'on' (enabled=true)
async function openPage({ storage = {}, mode = 'default', randomBase = 100000000, html = null } = {}) {
  const errs = [], alerts = [], confirms = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(e.message.split('\n')[0]));
  const dom = new JSDOM(html ?? fs.readFileSync(DIST, 'utf8'), {
    runScripts: 'dangerously', virtualConsole: vc, pretendToBeVisual: true, url: 'http://localhost/',
    beforeParse(w) {
      w.Math.random = seedStub(randomBase);
      w.alert = m => alerts.push(String(m));
      w.confirm = m => { confirms.push(String(m)); return true; };
      for (const [k, v] of Object.entries(storage)) w.localStorage.setItem(k, v);
      // 'off'/'on' se aplican lo antes posible tras definirse el namespace (fin de carga); ver applyMode()
    }
  });
  const w = dom.window, d = w.document;
  const P = { w, d, dom, errs, alerts, confirms, mode };
  P.ev = expr => w.eval(expr);
  P.json = expr => JSON.parse(w.eval(`JSON.stringify(${expr})`));
  P.set = (id, v) => { d.getElementById(id).value = String(v); };
  P.idle = async () => { await sleep(30); while (d.getElementById('runBtn').classList.contains('running')) await sleep(15); };
  if (mode !== 'default' && w.MSCBreeding) w.MSCBreeding.enabled = (mode === 'on');
  await P.idle();   // espera a que termine la simulación de arranque
  return P;
}

// Configura el cruce y nivel de evidencia por la ruta real de UI y ejecuta la simulación
async function runScenario(P, sc) {
  const { w } = P;
  P.set('parA-ploidy', sc.pA); w.updateParentalGenoOptions('A'); P.set('par4x', sc.gA);
  P.set('parB-ploidy', sc.pB); w.updateParentalGenoOptions('B'); P.set('par2x', sc.gB);
  P.set('nSlider', sc.nIdx ?? 3);
  for (const [id, v] of Object.entries(sc.params ?? {})) P.set(id, v);
  const active = P.ev('EL_ACTIVE_LEVEL');
  if (sc.level !== active) { w.elSelectLevel(sc.level); w.elApply(); } else { w.runMonteCarlo(); }
  await P.idle();
}

const normText = t => t.replace(/\s+/g, ' ').trim()
  .replace(/\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?(\.\d+)?Z?/g, '<DATE>')
  .replace(/\d{1,2}:\d{2}:\d{2}(\s?[AP]M)?/gi, '<TIME>');

// Instantánea determinista de todo lo observable relevante
function snapshot(P) {
  const { d } = P;
  const simLib = P.json('simLibrary');
  const rec = JSON.parse(JSON.stringify(P.json('SIM_STATE.simRecord')));
  delete rec.date;
  const st = P.json(`(function(){const s=SIM_STATE;return {mu:s.mu,sigma:s.sigma,cv:s.cv,allP:s.allP,N:s.N,wsdtMean:s.wsdtMean,sdtMeanTrait:s.sdtMeanTrait,top1n:s.top1n,top5n:s.top5n,top10n:s.top10n,elitePool_len:s.elitePool?s.elitePool.length:null,elitePool_json:JSON.stringify(s.elitePool)}})()`);
  const eliteHash = sha256(st.elitePool_json ?? 'null'); delete st.elitePool_json;
  const skJson = P.ev('JSON.stringify(SK_STATE)');
  const dom = {};
  for (const e of d.querySelectorAll('[id]')) {
    if (e.querySelector('[id]') || !e.textContent.trim()) continue;
    dom[e.id] = sha256(normText(e.textContent));
  }
  const lsKeys = []; for (let i = 0; i < P.w.localStorage.length; i++) lsKeys.push(P.w.localStorage.key(i));
  return {
    el_level: P.ev('EL_ACTIVE_LEVEL'), sim_seed: P.ev('SIM_SEED'), sim_count: P.ev('SIM_COUNT'),
    rng_state_after: P.ev('_RNG._s'),
    sim_record: rec, sim_state: { ...st, elitePool_sha256: eliteHash },
    sl_variance_audit: P.json('window._SL_VARIANCE_AUDIT'),
    sk_state_sha256: sha256(skJson ?? 'null'),
    library_len: simLib.length,
    dom_sha256: dom,
    localStorage_keys: lsKeys.sort()
  };
}

// Matriz de escenarios del Golden Master
const CROSSES = [
  { id: '4x2x', pA: 4, pB: 2, gA: 2, gB: 1 },
  { id: '2x2x', pA: 2, pB: 2, gA: 1, gB: 1 },
  { id: '4x4x', pA: 4, pB: 4, gA: 2, gB: 2 },
  { id: '2x4x', pA: 2, pB: 4, gA: 1, gB: 2 }
];
const SCENARIOS = [];
CROSSES.forEach((c, ci) => [0, 1, 2, 3].forEach(level =>
  SCENARIOS.push({ ...c, id: `${c.id}_L${level}`, level, randomBase: 200000000 + ci * 1000003 + level * 10007 })));
SCENARIOS.push(
  { ...CROSSES[0], id: '4x2x_L3_params', level: 3, randomBase: 310000001,
    params: { alphaSlider: 1200, bivSlider: 30, muBase: 40, efectoAdit: 1.7, h2Slider: 45, sigmaE: 3.5, dominance: 60, epistasis: 25, minDose: 2, wResina: 50, wVigor: 30, wEstructura: 20, c1: 6, c2: 4, c3: 5 } },
  { ...CROSSES[2], id: '4x4x_L2_params', level: 2, randomBase: 320000003,
    params: { alphaSlider: 300, bivSlider: 80, muBase: 55, h2Slider: 70, minDose: 3, c1: 3, c2: 3, c3: 3 } });

module.exports = { ROOT, DIST, sha256, sleep, openPage, runScenario, snapshot, SCENARIOS, CROSSES, normText };
