// Guardia de archivos protegidos: ningún archivo de src/ existente (salvo manifest.json) puede cambiar en la Fase 1.
// Los archivos NUEVOS bajo src/breeding/ están permitidos; cualquier otro archivo nuevo o modificado falla.
const fs = require('fs'), path = require('path');
const { ROOT, sha256 } = require('./harness');
const base = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'protected-files.baseline.json'), 'utf8')).files;
const now = {};
const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(e => { const p = path.join(d, e.name);
  e.isDirectory() ? walk(p) : (e.name !== 'manifest.json' && (now[path.relative(ROOT, p).split(path.sep).join('/')] = sha256(fs.readFileSync(p)))); });
walk(path.join(ROOT, 'src'));
let fail = 0;
for (const [f, h] of Object.entries(base)) {
  if (!(f in now)) { fail++; console.log('  ✗ eliminado:', f); }
  else if (now[f] !== h) { fail++; console.log('  ✗ MODIFICADO:', f); }
}
const added = Object.keys(now).filter(f => !(f in base));
for (const f of added) if (!f.startsWith('src/breeding/')) { fail++; console.log('  ✗ archivo nuevo fuera de src/breeding/:', f); }
console.log(`\nArchivos protegidos: ${Object.keys(base).length} intactos=${Object.keys(base).length - fail}; nuevos permitidos en src/breeding/: ${added.length}`);
console.log(fail ? '✗ FALLA' : '✓ ningún archivo de engine/, ui/, scopes/ ni index.template.html fue modificado');
process.exit(fail ? 1 : 0);
