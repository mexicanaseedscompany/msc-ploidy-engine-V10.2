// Golden Master: el comportamiento actual del motor y de la UI debe permanecer idéntico.
// Compara contra tests/golden/fixtures (generados con la línea base v10.2.0, sin MSCBreeding).
// Si la capa MSCBreeding existe, se ejecuta también con enabled=false y enabled=true (debe ser inerte).
const fs = require('fs'), path = require('path');
const H = require('./harness'), EG = require('./engine-golden');
const FX = path.join(__dirname, 'fixtures');
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : (fail++, console.log('  ✗', m)); };
function diff(a, b, p = '', out = []) {
  if (out.length > 8) return out;
  if (a && b && typeof a === 'object' && typeof b === 'object') { for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) diff(a[k], b[k], `${p}.${k}`, out); }
  else if (a !== b) out.push(`${p}: esperado ${JSON.stringify(a)} ≠ obtenido ${JSON.stringify(b)}`);
  return out;
}
(async () => {
  console.log('\nGolden Master');
  // 0. integridad de los fixtures
  const man = JSON.parse(fs.readFileSync(path.join(FX, 'MANIFEST.json'), 'utf8'));
  for (const [f, h] of Object.entries(man.fixtures_sha256)) ok(H.sha256(fs.readFileSync(path.join(FX, f), 'utf8')) === h, `fixture alterado: ${f}`);
  console.log(`  fixtures íntegros: ${Object.keys(man.fixtures_sha256).length} archivos (sha256 en MANIFEST.json)`);
  console.log(`  generados con node ${man.generated_with.node}, jsdom ${man.generated_with.jsdom}; actual: node ${process.version}`);

  // 1. motor (sin DOM)
  const gold = JSON.parse(fs.readFileSync(path.join(FX, 'golden_engine.json'), 'utf8'));
  const E = EG.load(); let nEng = 0;
  for (const c of EG.CASES) { const d = diff(gold[c.id].result, EG.runCase(E, c)); ok(d.length === 0, `motor ${c.id}: ${d.join(' | ')}`); nEng++; }
  console.log(`  motor:  ${nEng} casos (300 iteraciones MC + 25 cigotos + estado final de _RNG) idénticos`);

  // 2. UI completa
  const probe = await H.openPage({ mode: 'default' });
  const hasNS = typeof probe.w.MSCBreeding !== 'undefined';
  if (hasNS) ok(probe.w.MSCBreeding.enabled === false, 'MSCBreeding.enabled debe ser false por defecto');
  probe.dom.window.close();
  const modes = hasNS ? ['default', 'off', 'on'] : ['default'];
  let nUI = 0;
  for (const mode of modes) for (const sc of H.SCENARIOS) {
    const fx = JSON.parse(fs.readFileSync(path.join(FX, `golden_ui_${sc.id}.json`), 'utf8'));
    const P = await H.openPage({ mode, randomBase: sc.randomBase });
    await H.runScenario(P, sc);
    const real = P.errs.filter(e => !/localStorage/.test(e));
    ok(real.length === 0, `errores de página ${sc.id}/${mode}: ${real}`);
    const d = diff(fx.snapshot, H.snapshot(P));
    ok(d.length === 0, `UI ${sc.id} [${mode}]: ${d.join(' | ')}`);
    P.dom.window.close(); nUI++;
  }
  console.log(`  UI:     ${H.SCENARIOS.length} escenarios × modos [${modes.join(', ')}] = ${nUI} corridas idénticas al fixture`);
  console.log(`          (simRecord sin fecha, SIM_STATE, elitePool, varianza Scope L, SK_STATE, 88 elementos DOM, estado final de _RNG, claves de localStorage)`);

  // 3. Canarios de sensibilidad: el Golden Master DEBE detectar cambios mínimos
  const html0 = fs.readFileSync(H.DIST, 'utf8');
  const sc0 = H.SCENARIOS[0], fx0 = JSON.parse(fs.readFileSync(path.join(FX, `golden_ui_${sc0.id}.json`), 'utf8'));
  const canaries = [
    ['constante alterada 1e-7 en E_comp', '_RNG.normal(0, sigmaE)', '_RNG.normal(0, sigmaE * 1.0000001)'],
    ['un consumo extra de _RNG por individuo', 'const E_comp = _RNG.normal(0, sigmaE);', 'const E_comp = (_RNG.next(), _RNG.normal(0, sigmaE));']
  ];
  for (const [name, from, to] of canaries) {
    ok(html0.includes(from), `canario no aplicable: ${name}`);
    const P = await H.openPage({ mode: 'default', randomBase: sc0.randomBase, html: html0.replace(from, to) });
    await H.runScenario(P, sc0);
    const detected = diff(fx0.snapshot, H.snapshot(P)).length > 0;
    ok(detected, `el Golden Master NO detectó: ${name}`);
    console.log(`  canario: ${name} → ${detected ? 'DETECTADO ✓' : 'NO DETECTADO ✗'}`);
    P.dom.window.close();
  }
  console.log(`\n${fail ? '✗' : '✓'} Golden Master: ${pass} comprobaciones correctas, ${fail} fallidas`);
  process.exit(fail ? 1 : 0);
})();
