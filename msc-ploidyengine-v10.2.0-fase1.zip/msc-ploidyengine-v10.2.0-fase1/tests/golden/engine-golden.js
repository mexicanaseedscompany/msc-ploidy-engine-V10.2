// Golden Master del MOTOR (sin DOM): secuencias de simulateLinkedMCIteration + estado final de _RNG.
// El estado final de _RNG prueba el orden y el número exacto de consumos aleatorios.
const fs = require('fs'), path = require('path'), vm = require('vm');
const { sha256 } = require('./harness');
const ROOT = path.join(__dirname, '..', '..');
function load() {
  const { files } = JSON.parse(fs.readFileSync(path.join(ROOT, 'src', 'manifest.json'), 'utf8'));
  const code = files.filter(f => f.startsWith('src/engine/')).map(f => fs.readFileSync(path.join(ROOT, f), 'utf8')).join('') + `
;({ RNG, GAMETE_COPIES, EpistasisMatrix, HaplotypicBlockEngine, ParentalHaplotype, GenomicPolyploidEngine,
    setSeed: s => { _RNG = new RNG(s); }, rngState: () => _RNG._s })`;
  return vm.runInNewContext(code, { console, Math, Date });
}
const CASES = [];
[[4,2,2,1],[2,2,1,1],[4,4,2,2],[2,4,1,2],[4,2,3,2],[4,4,4,1]].forEach(([pA,pB,gA,gB],i) =>
  [0, 0.05, 1/6].forEach((alpha,j) => CASES.push({ id:`${pA}x${pB}x_g${gA}${gB}_a${j}`, pA,pB,gA,gB,alpha, seed: 4242 + i*101 + j*13 })));
function runCase(E, c) {
  const maxD = E.GAMETE_COPIES[c.pA] + E.GAMETE_COPIES[c.pB];
  E.setSeed(c.seed); E.HaplotypicBlockEngine.setCrossContext(c.pA, c.pB);
  const eng = new E.GenomicPolyploidEngine(c.alpha);
  const genome = E.GenomicPolyploidEngine.buildMCGenome([4, 3, 3], 1.0, 0.5, 0.2, undefined, 10);
  const epi = new E.EpistasisMatrix(); epi.set('MC_C0_L0', 'MC_C1_L1', 0.4, 'syn'); epi.set('MC_C0_L2', 'MC_C2_L0', -0.3, 'ant');
  const out = [];
  for (let i = 0; i < 300; i++) out.push(eng.simulateLinkedMCIteration(genome, c.gA, c.gB, c.alpha, 1, epi, c.pA, c.pB, maxD));
  const mcState = E.rngState();
  eng.buildGenome(genome.map(x => ({ id: x.id, length_cM: x.length_cM, loci: x.loci })));
  const z = [];
  for (let i = 0; i < 25; i++) { const r = eng.generateTriploidZygote(c.gA, c.gB, { bivalent: .6, quadrivalent: .4 }, epi, maxD, c.pA, c.pB);
    z.push(r, E.HaplotypicBlockEngine.computeIIH_global(r.chrResultsK)); }
  return { mc_sha256: sha256(JSON.stringify(out)), zygotes_sha256: sha256(JSON.stringify(z)), rng_after_mc: mcState, rng_after_all: E.rngState() };
}
module.exports = { load, CASES, runCase };
