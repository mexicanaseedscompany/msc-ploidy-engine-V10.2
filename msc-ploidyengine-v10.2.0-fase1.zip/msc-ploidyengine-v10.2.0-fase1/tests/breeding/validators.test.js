const fs = require('fs'), path = require('path');
module.exports = async (t, load) => {
  const { B, ROOT } = load(), DM = B.modules['data-model'];
  const V = (ent, f, o) => DM.validate(ent, DM.create(ent, f, o));

  t.section('Schema: entidades definidas');
  t.eq(DM.entities(), ['Plant', 'Cross', 'Population', 'Environment', 'Trait', 'Observation', 'Genotype', 'SimulationContext',
    'PredictedDistribution', 'CalibrationRecord', 'ModelVersion', 'BreedingCycle', 'ValidationResult', 'PredictionAudit', 'EvidenceState'], 'las 15 entidades');
  t.ok(DM.entities().every(e => DM.describe(e).length > 3), 'describe() documenta cada entidad');
  t.eq(DM.SCHEMA_VERSION, '1.0.0', 'SCHEMA_VERSION');

  t.section('create(): NO inventa datos');
  const p = DM.create('Plant', { plant_id: 'P1' }, { clock: () => '2026-01-01T00:00:00Z' });
  const unknownFields = Object.keys(p).filter(k => !['plant_id', 'schema_version', 'created_at', 'updated_at'].includes(k));
  t.ok(unknownFields.every(k => p[k] === null), 'todo campo no suministrado queda en null (family_id, generation, sex, ploidy, ...)');
  t.eq([p.created_at, p.updated_at, p.schema_version], ['2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z', '1.0.0'], 'solo metadatos de registro con reloj inyectable');
  t.eq(p.record_origin, null, 'record_origin NO se inventa');
  t.has(t.codes(DM.validate('Plant', p)), 'NULL_REQUIRED', 'record_origin ausente => INVALID (no se adivina "direct")');
  t.eq(DM.create('Trait', { trait_id: 't', name: 'n', type: 'continuous' }).engine_channel, 'unknown', 'único default declarado: engine_channel="unknown"');
  t.eq(DM.create('ModelVersion', { model_id: 'm', version: '1', kind: 'statistical', algorithm: 'a' }).status, 'candidate', 'default declarado: status="candidate"');
  const src = { plant_id: 'P2', notes: 'x', nested: { a: [1, { b: 2 }] } }, cp = DM.create('Plant', src);
  cp.nested.a[1].b = 99; t.eq(src.nested.a[1].b, 2, 'create() copia en profundidad (no comparte referencias)');

  t.section('Validación mínima por entidad (registro mínimo válido → VALID; sin identificador → INVALID)');
  const minimal = {
    Plant: { plant_id: 'P1', record_origin: 'direct' },
    Population: { population_id: 'POP1', record_origin: 'direct' },
    Environment: { environment_id: 'E1' },
    Trait: { trait_id: 'resin', name: 'Resin', type: 'continuous' },
    Observation: { observation_id: 'o1', plant_id: 'P1', trait_id: 'resin', value: 8.2, record_origin: 'direct' },
    Genotype: { plant_id: 'P1', marker_id: 'm1' },
    BreedingCycle: { cycle_id: 'C1' },
    ModelVersion: { model_id: 'PE-PRED-001', version: 'v0.1', kind: 'statistical', algorithm: 'baseline_mean' },
    CalibrationRecord: { calibration_id: 'cal1', record_origin: 'direct' },
    ValidationResult: { validation_id: 'val1', method: 'family_holdout', training_units: {}, test_units: {}, metrics: { test: {} }, disjoint: true }
  };
  for (const [ent, f] of Object.entries(minimal)) {
    t.eq(V(ent, f).status, 'VALID', `${ent} mínimo => VALID`);
    const idKey = Object.keys(f)[0], noId = Object.assign({}, f); delete noId[idKey];
    t.eq(V(ent, noId).status, 'INVALID', `${ent} sin ${idKey} => INVALID`);
  }
  t.eq(V('Cross', { cross_id: 'X1', record_origin: 'direct' }).status, 'WARNING', 'Cross sin padres => WARNING (PARENT_UNKNOWN)');
  t.eq(t.codes(V('Cross', { cross_id: 'X1', record_origin: 'direct' })), ['PARENT_UNKNOWN', 'PARENT_UNKNOWN'], 'madre y padre desconocidos se señalan');

  t.section('Tipos, rangos y enums');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { sex: 'robot' }))), 'INVALID_ENUM', 'sex fuera del enum');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { ploidy: 0 }))), 'OUT_OF_RANGE', 'ploidía < 1');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { ploidy: 2.5 }))), 'WRONG_TYPE', 'ploidía no entera');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { date_created: '31/12/2026' }))), 'WRONG_TYPE', 'fecha no ISO-8601');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { date_created: '2026-02-31' }))), 'WRONG_TYPE', 'fecha imposible (31 de febrero)');
  t.eq(V('Plant', Object.assign({}, minimal.Plant, { date_created: '2026-03-01', date_evaluated: '2026-03-10T12:00:00Z' })).status, 'VALID', 'fechas ISO válidas');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { date_created: '2026-03-10', date_evaluated: '2026-03-01' }))), 'EVALUATED_BEFORE_CREATED', 'evaluada antes de creada');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { mother_id: 'P1' }))), 'SELF_PARENT', 'una planta no puede ser su propia madre');
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { father_id: 'P1' }))), 'SELF_PARENT', '...ni su propio padre');
  t.has(t.codes(V('Environment', { environment_id: 'E', humidity: 120 })), 'OUT_OF_RANGE', 'humedad > 100');
  t.has(t.codes(V('Environment', { environment_id: 'E', date_start: '2026-05-01', date_end: '2026-04-01' })), 'END_BEFORE_START', 'ambiente: fin antes del inicio');
  t.has(t.codes(V('Population', Object.assign({}, minimal.Population, { planned_size: 10, actual_size: 12 }))), 'ACTUAL_GT_PLANNED', 'tamaño real > planificado => WARNING');
  t.eq(V('Population', Object.assign({}, minimal.Population, { planned_size: 10, actual_size: 12 })).status, 'WARNING', '...y es WARNING, no INVALID (no se descarta el dato)');
  t.has(t.codes(V('Observation', Object.assign({}, minimal.Observation, { confidence: 1.5 }))), 'OUT_OF_RANGE', 'confianza fuera de [0,1]');
  t.has(t.codes(V('Observation', Object.assign({}, minimal.Observation, { replicate: 0 }))), 'OUT_OF_RANGE', 'réplica < 1');
  t.has(t.codes(V('Observation', Object.assign({}, minimal.Observation, { value: null }))), 'NULL_REQUIRED', 'value=null no es una observación');
  t.has(t.codes(V('Observation', Object.assign({}, minimal.Observation, { value: undefined }))), 'MISSING_REQUIRED', 'value ausente no es una observación');

  t.section('Registros legacy: se aceptan con campos desconocidos, sin inventar');
  const legacySim = { simulation_id: 'legacy-3', legacy_id: 3, record_origin: 'legacy', seed: 123456, engine_version: '10.2.0-PloidyGen',
    original: { cross: '4x(g2) x 2x(g1)', alpha: '0.0500', prediction: { mu: '47.113' } } };
  const vs = V('SimulationContext', legacySim);
  t.eq(vs.status, 'VALID', 'SimulationContext legacy con muchos campos null => VALID');
  const nonLegacy = V('SimulationContext', Object.assign({}, legacySim, { record_origin: 'direct' }));
  t.eq(nonLegacy.status, 'INVALID', 'el mismo registro NO legacy exige los campos obligatorios');
  t.has(nonLegacy.errors.map(e => e.field), 'muBase', '...p. ej. muBase');
  const cs = DM.create('SimulationContext', legacySim);
  t.ok(['muBase', 'efectoAdit', 'h2', 'sigmaE', 'domCoef', 'epiCoef', 'ploidy_a', 'ploidy_b', 'evidence_level_selected', 'evidence_flags', 'genome_configuration', 'environment_id'].every(k => cs[k] === null),
    'campos que simRecord nunca guardó permanecen null (no se rellenan con valores actuales de la UI)');
  t.eq(cs.original.alpha, '0.0500', 'strings originales conservados literalmente en `original`');

  // Registro legacy real tomado del Golden Master (simRecord de v10.2.0): el schema lo representa sin pérdida
  const g = JSON.parse(fs.readFileSync(path.join(ROOT, 'tests/golden/fixtures/golden_ui_4x2x_L3.json'), 'utf8')).snapshot.sim_record;
  const fromGolden = DM.create('SimulationContext', { simulation_id: 'legacy-' + g.id, legacy_id: g.id, record_origin: 'legacy', engine_version: g.version, seed: g.seed, N: g.N, original: g });
  t.eq(DM.validate('SimulationContext', fromGolden).status, 'VALID', 'simRecord real del Golden Master (sin fecha) cabe en el schema como legacy');
  t.eq(fromGolden.original, g, '...y se conserva idéntico en `original`');
  t.ok(fromGolden.alpha === null && fromGolden.ploidy_a === null, '...sin parsear ni derivar nada (la migración es de la Fase 3)');

  t.section('Trait: configurable, sin escalas 0–10 impuestas');
  t.has(t.codes(V('Trait', { trait_id: 't', name: 'n', type: 'continuous', scale_min: 5, scale_max: 5 })), 'BAD_SCALE', 'scale_min < scale_max');
  t.has(t.codes(V('Trait', { trait_id: 't', name: 'n', type: 'continuous', heritability: 0.4 })), 'SOURCE_REQUIRED', 'heredabilidad sin fuente => INVALID (no se acepta h² sin origen)');
  t.eq(V('Trait', { trait_id: 't', name: 'n', type: 'continuous', heritability: 0.4, heritability_source: 'estimación propia 2025' }).status, 'VALID', 'heredabilidad con fuente');
  t.has(t.codes(V('Trait', { trait_id: 't', name: 'n', type: 'continuous', heritability: 1.4, heritability_source: 's' })), 'OUT_OF_RANGE', 'h² ∈ [0,1]');
  t.has(t.codes(V('Trait', { trait_id: 't', name: 'n', type: 'magic' })), 'INVALID_ENUM', 'tipo de carácter inválido');
  t.has(t.codes(V('Trait', { trait_id: 't', name: 'n', type: 'chemical', engine_channel: 'sdt:7' })), 'INVALID_ENUM', 'engine_channel inválido');
  t.eq(V('Trait', { trait_id: 'thc', name: 'THC', type: 'chemical', unit: '% p/p', scale_min: 0, scale_max: 40, engine_channel: 'phenotype' }).status, 'VALID', 'carácter químico con escala propia');

  t.section('Valor de observación coherente con el tipo de carácter (validateObservationValue)');
  const ov = (type, value, extra) => DM.validateObservationValue({ value }, Object.assign({ type }, extra || {}));
  t.eq(ov('continuous', 8.2).status, 'VALID', 'continuo numérico');
  t.eq(ov('continuous', '8.2').status, 'INVALID', 'continuo: un string NO se convierte');
  t.has(t.codes(ov('continuous', 12, { scale_min: 0, scale_max: 10 })), 'OUT_OF_RANGE', 'continuo fuera de escala');
  t.has(t.codes(ov('percentage', 101)), 'OUT_OF_RANGE', 'porcentaje > 100');
  t.eq(ov('percentage', 55.5).status, 'VALID', 'porcentaje válido');
  t.eq(ov('ordinal', 3, { scale_min: 1, scale_max: 5 }).status, 'VALID', 'ordinal entero en escala');
  t.eq(ov('ordinal', 2.5, { scale_min: 1, scale_max: 5 }).status, 'INVALID', 'ordinal no entero');
  t.eq(ov('ordinal', 9, { scale_min: 1, scale_max: 5 }).status, 'INVALID', 'ordinal fuera de escala');
  t.eq([0, 1, true, false].map(v => ov('binary', v).status), ['VALID', 'VALID', 'VALID', 'VALID'], 'binario: 0/1/true/false');
  t.eq(ov('binary', 2).status, 'INVALID', 'binario: 2 inválido');
  t.eq(ov('categorical', 'citrus').status, 'VALID', 'categórico: string');
  t.eq(ov('categorical', 7).status, 'INVALID', 'categórico: número inválido');
  t.eq(ov('chemical', 21.4, { scale_min: 0 }).status, 'VALID', 'químico numérico');
  t.eq(ov('chemical', -1, { scale_min: 0 }).status, 'INVALID', 'químico bajo el mínimo');
  const um = DM.validateObservationValue({ value: 5, unit: 'g' }, { type: 'continuous', unit: 'kg' });
  t.eq([um.status, t.codes(um)], ['WARNING', ['UNIT_MISMATCH']], 'unidad distinta => WARNING (no se convierte ni se descarta)');

  t.section('Valores no representables en JSON se RECHAZAN (no se convierten en null)');
  for (const [label, v] of [['NaN', NaN], ['Infinity', Infinity], ['-Infinity', -Infinity]]) {
    const r = V('Observation', Object.assign({}, minimal.Observation, { value: v }));
    t.eq(r.status, 'INVALID', `value=${label} => INVALID`);
    t.has(t.codes(r), 'NOT_JSON_SAFE', `value=${label}: NOT_JSON_SAFE`);
  }
  t.has(t.codes(V('Plant', Object.assign({}, minimal.Plant, { date_created: new Date() }))), 'NOT_JSON_SAFE', 'objeto Date => NOT_JSON_SAFE (use ISO-8601)');
  t.has(t.codes(V('PredictedDistribution', { prediction_id: 'p', provenance: 'SIMULATED', record_origin: 'legacy', quantiles: { p10: NaN } })), 'NOT_JSON_SAFE', 'NaN anidado detectado');
  t.eq(DM.jsonUnsafe({ a: [1, { b: NaN }] }), ['a[1].b'], 'jsonUnsafe informa la ruta exacta');
  t.eq(DM.jsonUnsafe({ a: undefined, b: null, c: 'x' }), [], 'undefined/null/strings son seguros (ausente ≠ inventado)');

  t.section('PredictedDistribution: distribución completa, no solo la media');
  const pd = (extra) => V('PredictedDistribution', Object.assign({ prediction_id: 'p', provenance: 'SIMULATED', record_origin: 'legacy' }, extra));
  t.eq(pd({ quantiles: { p10: 1, p25: 2, p50: 3, p75: 4, p90: 5, p95: 6 }, mean: 3, sd: 1, variance: 1, cv: 33, n_virtual: 1000 }).status, 'VALID', 'distribución con cuantiles P10..P95');
  t.has(t.codes(pd({ quantiles: { p10: 5, p25: 2 } })), 'QUANTILES_NOT_MONOTONE', 'cuantiles no monótonos');
  t.has(t.codes(pd({ uncertainty: { interval_low: 9, interval_high: 1 } })), 'BAD_INTERVAL', 'intervalo invertido');
  t.has(t.codes(pd({ variance: -1 })), 'OUT_OF_RANGE', 'varianza negativa');
  t.has(t.codes(V('PredictedDistribution', { prediction_id: 'p', provenance: 'SIMULATED', record_origin: 'direct' })), 'NULL_REQUIRED', 'registro no legacy exige mean');

  t.section('ModelVersion y EvidenceState');
  t.eq(t.codes(V('ModelVersion', Object.assign({}, minimal.ModelVersion, { status: 'active' }))), ['NO_OUT_OF_SAMPLE_METRICS'], 'modelo active sin métricas test fuera de muestra => WARNING');
  t.eq(V('ModelVersion', Object.assign({}, minimal.ModelVersion, { status: 'active', metrics: { test: { mae: 1 } } })).status, 'VALID', '...con métricas test => VALID');
  t.has(t.codes(V('ModelVersion', Object.assign({}, minimal.ModelVersion, { kind: 'neural' }))), 'INVALID_ENUM', 'kind inválido');
  const lvl = (o) => Object.assign({ data_available: [], data_required: [], data_missing: [], inference_used: [], observed_data: false, simulated_data: false, capability: 'unavailable' }, o);
  const es = (levels, sel) => V('EvidenceState', { evidence_state_id: 'es1', selected_level: sel || 'L3', levels });
  t.eq(es({ L3: lvl({ data_required: ['markers'], data_missing: ['markers'], capability: 'unavailable' }) }).status, 'VALID', 'L3 seleccionado SIN marcadores => capacidad "unavailable" es coherente');
  const bad = es({ L3: lvl({ data_required: ['markers'], data_missing: ['markers'], capability: 'available' }) });
  t.eq(bad.status, 'INVALID', 'L3 "available" con datos faltantes => INVALID');
  t.has(t.codes(bad), 'CAPABILITY_WITHOUT_DATA', '...CAPABILITY_WITHOUT_DATA: seleccionar un nivel no crea capacidad');
  t.has(t.codes(es({ L2: lvl({ capability: 'assumed', simulated_data: false }) })), 'ASSUMED_WITHOUT_SIMULATED_FLAG', '"assumed" debe declarar simulated_data');
  t.eq(es({ L2: lvl({ capability: 'assumed', simulated_data: true, inference_used: ['QTL de ejemplo'] }) }).status, 'VALID', '"assumed" con simulated_data=true');
  t.has(t.codes(es({ L9: lvl({}) })), 'INVALID_ENUM', 'nivel inexistente');
  t.has(t.codes(es({ L1: lvl({ capability: 'maybe' }) })), 'INVALID_ENUM', 'capability inválida');

  t.section('Campos desconocidos, versión de schema y objeto inválido');
  const uf = V('Plant', Object.assign({}, minimal.Plant, { color: 'rojo' }));
  t.eq([uf.status, t.codes(uf)], ['WARNING', ['UNKNOWN_FIELD']], 'campo desconocido => WARNING (no se elimina)');
  const sv = DM.validate('Plant', Object.assign(DM.create('Plant', minimal.Plant), { schema_version: '0.9.0' }));
  t.has(t.codes(sv), 'SCHEMA_VERSION_MISMATCH', 'schema_version distinta => WARNING');
  t.eq(DM.validate('Plant', null).status, 'INVALID', 'null no es un registro');
  t.eq(DM.validate('Plant', [1]).status, 'INVALID', 'un arreglo no es un registro');
  let threw = false; try { DM.validate('Nope', {}); } catch (e) { threw = true; }
  t.ok(threw, 'entidad desconocida lanza error');
  const rec = DM.create('Plant', minimal.Plant), before = JSON.stringify(rec); DM.validate('Plant', rec);
  t.eq(JSON.stringify(rec), before, 'validate() no modifica ni corrige el registro');
  t.eq(DM.keyOf('Genotype', { plant_id: 'P', marker_id: 'm' }), 'P|m', 'clave compuesta Genotype');
  t.eq(DM.keyOf('Genotype', { plant_id: 'P' }), null, 'clave compuesta incompleta => null (no "P|undefined")');
  t.eq(DM.keyOf('ModelVersion', { model_id: 'M', version: 'v1' }), 'M@v1', 'clave compuesta ModelVersion');
};
