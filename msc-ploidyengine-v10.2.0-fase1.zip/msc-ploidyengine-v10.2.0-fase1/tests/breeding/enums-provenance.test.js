module.exports = async (t, load) => {
  const { B } = load(), DM = B.modules['data-model'], E = DM.ENUMS;

  t.section('Enumeraciones cerradas e inmutables');
  t.eq(E.provenance, ['SIMULATED', 'OBSERVED', 'CALIBRATED', 'PREDICTED', 'VALIDATED', 'INFERRED'], 'provenance: exactamente los 6 valores');
  t.eq(E.quality_status, ['VALID', 'WARNING', 'INVALID'], 'quality_status');
  t.eq(E.trait_type, ['continuous', 'ordinal', 'binary', 'categorical', 'percentage', 'chemical'], 'tipos de carácter (no todo es escala 0-10)');
  t.eq(E.evidence_level, ['L0', 'L1', 'L2', 'L3'], 'niveles de evidencia');
  t.eq(E.validation_method, ['random_holdout', 'family_holdout', 'generational_holdout', 'cross_holdout', 'future_generation'], 'métodos de validación');
  t.ok(Object.isFrozen(E) && Object.keys(E).every(k => Object.isFrozen(E[k])), 'ENUMS congelado (profundo)');
  t.ok(Object.isFrozen(DM.PROVENANCE_RULES) && Object.keys(DM.PROVENANCE_RULES).every(k => Object.isFrozen(DM.PROVENANCE_RULES[k])), 'PROVENANCE_RULES congelado');

  t.section('Separación estricta de procedencia: matriz completa entidad × valor (6 × 6)');
  // Registro base válido por entidad; solo se varía provenance. Se comprueba ÚNICAMENTE el código PROVENANCE_NOT_ALLOWED
  // (otras reglas, p. ej. PREDICTED necesita modelo, se prueban aparte).
  const base = {
    Observation:           { observation_id: 'o', plant_id: 'p', trait_id: 't', value: 1, record_origin: 'direct' },
    SimulationContext:     { simulation_id: 's', record_origin: 'legacy' },
    PredictedDistribution: { prediction_id: 'pd', record_origin: 'legacy' },
    CalibrationRecord:     { calibration_id: 'c', record_origin: 'direct' },
    ValidationResult:      { validation_id: 'v', method: 'family_holdout', training_units: {}, test_units: {}, metrics: { test: {} }, disjoint: true },
    PredictionAudit:       { audit_id: 'a', prediction_id: 'pd' }
  };
  const rules = DM.PROVENANCE_RULES;
  t.eq(Object.keys(rules).sort(), Object.keys(base).sort(), 'todas las entidades con procedencia están cubiertas por la matriz');
  for (const ent of Object.keys(base)) for (const p of E.provenance) {
    const rec = DM.create(ent, Object.assign({}, base[ent], { provenance: p }));
    const rejected = t.codes(DM.validate(ent, rec)).includes('PROVENANCE_NOT_ALLOWED');
    t.eq(rejected, !rules[ent].includes(p), `${ent} con provenance=${p}: ${rules[ent].includes(p) ? 'admitida' : 'rechazada'}`);
  }

  t.section('Reglas semánticas clave de procedencia');
  t.eq(DM.create('Observation', base.Observation).provenance, 'OBSERVED', 'Observation se crea OBSERVED');
  t.eq(DM.create('SimulationContext', base.SimulationContext).provenance, 'SIMULATED', 'SimulationContext se crea SIMULATED');
  t.eq(DM.create('CalibrationRecord', base.CalibrationRecord).provenance, 'CALIBRATED', 'CalibrationRecord se crea CALIBRATED');
  t.eq(DM.create('ValidationResult', base.ValidationResult).provenance, 'VALIDATED', 'ValidationResult se crea VALIDATED');
  t.eq(DM.create('PredictedDistribution', base.PredictedDistribution).provenance, null, 'PredictedDistribution NO adivina su procedencia (varias admitidas)');
  t.has(t.codes(DM.validate('PredictedDistribution', DM.create('PredictedDistribution', base.PredictedDistribution))), 'NULL_REQUIRED', 'sin provenance explícita => inválido');
  t.ok(!E.provenance.includes('VALIDATED') || !rules.PredictedDistribution.includes('VALIDATED'), 'una distribución individual no puede declararse VALIDATED');
  t.ok(!rules.Observation.includes('SIMULATED') && !rules.SimulationContext.includes('OBSERVED'), 'una observación no es SIMULATED ni una simulación OBSERVED');

  const pdv = (extra) => DM.validate('PredictedDistribution', DM.create('PredictedDistribution', Object.assign({ prediction_id: 'x', record_origin: 'legacy' }, extra)));
  t.has(t.codes(pdv({ provenance: 'PREDICTED' })), 'PREDICTED_NEEDS_MODEL', 'PREDICTED exige modelo/versión/dataset de entrenamiento');
  t.eq(t.codes(pdv({ provenance: 'PREDICTED', model_id: 'm', model_version: '1', training_dataset_version: 'd1' })).includes('PREDICTED_NEEDS_MODEL'), false, 'PREDICTED completa: sin ese error');
  t.has(t.codes(pdv({ provenance: 'CALIBRATED' })), 'CALIBRATED_NEEDS_CALIBRATION', 'CALIBRATED exige calibration_id');
  t.has(t.codes(pdv({ provenance: 'SIMULATED', model_id: 'm' })), 'SIMULATED_WITH_MODEL', 'SIMULATED no puede citar un modelo');
  t.eq(pdv({ provenance: 'SIMULATED' }).status === 'INVALID', false, 'SIMULATED simple es aceptable');

  t.section('VALIDATED solo con evidencia fuera de muestra');
  const vr = (extra) => DM.validate('ValidationResult', DM.create('ValidationResult', Object.assign({}, base.ValidationResult, extra)));
  t.eq(vr({}).status, 'VALID', 'validación por familia, disjunta, con métricas test => VALID');
  t.has(t.codes(vr({ metrics: { train: { mae: 1 } } })), 'VALIDATED_NEEDS_TEST_METRICS', 'sin métricas de test no hay VALIDATED');
  t.has(t.codes(vr({ method: 'random_holdout', disjoint: null })), 'RANDOM_HOLDOUT_MUST_FLAG_LEAKAGE', 'random_holdout debe declarar riesgo de fuga');
  t.eq(vr({ method: 'random_holdout', leakage_prone: true, disjoint: null }).status, 'VALID', 'random_holdout con leakage_prone=true es aceptable');
  t.has(t.codes(vr({ disjoint: false })), 'SPLIT_NOT_DISJOINT', 'holdout por familia/cruce/generación exige unidades disjuntas');
  t.has(t.codes(vr({ method: 'cross_holdout', disjoint: null })), 'SPLIT_NOT_DISJOINT', 'cross_holdout sin disjoint');
};
