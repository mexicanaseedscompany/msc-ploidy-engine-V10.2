// Mini-arnés de pruebas (sin dependencias). Cada archivo *.test.js exporta async (t, load) => {...}
let pass = 0, fail = 0, current = '';
const t = {
  section(name) { current = name; console.log('\n' + name); },
  ok(cond, msg) { cond ? pass++ : (fail++, console.log(`  ✗ [${current}] ${msg}`)); },
  eq(a, b, msg) { const A = JSON.stringify(a), B = JSON.stringify(b); t.ok(A === B, `${msg}: obtenido ${A} ≠ esperado ${B}`); },
  has(arr, v, msg) { t.ok(Array.isArray(arr) && arr.indexOf(v) >= 0, `${msg}: falta ${JSON.stringify(v)} en ${JSON.stringify(arr)}`); },
  async rejects(p, code, msg) {
    try { await p; t.ok(false, `${msg}: no se rechazó (esperado ${code})`); }
    catch (e) { t.ok(e && e.code === code, `${msg}: código ${e && e.code} ≠ ${code}`); return e; }
  },
  codes(report) { return report.errors.concat(report.warnings).map(i => i.code); },
  get counts() { return { pass, fail }; }
};
module.exports = t;
