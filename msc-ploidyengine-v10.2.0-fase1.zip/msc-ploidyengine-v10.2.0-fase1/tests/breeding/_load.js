// Carga src/breeding/core/*.js (en el orden de manifest.json) en un contexto vm AISLADO y nuevo.
// Devuelve el contexto antes/después para demostrar que la capa solo añade el global MSCBreeding.
const vm = require('vm'), fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..', '..');
const coreFiles = () => JSON.parse(fs.readFileSync(path.join(ROOT, 'src', 'manifest.json'), 'utf8')).files.filter(f => f.startsWith('src/breeding/core/'));
module.exports = function load(opts) {
  const ctx = vm.createContext({ console });
  const names = () => vm.runInContext('Object.getOwnPropertyNames(globalThis)', ctx).sort();
  const before = names();
  (opts && opts.only ? opts.only : coreFiles()).forEach(f => vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), ctx, { filename: f }));
  return { B: ctx.MSCBreeding, ctx, before, after: names(), files: coreFiles(), ROOT, run: code => vm.runInContext(code, ctx) };
};
module.exports.coreFiles = coreFiles; module.exports.ROOT = ROOT;
