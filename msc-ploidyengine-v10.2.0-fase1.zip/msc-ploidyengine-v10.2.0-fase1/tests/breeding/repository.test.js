// Pruebas de BreedingRepository (contrato) + InMemoryRepository — Fase 1b.
// Cubre: insert, get, has, list, count, update, remove, clear, collections, snapshot, restore,
// clave duplicada, validación de schema, procedencia, inmutabilidad (PROVENANCE/CREATED_AT/KEY),
// ausencia de invención de datos y rechazo de valores no representables en JSON.
module.exports = async (t, load) => {
  const { B } = load();
  const DM = B.modules['data-model'], R = B.modules.repository;
  let n = 0;
  const clock = () => { n++; return '2026-01-01T00:' + String(Math.floor(n / 60) % 60).padStart(2, '0') + ':' + String(n % 60).padStart(2, '0') + 'Z'; };   // reloj inyectado, determinista y siempre válido
  const mk = (ent, f) => DM.create(ent, f, { clock });
  const plant = (id, extra) => mk('Plant', Object.assign({ plant_id: id, record_origin: 'direct' }, extra));
  const obs = (id, extra) => mk('Observation', Object.assign({ observation_id: id, plant_id: 'P1', trait_id: 'resin', value: 8.2, record_origin: 'direct' }, extra));
  const legacySim = (id, extra) => mk('SimulationContext', Object.assign({ simulation_id: id, record_origin: 'legacy' }, extra));
  const fresh = () => R.InMemoryRepository({ clock });
  const codesOf = e => (e && e.detail && e.detail.errors ? t.codes(e.detail) : []);

  // ─────────────────────────────────────────────────────────────
  t.section('Contrato: interfaz, colecciones y asincronía');
  const repo0 = fresh();
  t.eq(R.INTERFACE, ['insert', 'get', 'has', 'list', 'count', 'update', 'remove', 'clear', 'collections', 'snapshot', 'restore'], 'INTERFACE: 11 métodos');
  t.eq(R.implementsRepository(repo0), [], 'InMemoryRepository implementa los 11 métodos');
  t.eq(R.implementsRepository({}).length, 11, 'un objeto vacío no implementa ninguno');
  t.eq(R.implementsRepository({ insert() {}, get() {} }).length, 9, 'una implementación parcial reporta lo que falta');
  t.ok(Object.isFrozen(R.COLLECTIONS) && Object.isFrozen(R.INTERFACE), 'COLLECTIONS e INTERFACE congeladas');
  t.eq(repo0.collections(), ['plants', 'crosses', 'populations', 'environments', 'traits', 'observations', 'genotypes', 'simulations', 'predictions', 'calibrations', 'models', 'cycles', 'validations', 'audits', 'evidence_states'], 'collections(): 15 colecciones, síncrono');
  t.eq(Array.isArray(repo0.collections()), true, 'collections() es síncrono (devuelve array)');
  t.ok(Object.values(R.COLLECTIONS).every(e => DM.entities().includes(e)), 'cada colección apunta a una entidad del schema');
  ['insert', 'get', 'has', 'list', 'count', 'update', 'remove', 'clear', 'snapshot', 'restore'].forEach(m => {
    const out = (m === 'snapshot') ? repo0.snapshot() : (m === 'restore' ? repo0.restore({}) : repo0[m]('plants', 'x', {}));
    t.ok(out && typeof out.then === 'function', `${m}() devuelve Promise`);
    out.catch(() => {});
  });
  await t.rejects(repo0.count('no_existe'), 'UNKNOWN_COLLECTION', 'colección desconocida (count)');
  await t.rejects(repo0.insert('no_existe', {}), 'UNKNOWN_COLLECTION', 'colección desconocida (insert)');
  await t.rejects(repo0.get('no_existe', 'x'), 'UNKNOWN_COLLECTION', 'colección desconocida (get)');
  await t.rejects(repo0.list('no_existe'), 'UNKNOWN_COLLECTION', 'colección desconocida (list)');
  await t.rejects(repo0.clear('no_existe'), 'UNKNOWN_COLLECTION', 'colección desconocida (clear)');

  // ─────────────────────────────────────────────────────────────
  t.section('insert · get · has · count · list');
  const r1 = fresh();
  t.eq(await r1.count('plants'), 0, 'repositorio nuevo: count=0');
  t.eq(await r1.get('plants', 'P1'), null, 'get de clave inexistente → null (no lanza)');
  t.eq(await r1.has('plants', 'P1'), false, 'has → false');
  const p1 = plant('P1', { family_id: 'F1', generation: 'P' });
  const ins = await r1.insert('plants', p1);
  t.eq(ins.key, 'P1', 'insert devuelve la clave');
  t.eq(ins.record, p1, 'insert devuelve el registro tal cual (sin campos añadidos)');
  t.eq(ins.validation.status, 'VALID', 'insert informa la validación (VALID)');
  t.eq(await r1.has('plants', 'P1'), true, 'has → true');
  t.eq(await r1.count('plants'), 1, 'count=1');
  t.eq(await r1.get('plants', 'P1'), p1, 'get devuelve lo insertado');
  await r1.insert('plants', plant('P2', { family_id: 'F1', generation: 'F1' }));
  await r1.insert('plants', plant('P3', { family_id: 'F2', generation: 'F1' }));
  t.eq((await r1.list('plants')).map(x => x.plant_id), ['P1', 'P2', 'P3'], 'list: todos, en orden de inserción');
  t.eq((await r1.list('plants', x => x.family_id === 'F1')).map(x => x.plant_id), ['P1', 'P2'], 'list con predicado');
  t.eq(await r1.list('plants', () => false), [], 'list con predicado que no coincide → []');
  t.eq(await r1.count('observations'), 0, 'las colecciones son independientes');
  // aislamiento por copia profunda
  const orig = plant('P9', { notes: 'a' }); await r1.insert('plants', orig); orig.notes = 'MUTADO';
  t.eq((await r1.get('plants', 'P9')).notes, 'a', 'mutar el original DESPUÉS de insertar no altera lo almacenado');
  const g = await r1.get('plants', 'P9'); g.notes = 'MUTADO2';
  t.eq((await r1.get('plants', 'P9')).notes, 'a', 'mutar lo devuelto por get no altera lo almacenado');
  const l = await r1.list('plants'); l[0].family_id = 'XX';
  t.eq((await r1.get('plants', 'P1')).family_id, 'F1', 'mutar lo devuelto por list no altera lo almacenado');
  const repoB = fresh(); t.eq(await repoB.count('plants'), 0, 'dos repositorios no comparten estado');

  // ─────────────────────────────────────────────────────────────
  t.section('Clave duplicada (nunca se sobrescribe en silencio)');
  const dupErr = await t.rejects(r1.insert('plants', plant('P1', { family_id: 'OTRA' })), 'DUPLICATE_KEY', 'insert con clave existente');
  t.eq(dupErr && dupErr.detail, { key: 'P1' }, 'el error informa la clave');
  t.eq((await r1.get('plants', 'P1')).family_id, 'F1', 'el registro original queda intacto');
  t.eq(await r1.count('plants'), 4, 'el conteo no cambia');

  // ─────────────────────────────────────────────────────────────
  t.section('Validación de schema al insertar');
  const r2 = fresh();
  let e = await t.rejects(r2.insert('plants', { plant_id: 'X' }), 'VALIDATION_FAILED', 'registro incompleto (sin metadatos/record_origin) → rechazado');
  t.has(codesOf(e), 'MISSING_REQUIRED', 'el informe indica MISSING_REQUIRED');
  t.eq(e && e.detail && e.detail.status, 'INVALID', 'el informe de validación viaja en error.detail');
  t.eq(await r2.count('plants'), 0, 'un registro INVALID no se almacena');
  e = await t.rejects(r2.insert('plants', plant(null, {})), 'VALIDATION_FAILED', 'clave nula → rechazado');
  e = await t.rejects(r2.insert('plants', 'texto'), 'VALIDATION_FAILED', 'no-objeto → rechazado');
  e = await t.rejects(r2.insert('plants', null), 'VALIDATION_FAILED', 'null → rechazado');
  e = await t.rejects(r2.insert('plants', [1]), 'VALIDATION_FAILED', 'array → rechazado');
  e = await t.rejects(r2.insert('observations', plant('P1')), 'VALIDATION_FAILED', 'un registro de otra entidad se valida contra la colección destino');
  e = await t.rejects(r2.insert('plants', plant('P1', { ploidy: 0 })), 'VALIDATION_FAILED', 'rango inválido (ploidy<1) → rechazado');
  await t.rejects(r2.insert('plants', plant('P1', { generation: 3 })), 'VALIDATION_FAILED', 'tipo inválido (generation debe ser texto) → rechazado');
  e = await t.rejects(r2.insert('plants', plant('P1', { sex: 'dragon' })), 'VALIDATION_FAILED', 'enum inválido → rechazado');
  e = await t.rejects(r2.insert('observations', obs('o1', { value: null })), 'VALIDATION_FAILED', 'valor obligatorio nulo → rechazado');
  t.eq(await r2.count('plants') + await r2.count('observations'), 0, 'ningún rechazo dejó residuos');
  const w = await r2.insert('simulations', legacySim('S1'));
  t.ok(['VALID', 'WARNING'].includes(w.validation.status), 'registro legacy con campos desconocidos: se acepta (VALID/WARNING), nunca INVALID');
  t.eq(w.validation.status, DM.validate('SimulationContext', legacySim('S1')).status, 'la validación informada coincide con DM.validate');
  t.eq(await r2.count('simulations'), 1, 'el registro legacy quedó almacenado');

  // ─────────────────────────────────────────────────────────────
  t.section('Procedencia (separación SIMULATED/OBSERVED/CALIBRATED/PREDICTED/VALIDATED/INFERRED)');
  const r3 = fresh();
  t.eq(obs('o0').provenance, 'OBSERVED', 'Observation recibe OBSERVED del schema (única admitida)');
  e = await t.rejects(r3.insert('observations', obs('o1', { provenance: 'SIMULATED' })), 'VALIDATION_FAILED', 'SIMULATED en observations → rechazado');
  t.has(codesOf(e), 'PROVENANCE_NOT_ALLOWED', '…con PROVENANCE_NOT_ALLOWED');
  for (const bad of ['CALIBRATED', 'PREDICTED', 'VALIDATED', 'INFERRED'])
    await t.rejects(r3.insert('observations', obs('o_' + bad, { provenance: bad })), 'VALIDATION_FAILED', `${bad} en observations → rechazado`);
  const noProv = obs('o2'); noProv.provenance = null;   // create() aplica el default del schema; aquí se anula a propósito
  await t.rejects(r3.insert('observations', noProv), 'VALIDATION_FAILED', 'provenance nula → rechazada (no se asume OBSERVED)');
  t.eq(await r3.count('observations'), 0, 'ninguna observación no-OBSERVED entró');
  await r3.insert('observations', obs('o3'));
  t.eq((await r3.get('observations', 'o3')).provenance, 'OBSERVED', 'una observación OBSERVED sí entra');
  t.eq(legacySim('S9').provenance, 'SIMULATED', 'SimulationContext recibe SIMULATED');
  e = await t.rejects(r3.insert('simulations', legacySim('S2', { provenance: 'OBSERVED' })), 'VALIDATION_FAILED', 'OBSERVED en simulations → rechazado');
  t.has(codesOf(e), 'PROVENANCE_NOT_ALLOWED', '…con PROVENANCE_NOT_ALLOWED');
  await r3.insert('simulations', legacySim('S3'));
  t.eq((await r3.get('simulations', 'S3')).provenance, 'SIMULATED', 'SimulationContext SIMULATED entra');
  const pd = (id, prov) => mk('PredictedDistribution', { prediction_id: id, record_origin: 'legacy', provenance: prov });
  e = await t.rejects(r3.insert('predictions', pd('pd1', 'OBSERVED')), 'VALIDATION_FAILED', 'OBSERVED en predictions → rechazado');
  t.has(codesOf(e), 'PROVENANCE_NOT_ALLOWED', '…con PROVENANCE_NOT_ALLOWED');
  e = await t.rejects(r3.insert('predictions', pd('pd1', 'VALIDATED')), 'VALIDATION_FAILED', 'VALIDATED en predictions → rechazado');
  for (const ok of ['SIMULATED', 'INFERRED']) {
    const r = await r3.insert('predictions', pd('pd_' + ok, ok));
    t.ok(r.validation.status !== 'INVALID', `${ok} en predictions → admitido`);
  }
  // PREDICTED y CALIBRATED exigen sus referencias (no se afirma lo que no se puede rastrear)
  e = await t.rejects(r3.insert('predictions', pd('pd_P0', 'PREDICTED')), 'VALIDATION_FAILED', 'PREDICTED sin modelo → rechazado');
  t.has(codesOf(e), 'PREDICTED_NEEDS_MODEL', '…con PREDICTED_NEEDS_MODEL');
  const rP = await r3.insert('predictions', mk('PredictedDistribution', { prediction_id: 'pd_P1', record_origin: 'legacy', provenance: 'PREDICTED', model_id: 'PE-PRED-001', model_version: 'v0.1', training_dataset_version: 'D1' }));
  t.ok(rP.validation.status !== 'INVALID', 'PREDICTED con model_id/model_version/training_dataset_version → admitido');
  e = await t.rejects(r3.insert('predictions', pd('pd_C0', 'CALIBRATED')), 'VALIDATION_FAILED', 'CALIBRATED sin calibración → rechazado');
  t.has(codesOf(e), 'CALIBRATED_NEEDS_CALIBRATION', '…con CALIBRATED_NEEDS_CALIBRATION');
  const rC = await r3.insert('predictions', mk('PredictedDistribution', { prediction_id: 'pd_C1', record_origin: 'legacy', provenance: 'CALIBRATED', calibration_id: 'cal-1' }));
  t.ok(rC.validation.status !== 'INVALID', 'CALIBRATED con calibration_id → admitido');
  const vr = { validation_id: 'val1', method: 'family_holdout', training_units: {}, test_units: {}, metrics: { test: {} }, disjoint: true };
  t.eq(mk('ValidationResult', vr).provenance, 'VALIDATED', 'ValidationResult recibe VALIDATED');
  await t.rejects(r3.insert('validations', mk('ValidationResult', Object.assign({}, vr, { provenance: 'SIMULATED' }))), 'VALIDATION_FAILED', 'SIMULATED en validations → rechazado');
  await r3.insert('validations', mk('ValidationResult', vr));
  t.eq(await r3.count('validations'), 1, 'ValidationResult VALIDATED entra');
  await t.rejects(r3.insert('calibrations', mk('CalibrationRecord', { calibration_id: 'c1', record_origin: 'direct', provenance: 'SIMULATED' })), 'VALIDATION_FAILED', 'SIMULATED en calibrations → rechazado');
  await r3.insert('calibrations', mk('CalibrationRecord', { calibration_id: 'c1', record_origin: 'direct' }));
  t.eq((await r3.get('calibrations', 'c1')).provenance, 'CALIBRATED', 'CalibrationRecord recibe CALIBRATED');

  // ─────────────────────────────────────────────────────────────
  t.section('update: merge, updated_at, y campos inmutables');
  const r4 = fresh();
  await r4.insert('observations', obs('o1', { observer: 'inicial' }));
  const before = await r4.get('observations', 'o1');
  const patch = { value: 8.3, observer: 'corregido' };
  const up = await r4.update('observations', 'o1', patch);
  t.eq(up.record.value, 8.3, 'update aplica el parche (merge superficial)');
  t.eq(up.record.observer, 'corregido', 'update: segundo campo del parche');
  t.eq(up.record.plant_id, before.plant_id, 'update conserva los campos no parcheados');
  t.eq(up.record.created_at, before.created_at, 'created_at se conserva');
  t.ok(up.record.updated_at !== before.updated_at, 'updated_at cambia');
  t.ok(/^2026-01-01T00:\d{2}:\d{2}Z$/.test(up.record.updated_at), 'updated_at proviene del reloj inyectado (no de Date)');
  t.eq(up.validation.status, 'VALID', 'update informa la validación');
  t.eq(await r4.get('observations', 'o1'), up.record, 'lo devuelto por update es lo almacenado');
  t.eq(patch, { value: 8.3, observer: 'corregido' }, 'update no muta el parche del llamador');
  e = await t.rejects(r4.update('observations', 'o1', { provenance: 'SIMULATED' }), 'PROVENANCE_IMMUTABLE', 'cambiar provenance → PROVENANCE_IMMUTABLE');
  t.ok(e && /OBSERVED/.test(e.message) && /SIMULATED/.test(e.message), 'el mensaje indica el cambio intentado (OBSERVED → SIMULATED)');
  await t.rejects(r4.update('observations', 'o1', { provenance: 'PREDICTED' }), 'PROVENANCE_IMMUTABLE', 'no se "promueve" a PREDICTED');
  await t.rejects(r4.update('observations', 'o1', { provenance: null }), 'PROVENANCE_IMMUTABLE', 'no se borra la procedencia (null)');
  await t.rejects(r4.update('observations', 'o1', { created_at: '1999-01-01' }), 'CREATED_AT_IMMUTABLE', 'cambiar created_at → CREATED_AT_IMMUTABLE');
  await t.rejects(r4.update('observations', 'o1', { observation_id: 'o2' }), 'KEY_IMMUTABLE', 'cambiar la clave → KEY_IMMUTABLE');
  t.eq(await r4.has('observations', 'o2'), false, 'la clave nueva no se creó');
  const okSame = await r4.update('observations', 'o1', { provenance: 'OBSERVED', created_at: before.created_at });
  t.eq(okSame.record.provenance, 'OBSERVED', 'reenviar el MISMO provenance/created_at no es un cambio → permitido');
  await t.rejects(r4.update('observations', 'inexistente', { value: 1 }), 'NOT_FOUND', 'update de clave inexistente → NOT_FOUND');
  const snapPre = JSON.stringify(await r4.get('observations', 'o1'));
  e = await t.rejects(r4.update('observations', 'o1', { value: null }), 'VALIDATION_FAILED', 'update que dejaría el registro INVALID → rechazado');
  t.eq(JSON.stringify(await r4.get('observations', 'o1')), snapPre, 'tras el rechazo el registro almacenado NO cambió');
  e = await t.rejects(r4.update('observations', 'o1', { value: NaN }), 'VALIDATION_FAILED', 'update con NaN → rechazado');
  t.has(e && e.detail && e.detail.unsafe, 'value', 'el error lista la ruta no representable (value)');
  await t.rejects(r4.update('observations', 'o1', { observer: new Date() }), 'VALIDATION_FAILED', 'update con Date → rechazado');
  t.eq(JSON.stringify(await r4.get('observations', 'o1')), snapPre, 'ningún parche inválido dejó huella');
  // concurrencia optimista
  const cur = await r4.get('observations', 'o1');
  await t.rejects(r4.update('observations', 'o1', { value: 9 }, { expected_updated_at: '1999-01-01T00:00:00Z' }), 'CONFLICT', 'expected_updated_at obsoleto → CONFLICT');
  const okc = await r4.update('observations', 'o1', { value: 9 }, { expected_updated_at: cur.updated_at });
  t.eq(okc.record.value, 9, 'expected_updated_at correcto → permitido');

  // ─────────────────────────────────────────────────────────────
  t.section('remove · clear');
  const r5 = fresh();
  await r5.insert('plants', plant('A')); await r5.insert('plants', plant('B')); await r5.insert('observations', obs('o1'));
  const removed = await r5.remove('plants', 'A');
  t.eq(removed.plant_id, 'A', 'remove devuelve el registro eliminado');
  t.eq(await r5.has('plants', 'A'), false, 'remove: ya no existe');
  t.eq(await r5.count('plants'), 1, 'remove: count=1');
  await t.rejects(r5.remove('plants', 'A'), 'NOT_FOUND', 'remove repetido → NOT_FOUND');
  await t.rejects(r5.remove('plants', 'nunca'), 'NOT_FOUND', 'remove de clave inexistente → NOT_FOUND');
  await r5.insert('plants', plant('A'));
  t.eq(await r5.count('plants'), 2, 'una clave eliminada puede reinsertarse');
  t.eq(await r5.clear('plants'), 2, 'clear devuelve cuántos registros eliminó');
  t.eq(await r5.count('plants'), 0, 'clear vacía la colección');
  t.eq(await r5.count('observations'), 1, 'clear NO afecta a otras colecciones');
  t.eq(await r5.clear('plants'), 0, 'clear de colección vacía → 0');

  // ─────────────────────────────────────────────────────────────
  t.section('snapshot · restore');
  const src = fresh();
  await src.insert('plants', plant('P1', { family_id: 'F1' })); await src.insert('plants', plant('P2'));
  await src.insert('observations', obs('o1')); await src.insert('simulations', legacySim('S1'));
  const snap = await src.snapshot();
  t.eq(snap.schema_version, DM.SCHEMA_VERSION, 'snapshot lleva schema_version');
  t.ok(/^2026-01-01T/.test(snap.created_at), 'snapshot lleva created_at (reloj inyectado)');
  t.eq(Object.keys(snap.collections), src.collections(), 'snapshot incluye las 15 colecciones (vacías incluidas)');
  t.eq(snap.collections.plants.length, 2, 'snapshot: contenido de plants');
  t.eq(JSON.parse(JSON.stringify(snap)), snap, 'snapshot es JSON puro (ida y vuelta idéntica)');
  snap.collections.plants[0].family_id = 'MUTADO';
  t.eq((await src.get('plants', 'P1')).family_id, 'F1', 'mutar el snapshot no altera el repositorio (copia profunda)');
  const snap2 = await src.snapshot();
  const dst = fresh();
  t.eq(await dst.restore(snap2), 4, 'restore sobre repositorio vacío: devuelve el total restaurado');
  t.eq((await dst.snapshot()).collections, snap2.collections, 'ida y vuelta: las colecciones restauradas son idénticas');
  t.eq(await dst.get('plants', 'P1'), await src.get('plants', 'P1'), 'registro restaurado idéntico al original');
  const viaJson = fresh(); await viaJson.restore(JSON.parse(JSON.stringify(snap2)));
  t.eq((await viaJson.snapshot()).collections, snap2.collections, 'restore desde snapshot serializado a JSON');
  // no sobrescribe en silencio
  e = await t.rejects(dst.restore(snap2), 'NOT_EMPTY', 'restore sobre repositorio NO vacío → NOT_EMPTY');
  t.eq(await dst.count('plants'), 2, 'tras NOT_EMPTY nada cambió');
  const small = fresh(); await small.insert('plants', plant('Z1'));
  const sSnap = await small.snapshot();
  t.eq(await dst.restore(sSnap, { replace: true }), 1, 'restore con {replace:true} explícito reemplaza');
  t.eq((await dst.list('plants')).map(x => x.plant_id), ['Z1'], '…y solo queda lo restaurado');
  t.eq(await dst.count('observations'), 0, '…las demás colecciones quedan vacías');
  await t.rejects(fresh().restore(null), 'BAD_SNAPSHOT', 'snapshot null → BAD_SNAPSHOT');
  await t.rejects(fresh().restore({}), 'BAD_SNAPSHOT', 'snapshot sin collections → BAD_SNAPSHOT');
  await t.rejects(fresh().restore(Object.assign({}, snap2, { schema_version: '0.0.1' })), 'SCHEMA_MISMATCH', 'schema_version distinta → SCHEMA_MISMATCH');
  await t.rejects(fresh().restore({ schema_version: DM.SCHEMA_VERSION, collections: { fantasma: [] } }), 'UNKNOWN_COLLECTION', 'colección desconocida en snapshot');
  // atomicidad
  const bad = JSON.parse(JSON.stringify(snap2)); bad.collections.plants.push({ plant_id: 'ROTO' });
  const target = fresh(); await target.insert('plants', plant('KEEP'));
  await t.rejects(target.restore(bad, { replace: true }), 'VALIDATION_FAILED', 'snapshot con un registro INVALID → rechazado');
  t.eq((await target.list('plants')).map(x => x.plant_id), ['KEEP'], 'restore fallido es ATÓMICO: el estado previo queda intacto');
  const dupSnap = JSON.parse(JSON.stringify(snap2)); dupSnap.collections.plants.push(dupSnap.collections.plants[0]);
  await t.rejects(fresh().restore(dupSnap), 'DUPLICATE_KEY', 'clave duplicada dentro del snapshot → DUPLICATE_KEY');
  const empty = fresh(); const eSnap = await empty.snapshot();
  t.eq(await fresh().restore(eSnap), 0, 'snapshot de repositorio vacío se restaura (0 registros)');

  // ─────────────────────────────────────────────────────────────
  t.section('Ausencia de invención de datos');
  const r6 = fresh();
  const minimal = plant('M1');
  await r6.insert('plants', minimal);
  const got = await r6.get('plants', 'M1');
  t.eq(got, minimal, 'lo almacenado es EXACTAMENTE lo insertado');
  t.eq(Object.keys(got).sort(), Object.keys(minimal).sort(), 'el repositorio no añade ni quita claves');
  ['family_id', 'population_id', 'mother_id', 'father_id', 'generation', 'sex', 'ploidy', 'environment_id', 'date_created', 'date_evaluated', 'notes']
    .filter(k => k in minimal).forEach(k => t.eq(got[k], null, `campo no suministrado "${k}" permanece null`));
  t.ok(Object.keys(minimal).some(k => minimal[k] === null), 'el registro mínimo contiene campos null (desconocidos)');
  await r6.insert('observations', obs('z', { value: 0 }));
  t.eq((await r6.get('observations', 'z')).value, 0, 'el valor 0 se conserva (no se trata como ausente)');
  await r6.insert('simulations', legacySim('L1'));
  const lg = await r6.get('simulations', 'L1');
  ['seed', 'N', 'alpha', 'muBase', 'h2', 'sigmaE', 'ploidy_a', 'ploidy_b', 'evidence_level_selected'].forEach(k => t.eq(lg[k], null, `legacy: "${k}" permanece null (no se rellena con valores actuales)`));
  const raw = { plant_id: 'RAW', record_origin: 'direct' };
  e = await t.rejects(r6.insert('plants', raw), 'VALIDATION_FAILED', 'insert NO completa metadatos faltantes (created_at/updated_at/schema_version)');
  t.has(codesOf(e), 'MISSING_REQUIRED', '…informa MISSING_REQUIRED');
  t.eq(raw, { plant_id: 'RAW', record_origin: 'direct' }, 'el registro del llamador no se modifica');
  t.eq(await r6.has('plants', 'RAW'), false, '…y no se almacenó nada');
  const det = async () => { const r = fresh(); n = 0; await r.insert('plants', plant('D1')); await r.insert('observations', obs('d1')); await r.update('observations', 'd1', { value: 1 }); return JSON.stringify(await r.snapshot()); };
  t.eq(await det(), await det(), 'determinismo: mismas operaciones y mismo reloj → snapshot idéntico (sin aleatoriedad)');

  // ─────────────────────────────────────────────────────────────
  t.section('Valores no representables en JSON: se RECHAZAN (no se convierten en null)');
  const r7 = fresh();
  const unsafe = [
    ['NaN', () => obs('u1', { value: NaN })],
    ['Infinity', () => obs('u2', { value: Infinity })],
    ['-Infinity', () => obs('u3', { value: -Infinity })],
    ['Date (instancia)', () => plant('u4', { date_created: new Date('2026-01-01') })],
    ['función', () => plant('u5', { notes: function () {} })],
    ['NaN anidado', () => plant('u6', { extra: { a: [1, { b: NaN }] } })],
    ['Infinity en array', () => plant('u7', { extra: [Infinity] })]
  ];
  for (const [name, build] of unsafe) {
    const rec = build(), col = rec.observation_id ? 'observations' : 'plants';
    const err = await t.rejects(r7.insert(col, rec), 'VALIDATION_FAILED', `${name} → rechazado`);
    t.has(codesOf(err), 'NOT_JSON_SAFE', `${name}: el informe indica NOT_JSON_SAFE`);
  }
  t.eq(await r7.count('plants') + await r7.count('observations'), 0, 'ningún valor no representable fue almacenado');
  const nan = obs('u8', { value: NaN });
  await r7.insert('observations', nan).catch(() => {});
  t.ok(Number.isNaN(nan.value), 'el registro del llamador conserva su NaN (no fue convertido a null)');
  await r7.insert('observations', obs('ok1', { value: 7.25 }));
  t.eq(JSON.parse(JSON.stringify(await r7.snapshot())).collections.observations[0].value, 7.25, 'los valores válidos sobreviven a JSON sin pérdida');
};
