module.exports = async (t, load) => {
  const L = load(), B = L.B;

  t.section('Namespace: inerte por defecto');
  t.ok(B && typeof B === 'object', 'MSCBreeding existe');
  t.eq(B.enabled, false, 'enabled=false por defecto');
  t.eq(B.phase, 1, 'phase=1');
  t.eq(B.schema_version, '1.0.0', 'schema_version');
  const st = B.status();
  t.eq(st.engine_coupled, false, 'status().engine_coupled=false (Fase 1 no se conecta al motor)');
  t.eq(st.modules, ['data-model', 'repository'], 'módulos registrados');

  t.section('Inercia: la capa solo añade el global MSCBreeding');
  const added = L.after.filter(n => !L.before.includes(n)), removed = L.before.filter(n => !L.after.includes(n));
  t.eq(added, ['MSCBreeding'], 'únicos globales añadidos');
  t.eq(removed, [], 'ningún global eliminado');
  const B2src = L.run('MSCBreeding');
  L.run(require('fs').readFileSync(require('path').join(L.ROOT, 'src/breeding/core/breeding-namespace.js'), 'utf8'));
  t.ok(L.run('MSCBreeding') === B2src, 'recargar el namespace no reemplaza la instancia (idempotente)');

  t.section('Inercia estática: el código de la capa no referencia el motor, el DOM ni el almacenamiento');
  const fs = require('fs'), path = require('path');
  // quita comentarios y literales de cadena (escaneo por caracteres; los tokens prohibidos solo importan en código)
  const strip = src => { let o = '', i = 0, q = null;
    while (i < src.length) { const c = src[i], n = src[i + 1];
      if (q) { if (c === '\\') { i += 2; continue; } if (c === q) q = null; i++; continue; }
      if (c === '/' && n === '*') { i = src.indexOf('*/', i + 2) + 2; continue; }
      if (c === '/' && n === '/') { while (i < src.length && src[i] !== '\n') i++; continue; }
      if (c === '"' || c === "'" || c === '`') { q = c; i++; continue; }
      o += c; i++; }
    return o; };
  const FORBIDDEN = [/localStorage/, /sessionStorage/, /indexedDB/, /Math\.random/, /\b_RNG\b/, /\bnew RNG\b/, /\bsimLibrary\b/,
    /\bSIM_(STATE|SEED|COUNT)\b/, /\bSK_STATE\b/, /EPISTASIS_MATRIX/, /\bdocument\b/, /\bwindow\b/, /\$\(/, /\bfetch\(/, /XMLHttpRequest/, /runMonteCarlo/];
  t.ok(strip("a // x _RNG\n b /* simLibrary */ c 'localStorage'") .indexOf('RNG') < 0, 'autoprueba del eliminador de comentarios/cadenas');
  for (const f of L.files) {
    const code = strip(fs.readFileSync(path.join(L.ROOT, f), 'utf8'));
    for (const re of FORBIDDEN) t.ok(!re.test(code), `${f} no debe referenciar ${re}`);
  }
  t.ok(L.files.length >= 3 && L.files.every(f => f.startsWith('src/breeding/core/')), 'manifest carga solo módulos breeding/core');

  t.section('Umbrales INSUFFICIENT DATA: configurables y NO definidos');
  t.eq(B.config.insufficientData, { minPlants: null, minFamilies: null, minCrosses: null, minObservationsPerTrait: null }, 'todos null (no definidos)');
  t.eq(B.evaluateSufficiency({ plants: 1e6, families: 1e6, crosses: 1e6, observationsPerTrait: 1e6 }).status, 'UNDEFINED', 'sin umbrales: UNDEFINED, nunca SUFFICIENT por omisión');
  t.eq(B.evaluateSufficiency({}).status, 'UNDEFINED', 'sin datos y sin umbrales: UNDEFINED');
  t.eq(B.evaluateSufficiency({}).thresholds_undefined.length, 4, 'lista los 4 umbrales sin definir');
  B.setInsufficientDataThresholds({ minPlants: 10, minFamilies: 2, minCrosses: 1, minObservationsPerTrait: 5 });
  t.eq(B.evaluateSufficiency({ plants: 10, families: 2, crosses: 1, observationsPerTrait: 5 }).status, 'SUFFICIENT', 'umbrales definidos y cumplidos');
  const ev = B.evaluateSufficiency({ plants: 9, families: 2, crosses: 1, observationsPerTrait: 5 });
  t.eq([ev.status, ev.short], ['INSUFFICIENT DATA', ['minPlants']], 'umbral no cumplido');
  t.eq(B.evaluateSufficiency({ plants: 10 }).status, 'INSUFFICIENT DATA', 'conteo ausente cuenta como insuficiente (no se asume)');
  B.setInsufficientDataThresholds({ minPlants: null });
  t.eq(B.evaluateSufficiency({ plants: 99, families: 9, crosses: 9, observationsPerTrait: 9 }).status, 'UNDEFINED', 'volver a null => UNDEFINED');
  let thrown = 0;
  [{ foo: 1 }, { minPlants: -1 }, { minPlants: 1.5 }, { minPlants: '3' }].forEach(bad => { try { B.setInsufficientDataThresholds(bad); } catch (e) { thrown++; } });
  t.eq(thrown, 4, 'umbrales desconocidos/inválidos se rechazan');

  t.section('register(): sin módulos duplicados');
  let dup = false; try { B.register('data-model', {}); } catch (e) { dup = true; }
  t.ok(dup, 'registrar dos veces el mismo módulo lanza error');
};
