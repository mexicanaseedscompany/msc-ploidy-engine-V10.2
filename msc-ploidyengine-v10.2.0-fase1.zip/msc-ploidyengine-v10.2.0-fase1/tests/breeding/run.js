#!/usr/bin/env node
// Ejecuta todas las suites tests/breeding/*.test.js.  Uso: node tests/breeding/run.js
const fs = require('fs'), path = require('path');
const t = require('./_harness'), load = require('./_load');
(async () => {
  const files = fs.readdirSync(__dirname).filter(f => f.endsWith('.test.js')).sort();
  for (const f of files) { console.log(`\n══ ${f}`); await require(path.join(__dirname, f))(t, load); }
  const { pass, fail } = t.counts;
  console.log(`\n${fail ? '✗' : '✓'} MSCBreeding (Fase 1): ${pass} comprobaciones correctas, ${fail} fallidas — ${files.length} suites`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
