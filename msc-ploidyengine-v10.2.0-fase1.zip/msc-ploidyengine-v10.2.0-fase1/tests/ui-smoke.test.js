// Prueba de humo de la UI completa con jsdom: ejecuta runMonteCarlo() en los 4 tipos de cruce.
// Requiere: npm install  y  npm run build
const fs = require('fs'), path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');
const pkg = require('../package.json');
const file = path.join(__dirname, '..', 'dist', `MSC_PloidyEngine_v${pkg.version.replace(/\./g, '-')}-PloidyGen.html`);
(async () => {
  let fail = 0;
  for (const [pA, pB, gA, gB] of [[4, 2, 2, 1], [2, 2, 1, 1], [4, 4, 2, 2], [2, 4, 1, 2]]) {
    const errs = [], vc = new VirtualConsole();
    vc.on('jsdomError', e => { if (!/localStorage/.test(e.message)) errs.push(e.message.split('\n')[0]); });
    const dom = new JSDOM(fs.readFileSync(file, 'utf8'), { runScripts: 'dangerously', virtualConsole: vc, pretendToBeVisual: true, url: 'http://localhost/' });
    const w = dom.window, d = w.document; await new Promise(r => setTimeout(r, 600));
    const set = (id, v) => { d.getElementById(id).value = String(v); };
    set('parA-ploidy', pA); w.updateParentalGenoOptions('A'); set('par4x', gA);
    set('parB-ploidy', pB); w.updateParentalGenoOptions('B'); set('par2x', gB); set('nSlider', 3);
    w.runMonteCarlo(); await new Promise(r => setTimeout(r, 2000));
    const g = d.getElementById('gValueDisplay').textContent, z = d.getElementById('zygoteDisplay').textContent;
    const good = /G TOTAL/.test(g) && /Genotipo F1/.test(z) && !errs.length;
    if (!good) fail++;
    console.log(`${good ? '✓' : '✗'} ${pA}x×${pB}x  ${good ? '' : errs.join(' | ')}`);
  }
  process.exit(fail ? 1 : 0);
})();
